# NOX v1.0

NOX is a production-oriented Personal AI Operating System with cognitive planning, deep research, autonomous agent workforce, skills, autonomous execution, artifacts, workspaces, and Qdrant-backed semantic retrieval.

## Run

1. Copy `.env.production.example` to `.env` and provide real production credentials.
2. Ensure Supabase, Upstash Redis, and Qdrant Cloud are reachable.
3. Set `NEXT_PUBLIC_API_BASE_URL` to the public NOX API URL.
4. Run `docker compose up --build`.

The root production compose intentionally runs only `backend` and `frontend`; PostgreSQL, Redis, storage, and Qdrant remain external services configured through environment variables.

## Validation

Backend: `PYTHONPATH=. pytest -q`
Frontend contracts: `node --test frontend/tests/*.test.mjs`
Python compilation: `PYTHONPATH=. python -m compileall -q backend`
Qdrant runtime: `PYTHONPATH=. python scripts/validate_qdrant_runtime.py`
