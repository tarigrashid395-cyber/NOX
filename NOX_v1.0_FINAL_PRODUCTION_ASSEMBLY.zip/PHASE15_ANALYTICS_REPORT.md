# NOX Phase 15 — Analytics Integration

Integrated with the existing Analytics Engine.

Backend stream telemetry:
- `stream.completed` with streamed token count and duration.

UX telemetry:
- `artifact_opened`
- `artifact_exported`
- `research_started`
- `research_completed`
- `citation_opened`
- `plan_expanded`

A single authenticated `POST /api/v1/analytics/events` endpoint records UX events into the existing Analytics Engine and does not introduce a second analytics store.
