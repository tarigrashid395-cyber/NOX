# NOX Deployment Guide — RC1

## Supported RC deployment
The canonical controlled deployment is Docker Compose using `infrastructure/docker/docker-compose.prod.yml`.

## Steps
1. Copy `.env.production.example` to a secure deployment secret store or environment file.
2. Generate a unique `APP_SECRET_KEY` of at least 32 characters.
3. Set PostgreSQL and MinIO credentials.
4. Set `PUBLIC_ORIGIN` to the HTTPS public origin.
5. Build with Docker Compose.
6. Start the stack.
7. Verify `/health/live` and `/health/ready` through the gateway.
8. Verify authenticated registration/login and file upload in staging.
9. Configure TLS at the gateway/load balancer; the bundled nginx RC config is HTTP-only and should sit behind an HTTPS edge or be extended with certificates.

## Required production controls
- Never use development credentials.
- Restrict PostgreSQL/Redis/MinIO/Qdrant to the private network.
- Back up persistent volumes and test restore.
- Monitor disk usage, database connections, object storage and vector-store capacity.
