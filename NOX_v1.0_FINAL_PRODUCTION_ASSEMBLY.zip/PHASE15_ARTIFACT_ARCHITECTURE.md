# NOX Phase 15 — Artifact Architecture

Artifacts are derived from authoritative response content in the existing chat experience; no duplicate backend artifact engine was introduced.

Supported views: HTML preview, Markdown/report/research/study notes, JSON, code, presentation/diagram definitions as code/text.

The workspace provides copy, download, fullscreen and close actions. Desktop uses a right-side resizable-style workspace surface; mobile uses a full-screen drawer surface. Large/code/document-like responses are automatically classified into an artifact panel.
