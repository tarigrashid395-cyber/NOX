export {};

export default function Notfound(){return <main><h1>NOX</h1></main>}
