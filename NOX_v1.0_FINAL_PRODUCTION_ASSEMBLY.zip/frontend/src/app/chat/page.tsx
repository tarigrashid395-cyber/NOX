import AppShell from '../../components/layout/AppShell'; import ChatView from '../../components/chat/ChatView'; export default function Chat(){return <AppShell><ChatView/></AppShell>}
