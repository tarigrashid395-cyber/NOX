export {};

export default function Loading(){return <main><h1>NOX</h1></main>}
