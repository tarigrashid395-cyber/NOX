export {};

export default function Page(){return <main><h1>NOX</h1></main>}
