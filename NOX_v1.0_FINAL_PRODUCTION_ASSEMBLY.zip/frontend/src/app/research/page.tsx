'use client';
import AppShell from '../../components/layout/AppShell';
import ResearchWorkspace from '../../components/research/ResearchWorkspace';
export default function ResearchPage(){return <AppShell><ResearchWorkspace/></AppShell>}
