export {};

export default function Error(){return <main><h1>NOX</h1></main>}
