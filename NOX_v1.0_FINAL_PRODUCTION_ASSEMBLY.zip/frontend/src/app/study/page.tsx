import {redirect} from 'next/navigation'; export default function Study(){redirect('/chat')}
