import {api,setAccessToken} from '../api/client';
export type User={id:string;email:string;role:string};
export type AuthResult={access_token:string;expires_in:number;user:User};
export async function login(email:string,password:string){const r=await api<AuthResult>('/auth/login',{method:'POST',body:JSON.stringify({email,password})});setAccessToken(r.access_token);localStorage.setItem('nox_user',JSON.stringify(r.user));return r}
export async function register(email:string,password:string,display_name:string){const r=await api<AuthResult>('/auth/register',{method:'POST',body:JSON.stringify({email,password,display_name})});setAccessToken(r.access_token);localStorage.setItem('nox_user',JSON.stringify(r.user));return r}
export async function logout(){await api('/auth/logout',{method:'POST'});setAccessToken(null);localStorage.removeItem('nox_user')}
export function storedUser():User|null{if(typeof window==='undefined')return null;const x=localStorage.getItem('nox_user');return x?JSON.parse(x):null}
