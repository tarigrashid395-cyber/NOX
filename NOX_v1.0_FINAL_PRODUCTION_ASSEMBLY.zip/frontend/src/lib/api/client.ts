const base=process.env.NEXT_PUBLIC_API_BASE_URL ?? '/api/v1';
let accessToken: string | null = null;
export function setAccessToken(token:string|null){accessToken=token; if(typeof window!=='undefined'){if(token)sessionStorage.setItem('nox_access_token',token);else sessionStorage.removeItem('nox_access_token')}}
export function getAccessToken(){if(accessToken)return accessToken;if(typeof window!=='undefined')return sessionStorage.getItem('nox_access_token');return null}
export async function api<T>(path:string,init?:RequestInit):Promise<T>{
  const token=getAccessToken(); const headers=new Headers(init?.headers); if(!(init?.body instanceof FormData))headers.set('Content-Type','application/json'); if(token)headers.set('Authorization',`Bearer ${token}`);
  let r=await fetch(`${base}${path}`,{...init,headers,credentials:'include'});
  if(r.status===401 && typeof window!=='undefined'){const rr=await fetch(`${base}/auth/refresh`,{method:'POST',credentials:'include'}); if(rr.ok){const data=await rr.json(); setAccessToken(data.access_token); headers.set('Authorization',`Bearer ${data.access_token}`); r=await fetch(`${base}${path}`,{...init,headers,credentials:'include'})}}
  if(!r.ok){const detail=await r.text(); throw new Error(detail||`API ${r.status}`)} return r.status===204?undefined as T:r.json();
}
export async function upload<T>(path:string,file:File){const fd=new FormData();fd.append('file',file);return api<T>(path,{method:'POST',body:fd})}

export async function trackAnalytics(event:string, value=1, metadata:Record<string,unknown>={}){try{await api('/analytics/events',{method:'POST',body:JSON.stringify({event,category:'ux',value,success:true,latency_ms:0,metadata})})}catch{/* UX telemetry must never block the user flow. */}}
