'use client';
import {useCallback,useRef,useState} from 'react';
import {getAccessToken} from '../lib/api/client';

export type SSEEvent={type:string;data:any};
export function useSSE(){
  const controller=useRef<AbortController|null>(null); const [running,setRunning]=useState(false);
  const stop=useCallback(()=>{controller.current?.abort();controller.current=null;setRunning(false)},[]);
  const connect=useCallback(async(url:string,body:unknown,onEvent:(event:SSEEvent)=>void)=>{
    stop(); const c=new AbortController(); controller.current=c; setRunning(true);
    try{const response=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${getAccessToken()||''}`,'Accept':'text/event-stream'},body:JSON.stringify(body),signal:c.signal}); if(!response.ok) throw new Error(`Streaming request failed (${response.status})`); if(!response.body) throw new Error('Streaming is not supported by this response');
      const reader=response.body.getReader(); const decoder=new TextDecoder(); let buffer='';
      while(true){const {done,value}=await reader.read(); if(done) break; buffer+=decoder.decode(value,{stream:true}); const chunks=buffer.split('\n\n'); buffer=chunks.pop()||''; for(const chunk of chunks){let type='message',data=''; for(const line of chunk.split('\n')){if(line.startsWith('event:')) type=line.slice(6).trim(); if(line.startsWith('data:')) data+=line.slice(5).trim()} if(data) onEvent({type,data:JSON.parse(data)})}}
    }finally{controller.current=null;setRunning(false)}
  },[stop]);
  return {connect,stop,running};
}
