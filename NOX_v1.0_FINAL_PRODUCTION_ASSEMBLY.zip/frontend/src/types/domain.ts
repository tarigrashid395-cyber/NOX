export interface Conversation{id:string;title?:string|null}
export interface Message{id:string;role:'system'|'user'|'assistant'|'tool';content:string}
export interface Artifact{id:string;type:string;payload:Record<string,unknown>}
