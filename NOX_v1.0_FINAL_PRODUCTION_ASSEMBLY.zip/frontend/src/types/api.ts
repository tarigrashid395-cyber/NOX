export interface HealthResponse{status:string;service?:string;checks?:Record<string,string>}
export interface ErrorResponse{code:string;message:string;trace_id?:string;details?:Record<string,unknown>}
