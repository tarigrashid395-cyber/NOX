'use client'; import {create} from 'zustand';
export type ChatMessage={role:'user'|'assistant';content:string;citations?:unknown[]};
type State={conversationId?:string;messages:ChatMessage[];setConversation:(id:string)=>void;append:(message:ChatMessage)=>void;reset:()=>void};
export const useChatStore=create<State>((set)=>({messages:[],setConversation:(conversationId)=>set({conversationId}),append:(message)=>set(s=>({messages:[...s.messages,message]})),reset:()=>set({conversationId:undefined,messages:[]})}));
