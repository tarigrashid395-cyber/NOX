'use client';
import Link from 'next/link';
import {usePathname,useRouter} from 'next/navigation';
import {logout,storedUser} from '../../lib/auth/session';
import {cn} from '../../lib/utils/cn';

const nav=[['/chat','Chat'],['/tasks','Tasks'],['/missions','Missions'],['/workspaces','Workspaces'],['/projects','Projects'],['/settings','Settings']];
export default function Sidebar(){const p=usePathname();const r=useRouter();const u=storedUser();return <aside className="hidden h-screen w-[260px] shrink-0 flex-col border-r border-white/[.07] bg-[#0B0B0B] lg:flex">
  <div className="flex h-16 items-center px-5"><Link href="/chat" className="flex items-center gap-3"><span className="grid h-8 w-8 place-items-center rounded-lg bg-[#E53935] text-sm font-black">N</span><span className="text-[15px] font-semibold tracking-[.22em]">NOX</span></Link></div>
  <div className="px-3 pt-3"><Link href="/chat" className="flex items-center justify-center gap-2 rounded-xl bg-white text-sm font-medium text-black transition hover:bg-zinc-200"><span className="text-lg">＋</span> New chat</Link></div>
  <nav className="mt-5 space-y-1 px-3">{nav.map(([href,label])=><Link key={href} href={href} className={cn('flex items-center gap-3 rounded-xl px-3 py-2.5 text-[13px] transition',p.startsWith(href)?'bg-white/[.08] text-white':'text-zinc-400 hover:bg-white/[.05] hover:text-white')}><span className={cn('h-1.5 w-1.5 rounded-full',p.startsWith(href)?'bg-[#E53935]':'bg-zinc-700')}/>{label}</Link>)}</nav>
  <div className="mt-6 px-3"><div className="px-3 pb-2 text-[10px] font-medium uppercase tracking-[.18em] text-zinc-600">Recent</div><div className="space-y-0.5"><Link href="/chat" className="block truncate rounded-lg px-3 py-2 text-xs text-zinc-500 hover:bg-white/[.04] hover:text-zinc-300">Start a new conversation</Link><Link href="/chat" className="block truncate rounded-lg px-3 py-2 text-xs text-zinc-500 hover:bg-white/[.04] hover:text-zinc-300">Explore what NOX can do</Link></div></div>
  <div className="mt-auto border-t border-white/[.07] p-3"><div className="flex items-center gap-3 rounded-xl p-2"><div className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-white/10 text-xs font-medium">{(u?.email||'N').slice(0,1).toUpperCase()}</div><div className="min-w-0 flex-1"><div className="truncate text-xs text-zinc-300">{u?.email||'NOX User'}</div><div className="text-[10px] text-zinc-600">Personal workspace</div></div><button aria-label="Sign out" onClick={async()=>{await logout();r.replace('/login')}} className="text-zinc-600 hover:text-white">↪</button></div></div>
</aside>}
