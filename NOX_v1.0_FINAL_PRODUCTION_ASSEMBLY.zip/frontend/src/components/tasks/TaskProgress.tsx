'use client';
import {useState} from 'react';
import {api} from '../../lib/api/client';
import {Button} from '../ui/Button';

type Task={id:string;goal:string;status:string;progress:number;current_step:number;total_steps:number;retry_count:number;error?:string|null};
export default function TaskProgress({initialTask}:{initialTask?:Task}){
 const [task,setTask]=useState<Task|undefined>(initialTask); const [goal,setGoal]=useState(''); const [busy,setBusy]=useState(false);
 const create=async()=>{if(!goal.trim())return;setBusy(true);try{const next=await api<Task>('/tasks',{method:'POST',body:JSON.stringify({goal})});setTask(next)}finally{setBusy(false)}};
 const refresh=async()=>{if(!task)return;setTask(await api<Task>(`/tasks/${task.id}`))};
 const cancel=async()=>{if(!task)return;setTask(await api<Task>(`/tasks/${task.id}/cancel`,{method:'POST'}))};
 return <section className="rounded-2xl border border-white/[.07] bg-[#151515] p-5">
  {!task?<><label className="text-xs text-zinc-500">Execution goal</label><textarea value={goal} onChange={e=>setGoal(e.target.value)} rows={4} className="mt-2 w-full rounded-xl border border-white/10 bg-[#0B0B0B] p-3 text-sm text-white outline-none focus:border-red-500" placeholder="Describe what NOX should execute…"/><Button className="mt-3" disabled={busy||!goal.trim()} onClick={create}>{busy?'Creating…':'Start task'}</Button></>:<>
   <div className="flex items-start justify-between gap-4"><div><p className="text-sm font-medium">{task.goal}</p><p className="mt-1 text-xs uppercase tracking-wider text-[#E53935]">{task.status}</p></div><div className="flex gap-2"><Button variant="ghost" onClick={refresh}>Refresh</Button>{!['completed','failed','cancelled'].includes(task.status)&&<Button variant="danger" onClick={cancel}>Cancel</Button>}</div></div>
   <div className="mt-5 h-2 overflow-hidden rounded-full bg-white/10"><div className="h-full bg-[#E53935] transition-all" style={{width:`${task.progress}%`}}/></div>
   <div className="mt-2 flex justify-between text-[11px] text-zinc-500"><span>{Math.round(task.progress)}%</span><span>Step {task.current_step}/{task.total_steps||'—'}</span></div>
   {task.error&&<p className="mt-4 rounded-xl bg-red-950/30 p-3 text-xs text-red-300">{task.error}</p>}
  </>}
 </section>
}
