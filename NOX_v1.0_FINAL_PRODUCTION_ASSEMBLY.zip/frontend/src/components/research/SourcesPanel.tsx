'use client';
import CitationCard from '../citations/CitationCard';
export default function SourcesPanel({citations,onOpen}:{citations:any[];onOpen:(x:any)=>void}){return <div className="space-y-2">{citations.map((c,i)=><CitationCard key={c.citation_key||i} citation={c} onOpen={()=>onOpen(c)}/>)}</div>}
