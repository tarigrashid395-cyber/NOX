import {test,expect} from '@playwright/test';
test('landing page',async({page})=>{await page.goto('/');await expect(page.getByText('Your personal AI operating system.')).toBeVisible()});
test('authentication navigation',async({page})=>{await page.goto('/');await page.getByRole('link',{name:'Start with NOX'}).click();await expect(page.getByText('Create your workspace')).toBeVisible()});
