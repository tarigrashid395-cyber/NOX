export default { plugins: {} };
