import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root=path.resolve('frontend/src');
test('Phase 18 execution UI exists and uses real APIs',()=>{
 for(const file of ['components/tasks/TaskProgress.tsx','components/missions/MissionTimeline.tsx','components/workspaces/WorkspaceDashboard.tsx','components/artifacts/ArtifactLibrary.tsx','app/tasks/page.tsx','app/missions/page.tsx','app/workspaces/page.tsx']) assert.equal(fs.existsSync(path.join(root,file)),true,file);
 const source=fs.readFileSync(path.join(root,'components/tasks/TaskProgress.tsx'),'utf8');
 assert.ok(source.includes("api<Task>('/tasks'"));
 assert.ok(source.includes('`/tasks/${task.id}`'));
 assert.ok(source.includes('cancel'));
});
