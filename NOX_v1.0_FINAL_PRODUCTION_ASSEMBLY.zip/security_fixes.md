# Security Fixes Applied — v1.0 RC1

- Replaced production default-secret acceptance with fail-closed configuration validation.
- Production startup now requires PostgreSQL and Redis availability.
- Production startup no longer silently falls back to in-memory file storage.
- Production repository schema initialization failures are fail-closed.
- Visual API now derives the user identity from authentication rather than a hard-coded development UUID.
- Password changes revoke all outstanding refresh tokens.
- Added file magic-signature validation and UTF-8 checks.
- Normalized uploaded filenames before constructing object-storage keys.
- Added HTTP security headers and production HSTS.
- Readiness endpoint now returns HTTP 503 when dependencies are degraded.
- Added deterministic prompt-injection screening and secret redaction utilities.
- Upgraded frontend dependency declarations to Next.js 15.5.18 and React/ReactDOM 19.1.9.
- Removed empty Terraform scaffolding and empty historical migration files from the release tree.
- Added a canonical release database baseline migration.
