# Supabase Security Review

## PASS

- No Supabase secret is hardcoded.
- `SUPABASE_SERVICE_ROLE_KEY` is backend-only.
- `SUPABASE_ANON_KEY` is not used for privileged backend operations.
- NOX JWT authentication remains authoritative; Supabase Auth is not substituted.
- RLS is enabled on NOX tables.
- `anon` and `authenticated` table privileges are revoked by the baseline migration.
- Supabase Storage bucket is private by default.
- Storage operations use the server-side service-role credential.
- Supabase Data API is not required for NOX backend persistence.
- Supabase-hosted PostgreSQL connections use TLS.

Supabase states that service/secret keys bypass RLS and must never be exposed to browsers; this matches the NOX deployment model. urlSupabase RLS guidancehttps://supabase.com/docs/guides/database/postgres/row-level-security

## Important boundary

RLS policies do not replace NOX application authorization because NOX maintains its own JWT identity system. Direct backend database access is intentionally privileged; user isolation remains enforced by repository queries and API authorization. The migration therefore uses RLS as defense-in-depth and blocks public Data API access to NOX tables.

## Remaining operational requirement

After applying the migration, run Supabase's database test tooling or equivalent SQL assertions to verify that anonymous and authenticated roles cannot access NOX tables and that the server database role retains required access.
