# NOX v1.0 GA — Runtime Validation Report

Generated: 2026-10-07T06:01:29Z

No credential values are emitted.

| Validation | Status | Evidence |
|---|---|---|
| Supabase | **NOT VERIFIED** | Required Supabase runtime credentials are unavailable. |
| Upstash Redis | **NOT VERIFIED** | Required Upstash credentials are unavailable. |
| Qdrant | **NOT VERIFIED** | Required Qdrant credentials are unavailable. |
| API health | **NOT VERIFIED** | NOX_API_BASE_URL is not configured for an externally reachable application runtime. |
| Memory Engine | **NOT VERIFIED** | Requires a reachable NOX application runtime with authenticated application execution; no application base URL was supplied. |
| Research Engine | **NOT VERIFIED** | Requires a reachable NOX application runtime and external research provider configuration. |
| File Intelligence | **NOT VERIFIED** | Requires a reachable NOX application runtime for upload/processing/retrieval execution. |
| E2E | **NOT VERIFIED** | Requires a reachable NOX application runtime and test-user execution path. |
| Security secret scan | **PASS** | No known credential/private-key material was detected in scanned source paths. |
