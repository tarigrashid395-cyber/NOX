# Backup & Recovery Guide

## PostgreSQL
Use `pg_dump` for logical backups and scheduled volume snapshots for larger installations. Backups must be encrypted and access-controlled.

## MinIO
Back up the object bucket using a versioned replication/snapshot strategy. Validate that metadata and object data can be restored independently.

## Qdrant
Back up collections using Qdrant snapshot facilities. Vector data should be treated as rebuildable only if the source documents and embedding configuration are preserved.

## Recovery order
1. Provision PostgreSQL and restore schema/data.
2. Restore MinIO objects.
3. Restore Qdrant or rebuild vectors from source documents.
4. Start Redis.
5. Start backend and worker services.
6. Verify readiness and authentication.
7. Run smoke tests and reconcile audit/analytics state.

## Recovery objective
RPO/RTO values are deployment-specific and must be set by the operator; the repository does not claim a universal SLA.
