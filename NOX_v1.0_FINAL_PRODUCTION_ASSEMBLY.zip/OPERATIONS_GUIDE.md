# NOX Operations Guide

## Health
- `/api/v1/health/live`: process liveness.
- `/api/v1/health/ready`: dependency readiness; returns 503 when PostgreSQL or Redis is unavailable.

## Routine operations
- Review audit events and authentication anomalies.
- Monitor API latency, failed requests and provider errors.
- Monitor PostgreSQL connection saturation and slow queries.
- Monitor Redis availability and memory.
- Monitor MinIO object growth.
- Monitor Qdrant collection size and vector latency.

## Incident response
1. Confirm gateway and backend health.
2. Check dependency health.
3. Preserve audit/log evidence.
4. Roll back the application image if the deployment caused the incident.
5. Restore data only after identifying the failure mode.
6. Document the incident and add a regression test for any confirmed defect.
