from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException
from backend.app.api.deps import get_container, get_current_user
from backend.app.core.container import Container
from backend.app.security.auth import CurrentUser
from backend.app.intelligence.schemas import PlanRequest, ExecuteRequest, ExecutionPlan, ExecutionResponse

router=APIRouter(prefix="/intelligence",tags=["intelligence"])

@router.post("/plan",response_model=ExecutionPlan)
async def intelligence_plan(body:PlanRequest,container:Container=Depends(get_container),user:CurrentUser=Depends(get_current_user)):
    return await container.intelligence.plan(user.user_id,body)

@router.post("/execute",response_model=ExecutionResponse)
async def intelligence_execute(body:ExecuteRequest,container:Container=Depends(get_container),user:CurrentUser=Depends(get_current_user)):
    try:
        return await container.intelligence.execute(user.user_id,body,body.plan)
    except PermissionError as exc: raise HTTPException(403,str(exc)) from exc

@router.get("/executions/{execution_id}")
async def intelligence_execution(execution_id:UUID,container:Container=Depends(get_container),user:CurrentUser=Depends(get_current_user)):
    record=await container.intelligence.get(user.user_id,execution_id)
    if record is None: raise HTTPException(404,"Execution not found")
    return record
