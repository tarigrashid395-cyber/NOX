from fastapi import APIRouter, Depends, HTTPException, Request, Response
from backend.app.api.deps import get_current_user
from backend.app.schemas.auth import RegisterRequest,LoginRequest,RefreshRequest,ChangePasswordRequest
from backend.app.security.auth import CurrentUser
router=APIRouter(prefix="/auth",tags=["auth"])
@router.post("/register")
async def register(body:RegisterRequest,request:Request,response:Response):
    try:
        result=await request.app.state.auth_service.register(body.email,body.password,body.display_name)
        response.set_cookie("nox_refresh",result.pop("refresh_token"),httponly=True,secure=request.url.scheme=="https",samesite="lax",max_age=2592000,path="/api/v1/auth")
        return result
    except (ValueError,PermissionError) as e: raise HTTPException(400,str(e)) from e
@router.post("/login")
async def login(body:LoginRequest,request:Request,response:Response):
    try:
        result=await request.app.state.auth_service.login(body.email,body.password)
        response.set_cookie("nox_refresh",result.pop("refresh_token"),httponly=True,secure=request.url.scheme=="https",samesite="lax",max_age=2592000,path="/api/v1/auth")
        return result
    except (ValueError,PermissionError) as e: raise HTTPException(401,str(e)) from e
@router.post("/refresh")
async def refresh(body:RefreshRequest,request:Request,response:Response):
    try:
        raw=body.refresh_token or request.cookies.get("nox_refresh")
        result=await request.app.state.auth_service.refresh(raw)
        response.set_cookie("nox_refresh",result.pop("refresh_token"),httponly=True,secure=request.url.scheme=="https",samesite="lax",max_age=2592000,path="/api/v1/auth")
        return result
    except PermissionError as e: raise HTTPException(401,str(e)) from e
@router.post("/logout")
async def logout(body:RefreshRequest,request:Request,response:Response):
    raw=body.refresh_token or request.cookies.get("nox_refresh")
    if raw: await request.app.state.auth_service.repo.revoke_refresh(raw)
    response.delete_cookie("nox_refresh",path="/api/v1/auth"); return {"logged_out":True}
@router.get("/me")
async def me(user:CurrentUser=Depends(get_current_user)): return {"id":str(user.user_id),"email":user.email,"role":user.role}
@router.post("/change-password")
async def change_password(body:ChangePasswordRequest,request:Request,user:CurrentUser=Depends(get_current_user)):
    u=await request.app.state.auth_service.repo.get_user(user.user_id)
    if not u or not request.app.state.auth_service.hasher.verify(body.current_password,u["password_hash"]): raise HTTPException(400,"Current password is incorrect")
    await request.app.state.auth_service.repo.set_password(user.user_id,request.app.state.auth_service.hasher.hash(body.new_password)); await request.app.state.auth_service.repo.revoke_all_refresh(user.user_id); await request.app.state.auth_service.repo.audit_event(user.user_id,"password_changed"); return {"changed":True}
@router.get('/oauth/{provider}/authorize')
async def oauth_authorize(provider:str,request:Request):
    import urllib.parse
    settings=request.app.state.auth_service
    config=getattr(request.app.state,'oauth',{}).get(provider)
    if not config: raise HTTPException(503,f'{provider} OAuth is not configured')
    query=urllib.parse.urlencode({'client_id':config['client_id'],'redirect_uri':config['redirect_uri'],'response_type':'code','scope':config['scope']})
    return {'provider':provider,'authorization_url':f"{config['authorize_url']}?{query}"}
