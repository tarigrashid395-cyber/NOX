from fastapi import APIRouter,Depends
from backend.app.api.deps import get_container,get_current_user
from backend.app.core.container import Container
from backend.app.security.auth import CurrentUser
from backend.app.tools.tool_models import ToolRequest,ToolResult
router=APIRouter(prefix='/tools',tags=['tools'])
@router.post('/execute',response_model=ToolResult)
async def execute(body:ToolRequest,container:Container=Depends(get_container),user:CurrentUser=Depends(get_current_user)): return await container.tools.execute(user.user_id,body,context={'container':container},role=user.role)
@router.get('')
async def list_tools(container:Container=Depends(get_container),user:CurrentUser=Depends(get_current_user)): return {'tools':[x.model_dump(mode='json') for x in container.tool_registry.list()]}
