from fastapi import APIRouter, Depends
from backend.app.api.deps import get_container,get_current_user
from backend.app.core.container import Container
from backend.app.security.auth import CurrentUser
from backend.app.evaluation.schemas import EvaluationRequest,EvaluationResult,EvaluationReport

router=APIRouter(prefix='/evaluation',tags=['evaluation'])
@router.post('/run',response_model=EvaluationResult)
async def evaluation_run(body:EvaluationRequest,container:Container=Depends(get_container),user:CurrentUser=Depends(get_current_user)):
    result=await container.evaluation.run(user.user_id,body)
    await container.analytics.record(user.user_id,container.analytics_event('evaluation.run',category='evaluation',value=result.benchmark_score,success=result.regression_passed))
    return result
@router.get('/report',response_model=EvaluationReport)
async def evaluation_report(container:Container=Depends(get_container),user:CurrentUser=Depends(get_current_user)):
    return await container.evaluation.report(user.user_id)
