from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException
from backend.app.api.deps import get_container, get_current_user
from backend.app.core.container import Container
from backend.app.security.auth import CurrentUser
from backend.app.domain.memories import MemoryType
from backend.app.schemas.memory import MemoryStoreRequest,MemoryResponse,MemorySearchRequest,MemorySearchResponse,MemoryUserResponse

router=APIRouter(prefix="/memory",tags=["memory"])

def _response(x): return MemoryResponse(**x)

@router.post("/store",response_model=MemoryResponse)
async def store_memory(body:MemoryStoreRequest,container:Container=Depends(get_container),user:CurrentUser=Depends(get_current_user)):
    data=body.model_dump(exclude_none=True); mt=data.pop("memory_type")
    item=await container.memory.store(user.user_id,MemoryType(mt),**data)
    return _response(item)

@router.post("/search",response_model=MemorySearchResponse)
async def search_memory(body:MemorySearchRequest,container:Container=Depends(get_container),user:CurrentUser=Depends(get_current_user)):
    data=body.model_dump(); types=data.pop("memory_types")
    results=await container.memory.search(user.user_id,data.pop("query"),memory_types=types,**data)
    return MemorySearchResponse(query=body.query,results=results)

@router.get("/user",response_model=MemoryUserResponse)
async def user_memory(container:Container=Depends(get_container),user:CurrentUser=Depends(get_current_user)):
    items=await container.memory.lifecycle.repository.list_user(user.user_id)
    return MemoryUserResponse(memories=[_response(x) for x in items])

@router.delete("/{memory_id}")
async def delete_memory(memory_id:UUID,container:Container=Depends(get_container),user:CurrentUser=Depends(get_current_user)):
    ok=await container.memory.lifecycle.delete(user.user_id,memory_id)
    if not ok: raise HTTPException(status_code=404,detail="Memory not found")
    return {"deleted":True,"id":memory_id}
