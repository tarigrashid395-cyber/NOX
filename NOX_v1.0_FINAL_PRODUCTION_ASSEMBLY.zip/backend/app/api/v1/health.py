from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse
router=APIRouter(tags=['health'])
@router.get('/health')
async def health(request:Request):
    return {'status':'ok','service':'nox'}
@router.get('/health/live')
async def live(): return {'status':'ok'}
@router.get('/health/llm')
async def llm_health(request:Request):
    llm=getattr(request.app.state.container,'llm',None)
    if not llm: return JSONResponse(status_code=503,content={'status':'unavailable','providers':[]})
    results=await llm.health(); ok=any(x.healthy for x in results)
    return JSONResponse(status_code=200 if ok else 503,content={'status':'ok' if ok else 'degraded','providers':[x.__dict__ for x in results],'metrics':llm.metrics()})
@router.get('/health/ready')
async def ready(request:Request):
    checks={}
    db=request.app.state.container.database
    try: await db.ping(); checks['postgres']='ok'
    except Exception as exc: checks['postgres']=f'unavailable: {type(exc).__name__}'
    redis=request.app.state.container.redis
    try:
        await redis.ping(); checks['redis']='ok'; checks['redis_provider']=getattr(request.app.state.container.settings, 'redis_provider', 'unknown')
    except Exception as exc: checks['redis']=f'unavailable: {type(exc).__name__}'
    storage=getattr(request.app.state.container, 'files', None)
    provider=getattr(storage, 'storage', None)
    if hasattr(provider, 'ping'):
        try: checks['storage']='ok' if await provider.ping() else 'unavailable'
        except Exception as exc: checks['storage']=f'unavailable: {type(exc).__name__}'
    status='ok' if all(v=='ok' for v in checks.values()) else 'degraded'
    code = 200 if status == 'ok' else 503
    return JSONResponse(status_code=code, content={'status':status,'checks':checks})
