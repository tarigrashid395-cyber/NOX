from uuid import UUID
from fastapi import APIRouter,Depends,HTTPException
from backend.app.api.deps import get_container,get_current_user
from backend.app.core.container import Container
from backend.app.security.auth import CurrentUser
from backend.app.workspaces.workspace_models import WorkspaceCreate,WorkspaceUpdate,Workspace,WorkspaceAssets
router=APIRouter(prefix='/workspaces',tags=['workspaces'])
@router.post('',response_model=Workspace)
async def create(body:WorkspaceCreate,container:Container=Depends(get_container),user:CurrentUser=Depends(get_current_user)): return await container.workspaces.create(user.user_id,body)
@router.get('/{workspace_id}',response_model=Workspace)
async def get(workspace_id:UUID,container:Container=Depends(get_container),user:CurrentUser=Depends(get_current_user)):
    result=await container.workspaces.get(user.user_id,workspace_id)
    if not result: raise HTTPException(404,'Workspace not found')
    return result
@router.patch('/{workspace_id}',response_model=Workspace)
async def update(workspace_id:UUID,body:WorkspaceUpdate,container:Container=Depends(get_container),user:CurrentUser=Depends(get_current_user)):
    result=await container.workspaces.update(user.user_id,workspace_id,body)
    if not result: raise HTTPException(404,'Workspace not found')
    return result
@router.get('/{workspace_id}/assets',response_model=WorkspaceAssets)
async def assets(workspace_id:UUID,container:Container=Depends(get_container),user:CurrentUser=Depends(get_current_user)):
    result=await container.workspaces.assets(user.user_id,workspace_id)
    if not result: raise HTTPException(404,'Workspace not found')
    return result
