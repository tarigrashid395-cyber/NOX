from fastapi import APIRouter,Depends
from backend.app.api.deps import get_container,get_current_user
from backend.app.core.container import Container
from backend.app.security.auth import CurrentUser
from backend.app.evaluation.schemas import AnalyticsDashboard, AnalyticsEvent
router=APIRouter(prefix='/analytics',tags=['analytics'])
@router.get('/dashboard',response_model=AnalyticsDashboard)
async def analytics_dashboard(container:Container=Depends(get_container),user:CurrentUser=Depends(get_current_user)):
    report=await container.evaluation.report(user.user_id)
    graph=await container.graph.graph(user.user_id)
    return await container.analytics.dashboard(user.user_id,report,graph)


@router.post('/events', status_code=204)
async def analytics_event(body: AnalyticsEvent, container:Container=Depends(get_container), user:CurrentUser=Depends(get_current_user)):
    await container.analytics.record(user.user_id, body)
