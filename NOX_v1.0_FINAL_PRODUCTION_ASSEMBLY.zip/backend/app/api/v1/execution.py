from __future__ import annotations
from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException
from backend.app.api.deps import get_container,get_current_user
from backend.app.core.container import Container
from backend.app.security.auth import CurrentUser
from backend.app.execution.execution_models import TaskCreate,Task

router=APIRouter(prefix='/tasks',tags=['execution'])

@router.post('',response_model=Task,status_code=202)
async def create_task(body:TaskCreate,container:Container=Depends(get_container),user:CurrentUser=Depends(get_current_user)):
    task=await container.execution.create(user.user_id,body)
    await container.execution_scheduler.schedule(task.id)
    return task

@router.get('/{task_id}',response_model=Task)
async def get_task(task_id:UUID,container:Container=Depends(get_container),user:CurrentUser=Depends(get_current_user)):
    task=await container.execution.get_task(task_id,user.user_id)
    if not task: raise HTTPException(404,'Task not found')
    return task

@router.post('/{task_id}/cancel',response_model=Task)
async def cancel_task(task_id:UUID,container:Container=Depends(get_container),user:CurrentUser=Depends(get_current_user)):
    task=await container.execution.get_task(task_id,user.user_id)
    if not task: raise HTTPException(404,'Task not found')
    return await container.execution_scheduler.cancel(task_id)
