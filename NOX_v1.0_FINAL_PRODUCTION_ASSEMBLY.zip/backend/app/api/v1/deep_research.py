from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException
from backend.app.api.deps import get_container, get_current_user
from backend.app.core.container import Container
from backend.app.security.auth import CurrentUser
from backend.app.research.autonomous.research_models import DeepResearchStartRequest, DeepResearchSession, DeepResearchReport

router=APIRouter(prefix="/deep-research",tags=["deep-research"])

@router.post("/start",response_model=DeepResearchSession)
async def start_deep_research(body:DeepResearchStartRequest,container:Container=Depends(get_container),user:CurrentUser=Depends(get_current_user)):
    return await container.deep_research.start(user.user_id,body)

@router.get("/{session_id}",response_model=DeepResearchSession)
async def get_deep_research(session_id:UUID,container:Container=Depends(get_container),user:CurrentUser=Depends(get_current_user)):
    result=await container.deep_research.get(user.user_id,session_id)
    if result is None: raise HTTPException(404,"Deep research session not found")
    return result

@router.get("/report/{report_id}",response_model=DeepResearchReport)
async def get_deep_research_report(report_id:UUID,container:Container=Depends(get_container),user:CurrentUser=Depends(get_current_user)):
    result=await container.deep_research.report(user.user_id,report_id)
    if result is None: raise HTTPException(404,"Deep research report not found")
    return result
