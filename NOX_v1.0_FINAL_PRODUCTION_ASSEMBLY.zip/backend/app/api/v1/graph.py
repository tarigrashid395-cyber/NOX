from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException, Query
from backend.app.api.deps import get_container, get_current_user
from backend.app.core.container import Container
from backend.app.security.auth import CurrentUser
from backend.app.graph.schemas import GraphQuery, GraphResult

router=APIRouter(prefix='/graph',tags=['graph'])

@router.post('/query',response_model=GraphResult)
async def graph_query(body:GraphQuery,container:Container=Depends(get_container),user:CurrentUser=Depends(get_current_user)):
    return await container.graph.query(user.user_id,body)

@router.post('/search',response_model=GraphResult)
async def graph_search(body:GraphQuery,container:Container=Depends(get_container),user:CurrentUser=Depends(get_current_user)):
    return await container.graph.search_query(user.user_id,body)

@router.get('/entity/{entity_id}')
async def graph_entity(entity_id:UUID,container:Container=Depends(get_container),user:CurrentUser=Depends(get_current_user)):
    node=await container.graph.entity(user.user_id,entity_id)
    if node is None: raise HTTPException(404,'Graph entity not found')
    return node

@router.get('/visualize')
async def graph_visualize(kind:str=Query('knowledge_graph'),query:str=Query(''),container:Container=Depends(get_container),user:CurrentUser=Depends(get_current_user)):
    allowed={'knowledge_graph','learning_graph','project_graph','research_graph'}
    if kind not in allowed: raise HTTPException(400,f'Unsupported graph visualization: {kind}')
    payload=await container.graph.visualize(user.user_id,kind,query)
    # Reuse the approved Visual Engine for the artifact representation.
    from backend.app.schemas.visual import VisualRequest
    artifact=await container.visual.create(user.user_id,VisualRequest(visual_type='knowledge_graph',title=payload['title'],topic=query or kind,content={'nodes':payload['nodes'],'edges':payload['edges']}),export_format='json')
    return {'graph':payload,'visual_artifact':artifact}
