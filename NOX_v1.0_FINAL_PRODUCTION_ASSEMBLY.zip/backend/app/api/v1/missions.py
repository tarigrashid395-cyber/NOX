from uuid import UUID
from fastapi import APIRouter,Depends,HTTPException
from backend.app.api.deps import get_container,get_current_user
from backend.app.core.container import Container
from backend.app.security.auth import CurrentUser
from backend.app.missions.mission_models import MissionStartRequest,Mission
router=APIRouter(prefix='/missions',tags=['missions'])
@router.post('/start',response_model=Mission,status_code=202)
async def start(body:MissionStartRequest,container:Container=Depends(get_container),user:CurrentUser=Depends(get_current_user)): return await container.missions.start(user.user_id,body)
@router.get('/{mission_id}',response_model=Mission)
async def get(mission_id:UUID,container:Container=Depends(get_container),user:CurrentUser=Depends(get_current_user)):
    result=await container.missions.get(user.user_id,mission_id)
    if not result: raise HTTPException(404,'Mission not found')
    return result
