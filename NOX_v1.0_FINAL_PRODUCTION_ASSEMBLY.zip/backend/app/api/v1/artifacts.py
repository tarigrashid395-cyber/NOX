from uuid import UUID
from fastapi import APIRouter,Depends,HTTPException
from backend.app.api.deps import get_container,get_current_user
from backend.app.core.container import Container
from backend.app.security.auth import CurrentUser
from backend.app.artifacts.artifact_models import Artifact
router=APIRouter(prefix='/artifacts',tags=['artifacts'])
@router.get('/{artifact_id}',response_model=Artifact)
async def get_artifact(artifact_id:UUID,container:Container=Depends(get_container),user:CurrentUser=Depends(get_current_user)):
    result=await container.artifacts.get(user.user_id,artifact_id,include_content=True)
    if not result: raise HTTPException(404,'Artifact not found')
    if container.analytics: await container.analytics.record(user.user_id,container.analytics_event('artifact_downloaded',category='execution',tool='artifact'))
    return result
