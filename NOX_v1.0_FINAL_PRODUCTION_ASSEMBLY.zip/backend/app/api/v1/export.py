from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException
from backend.app.api.deps import get_container,get_current_user
from backend.app.core.container import Container
from backend.app.security.auth import CurrentUser
from backend.app.export.schemas import ExportRequest,ExportResult
router=APIRouter(prefix='/export',tags=['export'])
@router.post('',response_model=ExportResult)
async def export(body:ExportRequest,container:Container=Depends(get_container),user:CurrentUser=Depends(get_current_user)): return await container.export.export(user.user_id,body)
def _typed(fmt):
    async def handler(body:ExportRequest,container:Container=Depends(get_container),user:CurrentUser=Depends(get_current_user)):
        if body.format!=fmt: body=body.model_copy(update={'format':fmt})
        return await container.export.export(user.user_id,body)
    return handler
for path,fmt in [('/pdf','pdf'),('/docx','docx'),('/pptx','pptx'),('/zip','zip')]: router.post(path,response_model=ExportResult)(_typed(fmt))
@router.get('/history')
async def history(container:Container=Depends(get_container),user:CurrentUser=Depends(get_current_user)): return await container.export.history(user.user_id)
@router.get('/{export_id}',response_model=ExportResult)
async def get_export(export_id:UUID,container:Container=Depends(get_container),user:CurrentUser=Depends(get_current_user)):
    result=await container.export.get(user.user_id,export_id)
    if result is None: raise HTTPException(404,'Export job not found')
    return ExportResult(job=result)
