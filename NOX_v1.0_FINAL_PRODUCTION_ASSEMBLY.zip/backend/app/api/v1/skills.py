from fastapi import APIRouter,Depends
from backend.app.api.deps import get_container,get_current_user
from backend.app.core.container import Container
from backend.app.security.auth import CurrentUser
from backend.app.skills.skill_models import SkillExecutionRequest
router=APIRouter(prefix='/skills',tags=['skills'])
@router.post('/execute')
async def execute_skill(body:SkillExecutionRequest,container:Container=Depends(get_container),user:CurrentUser=Depends(get_current_user)):
    return await container.skills.execute(user.user_id,body,{'conversation_id':body.conversation_id})
@router.get('')
async def list_skills(container:Container=Depends(get_container),user:CurrentUser=Depends(get_current_user)): return {'skills':[x.model_dump(mode='json') for x in container.skills.registry.list()]}
