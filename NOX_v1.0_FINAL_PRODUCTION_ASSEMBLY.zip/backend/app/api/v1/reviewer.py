from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from backend.app.api.deps import get_container, get_current_user
from backend.app.core.container import Container
from backend.app.security.auth import CurrentUser
from backend.app.agents.reviewer.reviewer_models import ReviewReport

class ReviewerRequest(BaseModel):
    user_query: str = Field(min_length=1, max_length=20000)
    execution_plan: dict = Field(default_factory=dict)
    draft_response: str = Field(min_length=1, max_length=100000)
    plan_id: UUID | None = None
    iteration: int = Field(default=1, ge=1, le=2)

router=APIRouter(prefix="/reviewer", tags=["reviewer"])

@router.post("/review", response_model=ReviewReport)
async def review(body: ReviewerRequest, container: Container=Depends(get_container), user: CurrentUser=Depends(get_current_user)):
    plan=dict(body.execution_plan)
    if body.plan_id is not None: plan["plan_id"]=body.plan_id
    return await container.reviewer_service.review(body.user_query,plan,body.draft_response,user.user_id,body.iteration)

@router.get("/{review_id}", response_model=ReviewReport)
async def get_review(review_id: UUID, container: Container=Depends(get_container), user: CurrentUser=Depends(get_current_user)):
    report=await container.reviewer_service.get(review_id,user.user_id)
    if report is None: raise HTTPException(404,"Review report not found")
    return report
