from fastapi import APIRouter, Depends, File, UploadFile, HTTPException
from backend.app.api.deps import get_container,get_current_user
from backend.app.schemas.files import FileAnalysisRequest,FileQARequest
router=APIRouter(prefix="/files",tags=["files"])
@router.post("/upload")
async def upload(file:UploadFile=File(...),container=Depends(get_container),user=Depends(get_current_user)):
    try: return await container.files.upload(user.user_id,file.filename or "upload",await file.read(),file.content_type)
    except ValueError as exc: raise HTTPException(400,str(exc)) from exc
@router.post("/analyze")
async def analyze(body:FileAnalysisRequest,container=Depends(get_container),user=Depends(get_current_user)):
    try:return await container.files.analyze(user.user_id,body.document_id)
    except FileNotFoundError as exc:raise HTTPException(404,str(exc)) from exc
@router.post("/ask")
async def ask(body:FileQARequest,container=Depends(get_container),user=Depends(get_current_user)):
    try:return await container.files.ask(user.user_id,body.document_id,body.question)
    except FileNotFoundError as exc:raise HTTPException(404,str(exc)) from exc
@router.get("/history")
async def history(container=Depends(get_container),user=Depends(get_current_user)): return await container.files.repository.history(user.user_id)
@router.get("/{document_id}")
async def get_file(document_id,container=Depends(get_container),user=Depends(get_current_user)):
    from uuid import UUID
    result=await container.files.repository.get_document_bundle(user.user_id,UUID(document_id))
    if not result:raise HTTPException(404,"Document not found")
    return result
@router.delete("/{document_id}")
async def delete(document_id,container=Depends(get_container),user=Depends(get_current_user)):
    from uuid import UUID
    doc=await container.files.repository.get_document(user.user_id,UUID(document_id))
    if not doc:raise HTTPException(404,"Document not found")
    await container.files.storage.delete(doc["storage_key"]); return {"deleted":await container.files.repository.delete_document(user.user_id,UUID(document_id))}
