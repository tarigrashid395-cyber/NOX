from fastapi import APIRouter
from backend.app.api.v1.health import router as health_router
from backend.app.api.v1.memory import router as memory_router
from backend.app.api.v1.research import router as research_router
from backend.app.api.v1.files import router as files_router
from backend.app.api.v1.visual import router as visual_router
from backend.app.api.v1.motion import router as motion_router
from backend.app.api.v1.creation import router as creation_router
from backend.app.api.v1.export import router as export_router
from backend.app.api.v1.artifacts import router as artifacts_router
from backend.app.api.v1.auth import router as auth_router
from backend.app.api.v1.user import router as user_router
from backend.app.api.v1.chat import router as chat_router
from backend.app.api.v1.chat_stream import router as chat_stream_router
from backend.app.api.v1.intelligence import router as intelligence_router
from backend.app.api.v1.graph import router as graph_router
from backend.app.api.v1.evaluation import router as evaluation_router
from backend.app.api.v1.analytics import router as analytics_router
from backend.app.api.v1.planner import router as planner_router
from backend.app.api.v1.reviewer import router as reviewer_router
from backend.app.api.v1.deep_research import router as deep_research_router
from backend.app.api.v1.agents import router as agents_router
from backend.app.api.v1.skills import router as skills_router
from backend.app.api.v1.execution import router as execution_router
from backend.app.api.v1.missions import router as missions_router
from backend.app.api.v1.workspaces import router as workspaces_router
from backend.app.api.v1.tools import router as tools_router
router=APIRouter(prefix='/api/v1')
for r in (health_router,memory_router,research_router,files_router,visual_router,motion_router,creation_router,export_router,artifacts_router,auth_router,user_router,chat_router,intelligence_router,graph_router,evaluation_router,analytics_router,planner_router,reviewer_router,deep_research_router,agents_router,skills_router,execution_router,missions_router,workspaces_router,tools_router,chat_stream_router): router.include_router(r)
