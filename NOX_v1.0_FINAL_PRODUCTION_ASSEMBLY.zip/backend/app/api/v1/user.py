from fastapi import APIRouter,Depends,Request
from fastapi.responses import JSONResponse
from backend.app.api.deps import get_current_user
from backend.app.schemas.auth import ProfileUpdateRequest,PreferencesRequest
from backend.app.security.auth import CurrentUser
router=APIRouter(prefix='/user',tags=['user'])
@router.get('/profile')
async def profile(request:Request,user:CurrentUser=Depends(get_current_user)): return {'user':await request.app.state.auth_service.repo.get_user(user.user_id),'profile':await request.app.state.auth_service.repo.profile(user.user_id)}
@router.patch('/profile')
async def update_profile(body:ProfileUpdateRequest,request:Request,user:CurrentUser=Depends(get_current_user)): return await request.app.state.auth_service.repo.update_profile(user.user_id,body.model_dump(exclude_none=True))
@router.get('/preferences')
async def preferences(request:Request,user:CurrentUser=Depends(get_current_user)): return {'data':await request.app.state.auth_service.repo.preferences(user.user_id)}
@router.put('/preferences')
async def save_preferences(body:PreferencesRequest,request:Request,user:CurrentUser=Depends(get_current_user)): return {'data':await request.app.state.auth_service.repo.save_preferences(user.user_id,body.data)}
@router.get('/usage')
async def usage(request:Request,user:CurrentUser=Depends(get_current_user)): return {'total_requests':request.app.state.auth_service.repo.usage.get(user.user_id,{}).get('total_requests',0),'total_tokens':request.app.state.auth_service.repo.usage.get(user.user_id,{}).get('total_tokens',0),'plan':'free'}
@router.get('/activity')
async def activity(request:Request,user:CurrentUser=Depends(get_current_user)): return {'items':[x for x in request.app.state.auth_service.repo.audit if x['user_id']==user.user_id]}
@router.get('/export-data')
async def export_data(request:Request,user:CurrentUser=Depends(get_current_user)): return await request.app.state.auth_service.repo.account_export(user.user_id)
@router.delete('/account')
async def delete_account(request:Request,user:CurrentUser=Depends(get_current_user)):
    await request.app.state.auth_service.repo.audit_event(user.user_id,'account_deleted'); return {'deleted':await request.app.state.auth_service.repo.delete_user(user.user_id)}
