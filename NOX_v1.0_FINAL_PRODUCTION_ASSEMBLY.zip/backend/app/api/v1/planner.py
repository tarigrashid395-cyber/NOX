from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from backend.app.api.deps import get_container, get_current_user
from backend.app.core.container import Container
from backend.app.security.auth import CurrentUser
from backend.app.agents.planner.planner_models import ExecutionPlan

class PlannerRequest(BaseModel):
    goal: str = Field(min_length=1, max_length=20000)
    conversation_id: UUID | None = None

router=APIRouter(prefix="/planner", tags=["planner"])

@router.post("/plan", response_model=ExecutionPlan)
async def create_plan(body: PlannerRequest, container: Container=Depends(get_container), user: CurrentUser=Depends(get_current_user)):
    plan=await container.planner_service.plan(body.goal,user.user_id,body.conversation_id)
    return await container.planner_service.save(plan)

@router.get("/{plan_id}", response_model=ExecutionPlan)
async def get_plan(plan_id: UUID, container: Container=Depends(get_container), user: CurrentUser=Depends(get_current_user)):
    plan=await container.planner_service.get(plan_id,user.user_id)
    if plan is None: raise HTTPException(404,"Execution plan not found")
    return plan
