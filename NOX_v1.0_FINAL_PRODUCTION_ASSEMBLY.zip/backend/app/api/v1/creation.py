from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException
from backend.app.api.deps import get_container, get_current_user
from backend.app.core.container import Container
from backend.app.security.auth import CurrentUser
from backend.app.creation.schemas import CreationRequest, CreationResult
router=APIRouter(prefix='/create',tags=['creation'])
@router.post('',response_model=CreationResult)
async def create(body:CreationRequest,container:Container=Depends(get_container),user:CurrentUser=Depends(get_current_user)):
    return await container.creation.create(user.user_id,body,body.options.get('format','json'))

def _typed(creation_type):
    async def handler(body:CreationRequest,container:Container=Depends(get_container),user:CurrentUser=Depends(get_current_user)):
        if body.creation_type!=creation_type: body=body.model_copy(update={'creation_type':creation_type})
        return await container.creation.create(user.user_id,body,body.options.get('format','json'))
    return handler
router.post('/course',response_model=CreationResult)(_typed('course'))
router.post('/infographic',response_model=CreationResult)(_typed('infographic'))
router.post('/storyboard',response_model=CreationResult)(_typed('storyboard'))
router.post('/presentation',response_model=CreationResult)(_typed('presentation'))
@router.get('/history')
async def history(container:Container=Depends(get_container),user:CurrentUser=Depends(get_current_user)): return await container.creation.history(user.user_id)
@router.get('/{project_id}',response_model=object)
async def get_creation(project_id:UUID,container:Container=Depends(get_container),user:CurrentUser=Depends(get_current_user)):
    result=await container.creation.get(user.user_id,project_id)
    if result is None: raise HTTPException(404,'Creation project not found')
    return result
