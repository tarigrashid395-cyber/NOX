from uuid import UUID, uuid4
from time import perf_counter
from pydantic import BaseModel, Field
from fastapi import APIRouter, Depends
from backend.app.api.deps import get_container,get_current_user
from backend.app.security.auth import CurrentUser
from backend.app.providers.llm.base import LLMRequest, LLMMessage
class ChatRequest(BaseModel): message:str=Field(min_length=1); conversation_id:UUID|None=None
class ChatResponse(BaseModel): conversation_id:UUID; content:str; citations:list[dict]=[]; artifacts:list[dict]=[]; warnings:list[str]=[]
router=APIRouter(prefix='/chat',tags=['chat'])
_store={}
@router.post('',response_model=ChatResponse)
async def chat(body:ChatRequest,container=Depends(get_container),user:CurrentUser=Depends(get_current_user)):
    cid=body.conversation_id or uuid4(); key=(user.user_id,cid); history=_store.setdefault(key,[]); history.append({'role':'user','content':body.message})
    started=perf_counter()
    try:
        result=await container.supervisor.handle(user.user_id,body.message,cid)
        if container.llm:
            messages=[LLMMessage(role="system",content="You are NOX. Answer accurately, clearly, and acknowledge uncertainty. Preserve any evidence/citations supplied by the orchestration layer.")]
            messages.extend(LLMMessage(role=m["role"],content=m["content"]) for m in history[-12:] if m.get("role") in {"user","assistant"})
            response=await container.llm.complete(LLMRequest(messages=messages,max_tokens=2048))
            result.content=response.content
        await container.analytics.record(user.user_id,container.analytics_event('chat.request',category='usage',value=1,success=True,latency_ms=(perf_counter()-started)*1000))
    except Exception:
        await container.analytics.record(user.user_id,container.analytics_event('chat.request',category='usage',value=1,success=False,latency_ms=(perf_counter()-started)*1000))
        raise
    history.append({'role':'assistant','content':result.content})
    return ChatResponse(conversation_id=cid,content=result.content,citations=result.citations,artifacts=result.artifacts,warnings=result.warnings)
@router.get('/conversations')
async def conversations(user:CurrentUser=Depends(get_current_user)):
    rows=[]
    for (uid,cid),history in _store.items():
        if uid==user.user_id and history:
            rows.append({'id':str(cid),'title':history[0]['content'][:70],'updated_at':history[-1]['content']})
    return {'items':rows}
@router.get('/conversations/{conversation_id}')
async def conversation(conversation_id:UUID,user:CurrentUser=Depends(get_current_user)):
    return {'id':str(conversation_id),'messages':_store.get((user.user_id,conversation_id),[])}
