from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException, Query
from backend.app.api.deps import get_container, get_current_user
from backend.app.schemas.visual import VisualRequest
from backend.app.security.auth import CurrentUser
router=APIRouter(prefix="/visual",tags=["visual"])

@router.post("/create")
async def create_visual(request:VisualRequest, container=Depends(get_container), user:CurrentUser=Depends(get_current_user)):
    return await container.visual.create(user.user_id,request,request.options.get("format","json"))

@router.get("/{artifact_id}")
async def get_visual(artifact_id:UUID,container=Depends(get_container),user:CurrentUser=Depends(get_current_user)):
    item=await container.visual.get(user.user_id,artifact_id)
    if not item: raise HTTPException(404,"Visual artifact not found")
    return {"id":str(item.id),"user_id":str(item.user_id),"visual_type":item.visual_type,"title":item.title,"schema_version":item.schema_version,"payload":item.payload,"source_refs":item.source_refs,"created_at":item.created_at.isoformat()}

@router.get("/history/list")
async def visual_history(limit:int=Query(50,ge=1,le=100),container=Depends(get_container),user:CurrentUser=Depends(get_current_user)):
    rows=await container.visual.repository.list(user.user_id,limit)
    return {"items":[{"id":str(x.id),"visual_type":x.visual_type,"title":x.title,"created_at":x.created_at.isoformat()} for x in rows]}
