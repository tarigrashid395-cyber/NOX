from __future__ import annotations
from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from backend.app.api.deps import get_container,get_current_user
from backend.app.core.container import Container
from backend.app.security.auth import CurrentUser
from backend.app.agents.workforce.agent_models import AgentExecutionRequest

router=APIRouter(prefix='/agents',tags=['agents'])
@router.post('/execute')
async def execute(body:AgentExecutionRequest,container:Container=Depends(get_container),user:CurrentUser=Depends(get_current_user)):
    return await container.workforce.execute(user.user_id,body)
class TeamRequest(AgentExecutionRequest):
    agent_ids:list[str]=Field(default_factory=list)
@router.post('/team')
async def team(body:TeamRequest,container:Container=Depends(get_container),user:CurrentUser=Depends(get_current_user)):
    if body.agent_ids: body.preferred_agents=body.agent_ids; body.mode='team'; body.max_agents=len(body.agent_ids)
    else: body.mode='team'
    return await container.workforce.execute(user.user_id,body)
@router.get('')
async def list_agents(container:Container=Depends(get_container),user:CurrentUser=Depends(get_current_user)): return {'agents':[x.model_dump(mode='json') for x in container.workforce.definitions()]}
@router.get('/{agent_id}')
async def get_agent(agent_id:str,container:Container=Depends(get_container),user:CurrentUser=Depends(get_current_user)):
    try:return container.workforce.registry.get(agent_id)[0]
    except KeyError:raise HTTPException(404,'Agent not found')
