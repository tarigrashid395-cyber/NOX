from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException
from backend.app.api.deps import get_container, get_current_user
from backend.app.core.container import Container
from backend.app.security.auth import CurrentUser
from backend.app.schemas.research import ResearchRequest, ResearchResult, ResearchHistoryItem

router=APIRouter(prefix="/research",tags=["research"])

@router.post("/query",response_model=ResearchResult)
async def research_query(body:ResearchRequest,container:Container=Depends(get_container),user:CurrentUser=Depends(get_current_user)):
    return await container.research.run(user.user_id,body)

@router.post("/report",response_model=ResearchResult)
async def research_report(body:ResearchRequest,container:Container=Depends(get_container),user:CurrentUser=Depends(get_current_user)):
    body=body.model_copy(update={"include_report":True})
    return await container.research.run(user.user_id,body)

@router.get("/history",response_model=list[ResearchHistoryItem])
async def research_history(container:Container=Depends(get_container),user:CurrentUser=Depends(get_current_user)):
    return await container.research.history(user.user_id)

@router.get("/{research_id}",response_model=ResearchResult)
async def research_get(research_id:UUID,container:Container=Depends(get_container),user:CurrentUser=Depends(get_current_user)):
    result=await container.research.get(user.user_id,research_id)
    if result is None: raise HTTPException(status_code=404,detail="Research run not found")
    return result
