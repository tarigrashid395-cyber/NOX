from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException, Query
from backend.app.api.deps import get_container, get_current_user
from backend.app.core.container import Container
from backend.app.security.auth import CurrentUser
from backend.app.motion.schemas import MotionRequest, MotionResult
router=APIRouter(prefix='/motion',tags=['motion'])
@router.post('/create',response_model=MotionResult)
async def create_motion(body:MotionRequest,container:Container=Depends(get_container),user:CurrentUser=Depends(get_current_user)):
    return await container.motion.create(user.user_id,body,body.options.get('format','json'))
@router.get('/history')
async def motion_history(container:Container=Depends(get_container),user:CurrentUser=Depends(get_current_user)):
    return await container.motion.history(user.user_id)
@router.get('/{project_id}',response_model=object)
async def motion_get(project_id:UUID,container:Container=Depends(get_container),user:CurrentUser=Depends(get_current_user)):
    result=await container.motion.get(user.user_id,project_id)
    if result is None: raise HTTPException(404,'Motion project not found')
    return result
