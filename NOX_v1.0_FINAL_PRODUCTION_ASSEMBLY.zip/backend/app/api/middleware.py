import time
from uuid import uuid4
from starlette.middleware.base import BaseHTTPMiddleware
from backend.app.logging import trace_id_var
class TraceMiddleware(BaseHTTPMiddleware):
    async def dispatch(self,request,call_next):
        token=trace_id_var.set(str(uuid4())); start=time.perf_counter()
        try:
            response=await call_next(request); response.headers['X-Trace-ID']=trace_id_var.get() or ''; return response
        finally: trace_id_var.reset(token)


class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    def __init__(self, app, production: bool = False):
        super().__init__(app)
        self.production = production

    async def dispatch(self, request, call_next):
        response = await call_next(request)
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("X-Frame-Options", "DENY")
        response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
        response.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
        if self.production:
            response.headers.setdefault("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
        return response
