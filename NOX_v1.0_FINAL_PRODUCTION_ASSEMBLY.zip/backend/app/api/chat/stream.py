from __future__ import annotations
import asyncio
import json
from time import perf_counter
from uuid import UUID, uuid4
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
from backend.app.api.deps import get_container, get_current_user
from backend.app.security.auth import CurrentUser
from backend.app.providers.llm.base import LLMMessage, LLMRequest

router=APIRouter(prefix="/chat", tags=["chat-stream"])

class StreamChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=100000)
    conversation_id: UUID | None = None

async def _event(kind: str, payload: dict) -> str:
    return f"event: {kind}\ndata: {json.dumps(payload, ensure_ascii=False)}\n\n"

@router.post("/stream")
async def stream_chat(body: StreamChatRequest, container=Depends(get_container), user: CurrentUser=Depends(get_current_user)):
    if container.llm is None:
        raise HTTPException(503, "No streaming-capable LLM provider is configured")
    cid=body.conversation_id or uuid4()
    started=perf_counter()
    key=(user.user_id,cid)
    # The canonical chat store remains owned by chat.py; importing it avoids a second conversation store.
    from backend.app.api.v1.chat import _store
    history=_store.setdefault(key,[])
    history.append({"role":"user","content":body.message})
    queue: asyncio.Queue[tuple[str,dict] | None]=asyncio.Queue()
    async def progress(kind,label,**extra): await queue.put((kind,{"label":label,"conversation_id":str(cid),**extra}))
    async def orchestrate():
        try:
            await progress("status","Thinking",phase="thinking")
            callback=lambda event: progress(event["type"],event.get("label",event["type"]),**{k:v for k,v in event.items() if k not in {"type","label"}})
            result=await container.supervisor.handle(user.user_id,body.message,cid,event_sink=callback)
            await progress("status","Writing",phase="writing")
            messages=[LLMMessage(role="system",content="You are NOX. Answer accurately, clearly, and acknowledge uncertainty. Preserve evidence and citations supplied by orchestration. Stream the final answer directly.")]
            messages.extend(LLMMessage(role=m["role"],content=m["content"]) for m in history[-12:] if m.get("role") in {"user","assistant"})
            messages.append(LLMMessage(role="system",content=result.content))
            tokens=0
            streamed_parts=[]
            async for delta in container.llm.stream(LLMRequest(messages=messages,max_tokens=2048)):
                tokens += 1
                streamed_parts.append(delta)
                await queue.put(("token",{"delta":delta,"index":tokens}))
            history.append({"role":"assistant","content":result.content})
            await queue.put(("done",{"conversation_id":str(cid),"citations":result.citations,"artifacts":result.artifacts,"warnings":result.warnings,"tokens_streamed":tokens,"generation_time_ms":(perf_counter()-started)*1000}))
            await container.analytics.record(user.user_id,container.analytics_event("stream.completed",category="usage",value=float(tokens),success=True,latency_ms=(perf_counter()-started)*1000))
        except Exception as exc:
            await queue.put(("error",{"message":str(exc)}))
            await container.analytics.record(user.user_id,container.analytics_event("stream.completed",category="usage",value=0,success=False,latency_ms=(perf_counter()-started)*1000))
        finally:
            await queue.put(None)
    task=asyncio.create_task(orchestrate())
    async def generate():
        try:
            while True:
                item=await queue.get()
                if item is None: break
                kind,payload=item
                yield await _event(kind,payload)
        finally:
            if not task.done(): task.cancel()
    return StreamingResponse(generate(),media_type="text/event-stream",headers={"Cache-Control":"no-cache","Connection":"keep-alive","X-Accel-Buffering":"no"})
