from fastapi import Request
from fastapi.responses import JSONResponse
from backend.app.core.exceptions import NoxError
async def nox_error_handler(request:Request, exc:NoxError):
    return JSONResponse(status_code=exc.status_code,content={'code':exc.code,'message':str(exc) or exc.code})
