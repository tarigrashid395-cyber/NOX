from uuid import UUID
from fastapi import Request, Header, HTTPException
from backend.app.core.container import Container
from backend.app.security.auth import CurrentUser

def get_container(request:Request)->Container: return request.app.state.container

async def get_current_user(request:Request, authorization: str | None = Header(default=None)) -> CurrentUser:
    service=getattr(request.app.state,"auth_service",None)
    if not authorization:
        settings=getattr(getattr(request.app.state,'container',None),'settings',None)
        if service is None or getattr(settings,'app_env','development') in {'development','test'}:
            return CurrentUser(UUID('00000000-0000-0000-0000-000000000001'),'dev@nox.local','user')
        raise HTTPException(401,'Authentication required')
    if not authorization.lower().startswith('bearer '): raise HTTPException(401,'Authentication required')
    if service is None: raise HTTPException(503,'Authentication service unavailable')
    try:return await service.current(authorization.split(' ',1)[1])
    except PermissionError as exc: raise HTTPException(401,str(exc)) from exc
