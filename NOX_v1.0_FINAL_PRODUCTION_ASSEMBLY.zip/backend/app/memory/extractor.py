from __future__ import annotations
from dataclasses import dataclass
from uuid import UUID
from backend.app.domain.memories import MemoryType
from backend.app.memory.policies import validate_content

@dataclass(frozen=True)
class MemoryCandidate:
    user_id: UUID
    memory_type: MemoryType
    content: str
    importance: float=0.5
    confidence: float=1.0
    tags: tuple[str,...]=()
    metadata: dict | None=None
    source: str="conversation"

def extract_conversation_memory(user_id: UUID, conversation_id: UUID, text: str) -> MemoryCandidate:
    return MemoryCandidate(user_id, MemoryType.CONVERSATION, validate_content(text), metadata={"conversation_id":str(conversation_id)})
