from __future__ import annotations
from backend.app.domain.memories import MemoryType

MAX_CONTENT_LENGTH=100_000
MERGE_SIMILARITY_THRESHOLD=0.92
DEFAULT_LIMIT=10

ALLOWED_TYPES=set(MemoryType)

def validate_content(content: str) -> str:
    value=" ".join(content.strip().split())
    if not value: raise ValueError("Memory content cannot be empty")
    if len(value)>MAX_CONTENT_LENGTH: raise ValueError("Memory content exceeds maximum length")
    return value
