from __future__ import annotations
from backend.app.memory.compressor import summarize_conversation, compress_context, consolidate_knowledge

class MemoryWorkflow:
    def __init__(self,lifecycle,retriever): self.lifecycle=lifecycle; self.retriever=retriever
    async def store(self,*args,**kwargs): return await self.lifecycle.create(*args,**kwargs)
    async def search(self,*args,**kwargs): return await self.retriever.hybrid_retrieval(*args,**kwargs)
    async def summarize(self,messages): return summarize_conversation(messages)
    async def compress(self,items,max_chars=6000): return compress_context(items,max_chars)
    async def consolidate(self,items): return consolidate_knowledge(items)
