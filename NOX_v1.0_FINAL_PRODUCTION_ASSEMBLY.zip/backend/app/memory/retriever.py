from __future__ import annotations
from typing import Any
from backend.app.memory.ranker import rank_candidates
from backend.app.domain.memories import MemoryType

class MemoryRetriever:
    def __init__(self, repository, vector_store=None, embedder=None): self.repository=repository; self.vector_store=vector_store; self.embedder=embedder
    async def context_retrieval(self,user_id,query,limit=10):
        return await self.repository.search_lexical(user_id,query,[],limit)
    async def semantic_retrieval(self,user_id,query,memory_types=None,limit=10):
        if not self.vector_store or not self.embedder: return []
        try:
            vector=await self.embedder.embed(query)
            return await self.vector_store.search(vector,limit,{"user_id":user_id,"memory_types":memory_types or []})
        except Exception:
            return []
    async def hybrid_retrieval(self,user_id,query,memory_types=None,limit=10,**weights):
        lexical=await self.repository.search_lexical(user_id,query,memory_types or [],max(limit*3,limit))
        semantic=await self.semantic_retrieval(user_id,query,memory_types, max(limit*3,limit))
        merged={x["id"]:dict(x) for x in lexical}
        for x in semantic:
            merged.setdefault(x["id"],{})
            merged[x["id"]].update(x)
        weights.pop("include_archived", None)
        return rank_candidates([x for x in merged.values() if "content" in x],query,**weights)[:limit]
