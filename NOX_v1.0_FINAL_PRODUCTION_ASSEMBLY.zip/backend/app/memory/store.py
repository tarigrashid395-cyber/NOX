from __future__ import annotations
from abc import ABC, abstractmethod
from datetime import datetime, timezone
from uuid import UUID, uuid4
from typing import Any
from sqlalchemy import delete, select, update
from sqlalchemy.ext.asyncio import async_sessionmaker, AsyncSession
from backend.app.domain.memories import MemoryType
from backend.app.memory.models import MemoryRecord

class MemoryRepository(ABC):
    @abstractmethod
    async def create(self, data: dict[str,Any]) -> dict[str,Any]: ...
    @abstractmethod
    async def get(self, user_id: UUID, memory_id: UUID, include_archived=False) -> dict[str,Any] | None: ...
    @abstractmethod
    async def list_user(self, user_id: UUID, include_archived=False, limit=100) -> list[dict[str,Any]]: ...
    @abstractmethod
    async def search_lexical(self, user_id: UUID, query: str, memory_types: list[MemoryType], limit: int, include_archived=False) -> list[dict[str,Any]]: ...
    @abstractmethod
    async def update(self, user_id: UUID, memory_id: UUID, data: dict[str,Any]) -> dict[str,Any] | None: ...
    @abstractmethod
    async def archive(self, user_id: UUID, memory_id: UUID) -> bool: ...
    @abstractmethod
    async def delete(self, user_id: UUID, memory_id: UUID) -> bool: ...

class PostgresMemoryRepository(MemoryRepository):
    def __init__(self, session_factory: async_sessionmaker[AsyncSession] | None): self.session_factory=session_factory
    def _sessions(self):
        if self.session_factory is None:
            raise RuntimeError("PostgreSQL memory storage is unavailable")
        return self.session_factory()
    @staticmethod
    def _to_dict(r: MemoryRecord)->dict[str,Any]:
        return {"id":r.id,"user_id":r.user_id,"memory_type":MemoryType(r.memory_type),"content":r.content,"importance":r.importance,"confidence":r.confidence,"tags":r.tags or [],"metadata":r.metadata_json or {},"source":r.source,"conversation_id":r.conversation_id,"project_id":r.project_id,"source_uri":r.source_uri,"goal_status":r.goal_status,"target_date":r.target_date,"created_at":r.created_at,"updated_at":r.updated_at,"archived_at":r.archived_at}
    async def create(self,data):
        r=MemoryRecord(**data)
        async with self._sessions() as session:
            session.add(r)
            await session.commit()
            await session.refresh(r)
            return self._to_dict(r)
    async def get(self,user_id,memory_id,include_archived=False):
        async with self._sessions() as s:
            stmt=select(MemoryRecord).where(MemoryRecord.id==memory_id,MemoryRecord.user_id==user_id)
            if not include_archived: stmt=stmt.where(MemoryRecord.archived_at.is_(None))
            r=(await s.execute(stmt)).scalar_one_or_none(); return self._to_dict(r) if r else None
    async def list_user(self,user_id,include_archived=False,limit=100):
        async with self._sessions() as s:
            stmt=select(MemoryRecord).where(MemoryRecord.user_id==user_id).order_by(MemoryRecord.updated_at.desc()).limit(limit)
            if not include_archived: stmt=stmt.where(MemoryRecord.archived_at.is_(None))
            return [self._to_dict(r) for r in (await s.execute(stmt)).scalars()]
    async def search_lexical(self,user_id,query,memory_types,limit,include_archived=False):
        async with self._sessions() as s:
            stmt=select(MemoryRecord).where(MemoryRecord.user_id==user_id)
            if not include_archived: stmt=stmt.where(MemoryRecord.archived_at.is_(None))
            if memory_types: stmt=stmt.where(MemoryRecord.memory_type.in_([str(x) for x in memory_types]))
            terms=[t for t in query.lower().split() if t]
            if terms:
                stmt=stmt.where(*[MemoryRecord.content.ilike(f"%{t}%") for t in terms])
            rows=list((await s.execute(stmt.order_by(MemoryRecord.updated_at.desc()).limit(limit))).scalars())
            return [self._to_dict(r)|{"lexical_score":sum(t in r.content.lower() for t in terms)/max(1,len(terms))} for r in rows]
    async def update(self,user_id,memory_id,data):
        data["updated_at"]=datetime.now(timezone.utc)
        async with self._sessions() as s:
            await s.execute(update(MemoryRecord).where(MemoryRecord.id==memory_id,MemoryRecord.user_id==user_id).values(**data)); await s.commit()
        return await self.get(user_id,memory_id,include_archived=True)
    async def archive(self,user_id,memory_id): return bool(await self.update(user_id,memory_id,{"archived_at":datetime.now(timezone.utc)}))
    async def delete(self,user_id,memory_id):
        async with self._sessions() as s:
            result=await s.execute(delete(MemoryRecord).where(MemoryRecord.id==memory_id,MemoryRecord.user_id==user_id)); await s.commit(); return result.rowcount>0

class InMemoryMemoryRepository(MemoryRepository):
    def __init__(self): self.items={}
    async def create(self,data):
        data=dict(data); data.setdefault("id",uuid4()); now=datetime.now(timezone.utc); data.setdefault("created_at",now); data.setdefault("updated_at",now); data.setdefault("archived_at",None); self.items[data["id"]]=data; return dict(data)
    async def get(self,user_id,memory_id,include_archived=False):
        x=self.items.get(memory_id); return dict(x) if x and x["user_id"]==user_id and (include_archived or not x.get("archived_at")) else None
    async def list_user(self,user_id,include_archived=False,limit=100):
        xs=[x for x in self.items.values() if x["user_id"]==user_id and (include_archived or not x.get("archived_at"))]; xs.sort(key=lambda x:x.get("updated_at"),reverse=True); return [dict(x) for x in xs[:limit]]
    async def search_lexical(self,user_id,query,memory_types,limit,include_archived=False):
        terms=[t.lower() for t in query.split() if t]; xs=[]
        for x in self.items.values():
            if x["user_id"]!=user_id or (not include_archived and x.get("archived_at")) or (memory_types and x["memory_type"] not in memory_types): continue
            score=sum(t in x["content"].lower() for t in terms)/max(1,len(terms));
            if score>0: xs.append(dict(x)|{"lexical_score":score})
        xs.sort(key=lambda x:x["lexical_score"],reverse=True); return xs[:limit]
    async def update(self,user_id,memory_id,data):
        x=await self.get(user_id,memory_id,True)
        if not x:return None
        x.update(data); x["updated_at"]=datetime.now(timezone.utc); self.items[memory_id]=x; return dict(x)
    async def archive(self,user_id,memory_id): return bool(await self.update(user_id,memory_id,{"archived_at":datetime.now(timezone.utc)}))
    async def delete(self,user_id,memory_id):
        x=await self.get(user_id,memory_id,True)
        if not x:return False
        del self.items[memory_id]; return True
