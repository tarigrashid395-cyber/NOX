from __future__ import annotations

def summarize_conversation(messages: list[str], max_chars: int = 2000) -> str:
    cleaned = [" ".join(m.split()) for m in messages if m and m.strip()]
    if not cleaned:
        return ""
    text = " ".join(cleaned)
    if len(text) <= max_chars:
        return text
    sentences = []
    for part in text.replace("! ", "!| ").replace("? ", "?| ").replace(". ", ".| ").split("|"):
        if part.strip():
            sentences.append(part.strip())
    selected = sentences[: max(1, max_chars // 180)]
    result = " ".join(selected)
    return result[:max_chars].rstrip() + "…"

def compress_context(items: list[str], max_chars: int = 6000) -> str:
    text = "\n".join(x.strip() for x in items if x and x.strip())
    if len(text) <= max_chars:
        return text
    return text[:max_chars].rsplit(" ", 1)[0] + "…"

def consolidate_knowledge(items: list[str], max_items: int = 20) -> list[str]:
    unique: list[str] = []
    seen: set[str] = set()
    for item in items:
        normalized = " ".join(item.split()).lower()
        if normalized and normalized not in seen:
            seen.add(normalized)
            unique.append(item.strip())
        if len(unique) >= max_items:
            break
    return unique
