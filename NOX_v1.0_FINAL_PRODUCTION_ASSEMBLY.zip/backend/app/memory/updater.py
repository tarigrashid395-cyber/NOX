from __future__ import annotations
from datetime import datetime, timezone
from uuid import UUID
from backend.app.domain.memories import MemoryType
from backend.app.memory.policies import validate_content
import logging

logger=logging.getLogger(__name__)

class MemoryLifecycle:
    def __init__(self, repository, vector_store=None, embedder=None): self.repository=repository; self.vector_store=vector_store; self.embedder=embedder
    async def create(self,user_id:UUID,memory_type:MemoryType,content:str,**kwargs):
        data={"id":kwargs.pop("id",None) or __import__("uuid").uuid4(),"user_id":user_id,"memory_type":memory_type,"content":validate_content(content),**kwargs}
        item=await self.repository.create(data)
        try:
            await self._index(item)
        except Exception as exc:
            logger.warning("memory vector indexing failed", exc_info=exc)
        return item
    async def update(self,user_id,memory_id,**changes):
        if "content" in changes: changes["content"]=validate_content(changes["content"])
        item=await self.repository.update(user_id,memory_id,changes)
        if item:
            try:
                await self._index(item)
            except Exception as exc:
                logger.warning("memory vector re-index failed", exc_info=exc)
        return item
    async def merge(self,user_id,memory_ids:list[UUID],content:str,**kwargs):
        if not memory_ids: raise ValueError("memory_ids cannot be empty")
        first=await self.repository.get(user_id,memory_ids[0],True)
        if not first: raise ValueError("source memory not found")
        merged=await self.create(user_id,first["memory_type"],content,metadata={"merged_from":[str(x) for x in memory_ids]},**kwargs)
        for mid in memory_ids: await self.archive(user_id,mid)
        return merged
    async def archive(self,user_id,memory_id):
        item=await self.repository.update(user_id,memory_id,{"archived_at":datetime.now(timezone.utc)})
        if item and self.vector_store: await self.vector_store.delete(memory_id)
        return item
    async def delete(self,user_id,memory_id):
        ok=await self.repository.delete(user_id,memory_id)
        if ok and self.vector_store: await self.vector_store.delete(memory_id)
        return ok
    async def _index(self,item):
        if self.vector_store and self.embedder:
            vector=await self.embedder.embed(item["content"])
            await self.vector_store.ensure_collection(len(vector))
            payload={
                "user_id":str(item["user_id"]),
                "memory_type":str(item["memory_type"]),
                "content":item["content"],
                "importance":float(item.get("importance",0.5)),
                "confidence":float(item.get("confidence",1.0)),
                "tags":list(item.get("tags",[])),
                "metadata":item.get("metadata",{}),
                "source":item.get("source","user"),
                "conversation_id":str(item["conversation_id"]) if item.get("conversation_id") else None,
                "project_id":str(item["project_id"]) if item.get("project_id") else None,
            }
            await self.vector_store.upsert(item["id"],vector,payload)
