from __future__ import annotations
from datetime import datetime, timezone
from math import exp
from typing import Iterable
from backend.app.schemas.memory import MemoryResult

def lexical_score(query: str, content: str) -> float:
    q={x.lower() for x in query.split() if x.strip()}
    c={x.lower() for x in content.split() if x.strip()}
    if not q: return 0.0
    return len(q & c)/len(q)

def recency_score(created_at) -> float:
    if created_at is None: return 0.0
    now=datetime.now(timezone.utc)
    if created_at.tzinfo is None: created_at=created_at.replace(tzinfo=timezone.utc)
    days=max(0.0,(now-created_at).total_seconds()/86400)
    return exp(-days/30.0)

def rank_candidates(candidates: Iterable[dict], query: str, *, semantic_weight=.65, lexical_weight=.20, recency_weight=.10, importance_weight=.05) -> list[MemoryResult]:
    out=[]
    for item in candidates:
        sem=float(item.get("semantic_score", item.get("score",0.0)))
        lex=float(item.get("lexical_score", lexical_score(query,item["content"])))
        rec=float(item.get("recency_score", recency_score(item.get("created_at"))))
        imp=float(item.get("importance", item.get("importance_score",0.5)))
        score=semantic_weight*sem+lexical_weight*lex+recency_weight*rec+importance_weight*imp
        out.append(MemoryResult(id=item["id"],user_id=item["user_id"],memory_type=item["memory_type"],content=item["content"],score=score,semantic_score=sem,lexical_score=lex,recency_score=rec,importance_score=imp,metadata=item.get("metadata",{}),tags=item.get("tags",[]),created_at=item.get("created_at"),updated_at=item.get("updated_at"),archived_at=item.get("archived_at")))
    return sorted(out,key=lambda x:(x.score,x.importance_score),reverse=True)
