from __future__ import annotations
from datetime import datetime
from typing import Any
from uuid import UUID
from sqlalchemy import DateTime, Float, Index, String, Text, JSON
from sqlalchemy.types import UserDefinedType

class VectorType(UserDefinedType):
    cache_ok=True
    def __init__(self, dimension:int): self.dimension=dimension
    def get_col_spec(self, **kw): return f"vector({self.dimension})"
    def bind_processor(self, dialect):
        def process(value):
            if value is None: return None
            return "[" + ",".join(str(float(v)) for v in value) + "]" if isinstance(value,(list,tuple)) else value
        return process
from sqlalchemy.orm import Mapped, mapped_column
from backend.app.db.base import Base

class MemoryRecord(Base):
    __tablename__ = "memories"
    id: Mapped[UUID] = mapped_column(primary_key=True)
    user_id: Mapped[UUID] = mapped_column(index=True)
    memory_type: Mapped[str] = mapped_column(String(32), index=True)
    content: Mapped[str] = mapped_column(Text)
    importance: Mapped[float] = mapped_column(Float, default=0.5)
    confidence: Mapped[float] = mapped_column(Float, default=1.0)
    tags: Mapped[list[str]] = mapped_column(JSON, default=list)
    metadata_json: Mapped[dict[str, Any]] = mapped_column("metadata", JSON, default=dict)
    source: Mapped[str] = mapped_column(String(128), default="user")
    conversation_id: Mapped[UUID | None] = mapped_column(index=True, nullable=True)
    project_id: Mapped[UUID | None] = mapped_column(index=True, nullable=True)
    source_uri: Mapped[str | None] = mapped_column(String(2048), nullable=True)
    goal_status: Mapped[str | None] = mapped_column(String(64), nullable=True)
    target_date: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    embedding: Mapped[list[float] | None] = mapped_column(VectorType(1536), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow)
    archived_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    __table_args__=(Index("ix_memories_user_type", "user_id", "memory_type"),)
