from backend.app.evaluation.schemas import AdaptiveProfile,AnalyticsDashboard
class AdaptiveIntelligence:
    def profile(self,dashboard:AnalyticsDashboard)->AdaptiveProfile:
        reasons=[]
        if dashboard.learning.get('success_rate',0)<.7: reasons.append('increase scaffolding and practice')
        if dashboard.research.get('events',0)>10: reasons.append('deepen research defaults')
        if dashboard.usage.get('latency_ms',0)>2000: reasons.append('prefer concise outputs')
        return AdaptiveProfile(explanation_level='guided' if dashboard.learning.get('success_rate',0)<.7 else 'balanced',visual_density='detailed' if dashboard.learning.get('events',0)>5 else 'balanced',motion_intensity='minimal',research_depth='deep' if dashboard.research.get('events',0)>10 else 'standard',learning_mode='adaptive',rationale=reasons)
