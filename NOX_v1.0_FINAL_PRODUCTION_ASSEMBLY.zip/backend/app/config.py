from functools import lru_cache
from pydantic import Field, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_name: str = "NOX"
    app_env: str = Field(default="development", validation_alias="APP_ENV")
    app_secret_key: str = Field(default="change-me-in-development", validation_alias="APP_SECRET_KEY")
    database_url: str = Field(default="postgresql+asyncpg://nox:nox@localhost:5432/nox", validation_alias="DATABASE_URL")
    supabase_url: str = Field(default="", validation_alias="SUPABASE_URL")
    supabase_anon_key: str = Field(default="", validation_alias="SUPABASE_ANON_KEY")
    supabase_service_role_key: str = Field(default="", validation_alias="SUPABASE_SERVICE_ROLE_KEY")
    supabase_storage_bucket: str = Field(default="nox", validation_alias="SUPABASE_STORAGE_BUCKET")
    storage_provider: str = Field(default="minio", validation_alias="STORAGE_PROVIDER")
    database_pool_size: int = Field(default=10, validation_alias="DATABASE_POOL_SIZE")
    database_max_overflow: int = Field(default=20, validation_alias="DATABASE_MAX_OVERFLOW")
    redis_provider: str = Field(default="redis", validation_alias="REDIS_PROVIDER")
    redis_url: str = Field(default="redis://localhost:6379/0", validation_alias="REDIS_URL")
    upstash_redis_rest_url: str = Field(default="", validation_alias="UPSTASH_REDIS_REST_URL")
    upstash_redis_rest_token: str = Field(default="", validation_alias="UPSTASH_REDIS_REST_TOKEN")
    redis_timeout_seconds: float = Field(default=5.0, validation_alias="REDIS_TIMEOUT_SECONDS")
    redis_max_retries: int = Field(default=3, validation_alias="REDIS_MAX_RETRIES")
    redis_retry_backoff_seconds: float = Field(default=0.25, validation_alias="REDIS_RETRY_BACKOFF_SECONDS")
    redis_poll_interval_seconds: float = Field(default=0.25, validation_alias="REDIS_POLL_INTERVAL_SECONDS")
    s3_endpoint: str = Field(default="http://localhost:9000", validation_alias="S3_ENDPOINT")
    s3_access_key: str = Field(default="nox", validation_alias="S3_ACCESS_KEY")
    s3_secret_key: str = Field(default="noxsecret", validation_alias="S3_SECRET_KEY")
    s3_bucket: str = Field(default="nox", validation_alias="S3_BUCKET")
    cors_origins: list[str] = Field(default=["http://localhost:3000"], validation_alias="CORS_ORIGINS")
    log_level: str = Field(default="INFO", validation_alias="LOG_LEVEL")
    max_upload_bytes: int = Field(default=50_000_000, validation_alias="MAX_UPLOAD_BYTES")
    embedding_dimension: int = Field(default=1536, validation_alias="EMBEDDING_DIMENSION")
    session_ttl_seconds: int = Field(default=86_400, validation_alias="SESSION_TTL_SECONDS")
    queue_enabled: bool = Field(default=True, validation_alias="QUEUE_ENABLED")
    qdrant_url: str = Field(default="http://localhost:6333", validation_alias="QDRANT_URL")
    qdrant_api_key: str = Field(default="", validation_alias="QDRANT_API_KEY")
    qdrant_collection: str = Field(default="nox_memories", validation_alias="QDRANT_COLLECTION")
    qdrant_timeout_seconds: float = Field(default=5.0, validation_alias="QDRANT_TIMEOUT_SECONDS")
    google_client_id: str|None = Field(default=None, validation_alias="GOOGLE_CLIENT_ID")
    google_redirect_uri: str|None = Field(default=None, validation_alias="GOOGLE_REDIRECT_URI")
    github_client_id: str|None = Field(default=None, validation_alias="GITHUB_CLIENT_ID")
    github_redirect_uri: str|None = Field(default=None, validation_alias="GITHUB_REDIRECT_URI")
    openai_api_key: str|None = Field(default=None, validation_alias="OPENAI_API_KEY")
    openai_model: str = Field(default="gpt-5.6", validation_alias="OPENAI_MODEL")
    openai_base_url: str = Field(default="https://api.openai.com/v1", validation_alias="OPENAI_BASE_URL")
    anthropic_api_key: str|None = Field(default=None, validation_alias="ANTHROPIC_API_KEY")
    anthropic_model: str = Field(default="claude-sonnet-4-5", validation_alias="ANTHROPIC_MODEL")
    anthropic_base_url: str = Field(default="https://api.anthropic.com/v1", validation_alias="ANTHROPIC_BASE_URL")
    llm_timeout_seconds: float = Field(default=30.0, validation_alias="LLM_TIMEOUT_SECONDS")
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore", case_sensitive=False, populate_by_name=True)

    @model_validator(mode="after")
    def validate_runtime_security(self):
        if self.app_env.lower() in {"production", "prod"}:
            if self.app_secret_key == "change-me-in-development" or len(self.app_secret_key) < 32:
                raise ValueError("APP_SECRET_KEY must be a unique value of at least 32 characters in production")
            if not self.database_url:
                raise ValueError("DATABASE_URL is required in production")
            if not self.supabase_url or not self.supabase_anon_key or not self.supabase_service_role_key:
                raise ValueError("SUPABASE_URL, SUPABASE_ANON_KEY and SUPABASE_SERVICE_ROLE_KEY are required in production")
            if self.storage_provider.lower() == "supabase" and not self.supabase_service_role_key:
                raise ValueError("SUPABASE_SERVICE_ROLE_KEY is required for Supabase Storage")
            if self.storage_provider.lower() == "minio" and any("localhost" in value or "127.0.0.1" in value for value in (self.s3_endpoint,)):
                raise ValueError("Production MinIO endpoint must not use localhost/loopback addresses")
            if self.redis_provider.lower() == "upstash":
                if not self.upstash_redis_rest_url or not self.upstash_redis_rest_token:
                    raise ValueError("UPSTASH_REDIS_REST_URL and UPSTASH_REDIS_REST_TOKEN are required for Upstash Redis in production")
                if not self.upstash_redis_rest_url.startswith("https://"):
                    raise ValueError("UPSTASH_REDIS_REST_URL must use HTTPS")
            elif any("localhost" in value or "127.0.0.1" in value for value in (self.redis_url,)):
                raise ValueError("Production Redis endpoint must not use localhost/loopback addresses")
            if any("localhost" in value or "127.0.0.1" in value for value in (self.database_url, self.qdrant_url)):
                raise ValueError("Production service endpoints must not use localhost/loopback addresses")
            if not self.cors_origins or any(origin == "*" for origin in self.cors_origins):
                raise ValueError("Production CORS_ORIGINS must contain explicit origins")
            if not self.openai_api_key and not self.anthropic_api_key:
                raise ValueError("At least one production LLM provider must be configured")
        return self

@lru_cache
def get_settings() -> Settings:
    return Settings()
