class KnowledgeRetriever:
    def __init__(self,repository): self.repository=repository
    async def document(self,user_id,document_id): return await self.repository.get_document_bundle(user_id,document_id)
