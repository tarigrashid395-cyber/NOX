class KnowledgeWorkflow:
    def __init__(self,indexer,retriever): self.indexer=indexer; self.retriever=retriever
