from backend.app.files.repository import PostgresFileRepository
class KnowledgeStore(PostgresFileRepository): pass
