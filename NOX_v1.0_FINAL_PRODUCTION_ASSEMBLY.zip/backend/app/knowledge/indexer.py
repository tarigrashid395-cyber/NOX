class KnowledgeIndexer:
    def __init__(self,service): self.service=service
    async def index_document(self,user_id,document_id): return await self.service.analyze(user_id,document_id)
