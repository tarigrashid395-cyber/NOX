from __future__ import annotations
from abc import ABC, abstractmethod
from datetime import datetime, timezone
from uuid import UUID
from sqlalchemy import DateTime, JSON, String, Text, select
from sqlalchemy.orm import Mapped, mapped_column
from backend.app.db.base import Base
from backend.app.schemas.research import ResearchHistoryItem, ResearchResult
from backend.app.research.autonomous.research_models import DeepResearchSession, DeepResearchReport

class ResearchRecord(Base):
    __tablename__="research_runs"
    id: Mapped[UUID]=mapped_column(primary_key=True)
    user_id: Mapped[UUID]=mapped_column(index=True)
    query: Mapped[str]=mapped_column(Text)
    status: Mapped[str]=mapped_column(String(32),index=True)
    result_json: Mapped[dict]=mapped_column(JSON)
    created_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=lambda: datetime.now(timezone.utc),index=True)
    completed_at: Mapped[datetime|None]=mapped_column(DateTime(timezone=True),nullable=True)

class ResearchRepository(ABC):
    @abstractmethod
    async def save(self,result:ResearchResult)->ResearchResult: ...
    @abstractmethod
    async def get(self,user_id:UUID,research_id:UUID)->ResearchResult|None: ...
    @abstractmethod
    async def history(self,user_id:UUID,limit:int=50)->list[ResearchHistoryItem]: ...
    async def save_deep_research(self,session:DeepResearchSession,report:DeepResearchReport)->DeepResearchSession: ...
    async def get_deep_research(self,user_id:UUID,session_id:UUID)->DeepResearchSession|None: ...
    async def get_deep_report(self,user_id:UUID,report_id:UUID)->DeepResearchReport|None: ...
    async def search_goal(self,user_id:UUID,goal:str,limit:int=5)->list[DeepResearchSession]: ...
    async def create_project(self,user_id:UUID,name:str,goal:str): ...

class PostgresResearchRepository(ResearchRepository):
    def __init__(self,session_factory): self.session_factory=session_factory
    async def ensure_schema(self):
        if self.session_factory is None: return
        session=self.session_factory()
        try:
            bind=session.bind
            if bind is None: return
            async with bind.begin() as conn:
                await conn.run_sync(ResearchRecord.__table__.create,checkfirst=True)
        finally:
            await session.close()
    async def save(self,result):
        async with self.session_factory() as session:
            existing=await session.get(ResearchRecord,result.id)
            payload=result.model_dump(mode="json")
            if existing:
                existing.query=result.query; existing.status=result.status; existing.result_json=payload; existing.completed_at=result.completed_at
            else:
                session.add(ResearchRecord(id=result.id,user_id=result.user_id,query=result.query,status=result.status,result_json=payload,created_at=result.created_at,completed_at=result.completed_at))
            await session.commit()
        return result
    async def get(self,user_id,research_id):
        async with self.session_factory() as session:
            r=(await session.execute(select(ResearchRecord).where(ResearchRecord.id==research_id,ResearchRecord.user_id==user_id))).scalar_one_or_none()
            return ResearchResult.model_validate(r.result_json) if r else None
    async def history(self,user_id,limit=50):
        async with self.session_factory() as session:
            rows=(await session.execute(select(ResearchRecord).where(ResearchRecord.user_id==user_id).order_by(ResearchRecord.created_at.desc()).limit(limit))).scalars()
            return [ResearchHistoryItem(id=r.id,query=r.query,status=r.status,created_at=r.created_at,completed_at=r.completed_at) for r in rows]

    async def ensure_deep_research_schema(self):
        if self.session_factory is None: return
        from sqlalchemy import text
        async with self.session_factory() as session:
            statements = [
                "CREATE TABLE IF NOT EXISTS deep_research_projects (project_id UUID PRIMARY KEY, user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE, name TEXT NOT NULL, goal TEXT NOT NULL, status VARCHAR(32) NOT NULL DEFAULT 'active', created_at TIMESTAMPTZ NOT NULL, updated_at TIMESTAMPTZ NOT NULL)",
                "CREATE INDEX IF NOT EXISTS ix_deep_research_projects_user_id ON deep_research_projects(user_id)",
                "CREATE TABLE IF NOT EXISTS deep_research_sessions (session_id UUID PRIMARY KEY, user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE, project_id UUID NULL REFERENCES deep_research_projects(project_id) ON DELETE SET NULL, goal TEXT NOT NULL, status VARCHAR(32) NOT NULL, depth VARCHAR(16) NOT NULL, session_json JSONB NOT NULL, report_id UUID NULL, created_at TIMESTAMPTZ NOT NULL, completed_at TIMESTAMPTZ NULL)",
                "CREATE INDEX IF NOT EXISTS ix_deep_research_sessions_user_id ON deep_research_sessions(user_id)",
                "CREATE INDEX IF NOT EXISTS ix_deep_research_sessions_project_id ON deep_research_sessions(project_id)",
                "CREATE TABLE IF NOT EXISTS deep_research_reports (report_id UUID PRIMARY KEY, session_id UUID NOT NULL REFERENCES deep_research_sessions(session_id) ON DELETE CASCADE, user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE, project_id UUID NULL REFERENCES deep_research_projects(project_id) ON DELETE SET NULL, report_json JSONB NOT NULL, created_at TIMESTAMPTZ NOT NULL)",
                "CREATE TABLE IF NOT EXISTS deep_research_sources (source_key TEXT NOT NULL, session_id UUID NOT NULL REFERENCES deep_research_sessions(session_id) ON DELETE CASCADE, title TEXT NOT NULL, url TEXT NULL, provider TEXT NOT NULL, metadata JSONB NOT NULL, PRIMARY KEY (session_id, source_key))",
                "CREATE TABLE IF NOT EXISTS deep_research_evidence (evidence_id UUID PRIMARY KEY, session_id UUID NOT NULL REFERENCES deep_research_sessions(session_id) ON DELETE CASCADE, source_id TEXT NOT NULL, claim TEXT NOT NULL, excerpt TEXT NOT NULL, score DOUBLE PRECISION NOT NULL, confidence DOUBLE PRECISION NOT NULL, evidence_json JSONB NOT NULL)",
                "CREATE INDEX IF NOT EXISTS ix_deep_research_evidence_session_id ON deep_research_evidence(session_id)",
                "CREATE INDEX IF NOT EXISTS ix_deep_research_reports_user_id ON deep_research_reports(user_id)",
                "CREATE TABLE IF NOT EXISTS deep_research_evidence_edges (id UUID PRIMARY KEY, session_id UUID NOT NULL REFERENCES deep_research_sessions(session_id) ON DELETE CASCADE, source_node TEXT NOT NULL, target_node TEXT NOT NULL, relation TEXT NOT NULL, weight DOUBLE PRECISION NOT NULL, metadata JSONB NOT NULL)",
                "CREATE INDEX IF NOT EXISTS ix_deep_research_evidence_edges_session_id ON deep_research_evidence_edges(session_id)",
            ]
            for statement in statements: await session.execute(text(statement))
            await session.commit()

    async def create_project(self,user_id,name,goal):
        from datetime import datetime, timezone
        from uuid import uuid4
        await self.ensure_deep_research_schema()
        project_id=uuid4(); now=datetime.now(timezone.utc)
        from sqlalchemy import text
        async with self.session_factory() as session:
            await session.execute(text("INSERT INTO deep_research_projects(project_id,user_id,name,goal,status,created_at,updated_at) VALUES (:id,:uid,:name,:goal,'active',:created,:updated)"),{"id":project_id,"uid":user_id,"name":name,"goal":goal,"created":now,"updated":now})
            await session.commit()
        return project_id

    async def save_deep_research(self,session_obj,report):
        await self.ensure_deep_research_schema()
        from sqlalchemy import text
        async with self.session_factory() as session:
            payload=session_obj.model_dump(mode='json')
            await session.execute(text("INSERT INTO deep_research_sessions(session_id,user_id,project_id,goal,status,depth,session_json,report_id,created_at,completed_at) VALUES (:id,:uid,:pid,:goal,:status,:depth,:json,:rid,:created,:completed) ON CONFLICT(session_id) DO UPDATE SET status=EXCLUDED.status,session_json=EXCLUDED.session_json,report_id=EXCLUDED.report_id,completed_at=EXCLUDED.completed_at"),{"id":session_obj.session_id,"uid":session_obj.user_id,"pid":session_obj.project_id,"goal":session_obj.goal,"status":session_obj.status.value,"depth":session_obj.depth.value,"json":payload,"rid":report.report_id,"created":session_obj.created_at,"completed":session_obj.completed_at})
            await session.execute(text("INSERT INTO deep_research_reports(report_id,session_id,user_id,project_id,report_json,created_at) VALUES (:id,:sid,:uid,:pid,:json,:created) ON CONFLICT(report_id) DO UPDATE SET report_json=EXCLUDED.report_json"),{"id":report.report_id,"sid":report.session_id,"uid":session_obj.user_id,"pid":report.project_id,"json":report.model_dump(mode='json'),"created":report.created_at})
            await session.execute(text("DELETE FROM deep_research_evidence_edges WHERE session_id=:sid"),{"sid":session_obj.session_id})
            await session.execute(text("DELETE FROM deep_research_evidence WHERE session_id=:sid"),{"sid":session_obj.session_id})
            await session.execute(text("DELETE FROM deep_research_sources WHERE session_id=:sid"),{"sid":session_obj.session_id})
            for raw in session_obj.evidence:
                from sqlalchemy import text
                await session.execute(text("INSERT INTO deep_research_evidence(evidence_id,session_id,source_id,claim,excerpt,score,confidence,evidence_json) VALUES (:id,:sid,:source,:claim,:excerpt,:score,:confidence,:json) ON CONFLICT(evidence_id) DO UPDATE SET evidence_json=EXCLUDED.evidence_json"),{"id":raw["id"],"sid":session_obj.session_id,"source":raw["source_id"],"claim":raw["claim"],"excerpt":raw["excerpt"],"score":raw["score"],"confidence":raw["confidence"],"json":raw})
                metadata=raw.get("metadata") or {}
                source_key=str(raw["source_id"])
                await session.execute(text("INSERT INTO deep_research_sources(source_key,session_id,title,url,provider,metadata) VALUES (:key,:sid,:title,:url,:provider,:metadata) ON CONFLICT(session_id,source_key) DO UPDATE SET title=EXCLUDED.title,url=EXCLUDED.url,provider=EXCLUDED.provider,metadata=EXCLUDED.metadata"),{"key":source_key,"sid":session_obj.session_id,"title":str(metadata.get("title") or source_key),"url":metadata.get("url"),"provider":str(metadata.get("provider") or "unknown"),"metadata":metadata})
            for edge in session_obj.graph.edges:
                from uuid import uuid4
                await session.execute(text("INSERT INTO deep_research_evidence_edges(id,session_id,source_node,target_node,relation,weight,metadata) VALUES (:id,:sid,:source,:target,:relation,:weight,:metadata)"),{"id":uuid4(),"sid":session_obj.session_id,"source":edge.source,"target":edge.target,"relation":edge.relation,"weight":edge.weight,"metadata":edge.metadata})
            await session.commit()
        return session_obj

    async def get_deep_research(self,user_id,session_id):
        await self.ensure_deep_research_schema()
        from sqlalchemy import text
        async with self.session_factory() as session:
            row=(await session.execute(text("SELECT session_json FROM deep_research_sessions WHERE session_id=:id AND user_id=:uid"),{"id":session_id,"uid":user_id})).scalar_one_or_none()
            return DeepResearchSession.model_validate(row) if row else None

    async def get_deep_report(self,user_id,report_id):
        await self.ensure_deep_research_schema()
        from sqlalchemy import text
        async with self.session_factory() as session:
            row=(await session.execute(text("SELECT report_json FROM deep_research_reports WHERE report_id=:id AND user_id=:uid"),{"id":report_id,"uid":user_id})).scalar_one_or_none()
            return DeepResearchReport.model_validate(row) if row else None

    async def search_goal(self,user_id,goal,limit=5):
        await self.ensure_deep_research_schema()
        from sqlalchemy import text
        async with self.session_factory() as session:
            rows=(await session.execute(text("SELECT session_json FROM deep_research_sessions WHERE user_id=:uid AND status IN ('completed','partial') AND goal ILIKE :goal ORDER BY created_at DESC LIMIT :limit"),{"uid":user_id,"goal":f"%{goal}%","limit":limit})).scalars().all()
            return [DeepResearchSession.model_validate(x) for x in rows]

class InMemoryResearchRepository(ResearchRepository):
    def __init__(self): self.items={}; self.deep_sessions={}; self.deep_reports={}; self.projects={}
    async def save(self,result): self.items[result.id]=result; return result
    async def get(self,user_id,research_id):
        result=self.items.get(research_id); return result if result and result.user_id==user_id else None
    async def history(self,user_id,limit=50):
        rows=[x for x in self.items.values() if x.user_id==user_id]; rows.sort(key=lambda x:x.created_at,reverse=True)
        return [ResearchHistoryItem(id=x.id,query=x.query,status=x.status,created_at=x.created_at,completed_at=x.completed_at) for x in rows[:limit]]
    async def save_deep_research(self,session,report):
        self.deep_sessions[session.session_id]=session
        self.deep_reports[report.report_id]=report
        return session

    async def get_deep_research(self,user_id,session_id):
        result=self.deep_sessions.get(session_id)
        return result if result and result.user_id==user_id else None

    async def get_deep_report(self,user_id,report_id):
        report=self.deep_reports.get(report_id)
        return report if report and any(x.session_id==report.session_id and x.user_id==user_id for x in self.deep_sessions.values()) else None

    async def search_goal(self,user_id,goal,limit=5):
        q=goal.lower().strip(); rows=[x for x in self.deep_sessions.values() if x.user_id==user_id and q in x.goal.lower()]
        rows.sort(key=lambda x:x.created_at,reverse=True)
        return rows[:limit]

    async def create_project(self,user_id,name,goal):
        from datetime import datetime, timezone
        from uuid import uuid4
        project_id=uuid4(); self.projects[project_id]={"project_id":project_id,"user_id":user_id,"name":name,"goal":goal,"status":"active","created_at":datetime.now(timezone.utc),"updated_at":datetime.now(timezone.utc)}; return project_id
