from __future__ import annotations
from datetime import datetime, timezone
from time import perf_counter
from uuid import UUID, uuid4
from backend.app.schemas.research import ResearchRequest
from .research_models import DeepResearchSession, DeepResearchReport, DeepResearchStartRequest, ResearchSessionStatus
from .research_planner import AutonomousResearchPlanner
from .research_executor import ResearchExecutor
from .research_gap_detector import ResearchGapDetector
from .research_validator import ResearchValidator
from .evidence_graph import EvidenceGraphBuilder
from .research_memory import ResearchMemory

class AutonomousResearchOrchestrator:
    def __init__(self, search_engine, evidence_engine, citation_engine, conflict_engine, report_builder, repository, memory=None, analytics=None):
        self.repository=repository
        self.planner=AutonomousResearchPlanner()
        self.executor=ResearchExecutor(search_engine,evidence_engine)
        self.citation_engine=citation_engine
        self.conflict_engine=conflict_engine
        self.report_builder=report_builder
        self.gap_detector=ResearchGapDetector()
        self.validator=ResearchValidator()
        self.graph_builder=EvidenceGraphBuilder()
        self.memory=ResearchMemory(repository,memory)
        self.analytics=analytics

    async def start(self, user_id: UUID, request: DeepResearchStartRequest) -> DeepResearchSession:
        started=perf_counter(); now=datetime.now(timezone.utc); session_id=uuid4()
        project_id=request.project_id
        if project_id is None:
            project_name=request.project_name or request.goal[:120]
            try:
                project_id=await self.repository.create_project(user_id,project_name,request.goal)
            except Exception:
                project_id=None
        depth=self.planner.choose_depth(request.goal,request.depth)
        plan=self.planner.build(request.goal,depth)
        prior=await self.memory.find_prior_sessions(user_id,request.goal,limit=5) if request.reuse_memory else []
        remembered=await self.memory.recall(user_id,request.goal,limit=8) if request.reuse_memory else []
        all_evidence=[]; warnings=[]; gaps=[]; conflicts=[]; cycles=0
        if remembered:
            from backend.app.schemas.research import EvidenceItem
            for item in remembered:
                content=str(item.get("content") or "").strip() if isinstance(item,dict) else ""
                if not content: continue
                memory_id=str(item.get("id") or uuid4())
                claim=content.split(". ",1)[0][:500]
                all_evidence.append(EvidenceItem(source_id=f"memory:{memory_id}",claim=claim,excerpt=content[:4000],score=.60,relevance=.60,quality=.55,confidence=.60,metadata={"provider":"memory","memory_id":memory_id}))
        for prior_session in prior:
            for raw_item in prior_session.evidence[:request.max_sources_per_step]:
                try:
                    from backend.app.schemas.research import EvidenceItem
                    all_evidence.append(EvidenceItem.model_validate(raw_item))
                except Exception:
                    warnings.append(f"Prior research evidence could not be reused from session {prior_session.session_id}")
        executed_queries=set()
        max_cycles=len(plan)
        for cycle in range(1,max_cycles+1):
            cycles=cycle
            candidates=[p for p in plan if p.query not in executed_queries and (p.cycle <= cycle)]
            if not candidates:
                break
            step=candidates[0]
            step.cycle=cycle
            executed_queries.add(step.query)
            try:
                evidence, warns=await self.executor.execute(user_id,step.query,request.providers,request.max_sources_per_step)
                warnings.extend(warns); all_evidence.extend(evidence); step.completed=True
            except Exception as exc:
                warnings.append(f"Research cycle {cycle} failed: {exc}")
            all_evidence=self.validator.rank(self._deduplicate(all_evidence))
            citations=self.citation_engine.generate(all_evidence)
            conflicts=self.validator.conflicts(all_evidence,self.conflict_engine.detect(all_evidence))
            gaps=self.gap_detector.detect(request.goal,all_evidence,conflicts)
            blocking=[g for g in gaps if g.blocking]
            if cycle >= max_cycles or not blocking:
                break
            gap_query=next((g.suggested_query for g in gaps if g.blocking),None)
            if gap_query and gap_query not in executed_queries:
                extra=type(plan[0])(step_id=len(plan)+1,query=gap_query,objective="Close a detected research gap.",rationale="Automatically generated from gap detection.",cycle=cycle+1)
                plan.append(extra)
                max_cycles=min(len(plan), self.planner._DEPTHS[depth])
        all_evidence=self.validator.rank(self._deduplicate(all_evidence))
        citations=self.citation_engine.generate(all_evidence)
        conflicts=self.validator.conflicts(all_evidence,self.conflict_engine.detect(all_evidence))
        gaps=self.gap_detector.detect(request.goal,all_evidence,conflicts)
        graph=self.graph_builder.build(all_evidence,conflicts)
        report=self.report_builder.build(request.goal,all_evidence,citations,conflicts)
        confidence=self.validator.confidence(all_evidence,conflicts)
        status=ResearchSessionStatus.COMPLETED if all_evidence and not any(g.blocking for g in gaps) else ResearchSessionStatus.PARTIAL if all_evidence else ResearchSessionStatus.FAILED
        conclusion=report.executive_summary
        elapsed=perf_counter()-started
        session=DeepResearchSession(session_id=session_id,user_id=user_id,project_id=project_id,goal=request.goal,status=status,depth=depth,plan=plan,gaps=gaps,evidence=[x.model_dump(mode="json") for x in all_evidence],conflicts=[x.model_dump(mode="json") for x in conflicts],graph=graph,conclusion=conclusion,metrics={"research_depth":len(plan),"research_cycles":cycles,"research_time":round(elapsed,6),"evidence_count":len(all_evidence),"conflict_count":len(conflicts),"confidence_score":confidence},reused_sessions=[x.session_id for x in prior],warnings=warnings,created_at=now,completed_at=datetime.now(timezone.utc))
        report_obj=DeepResearchReport(report_id=uuid4(),session_id=session.session_id,project_id=project_id,goal=request.goal,executive_summary=report.executive_summary,detailed_analysis=report.detailed_analysis,key_findings=report.key_findings,recommendations=report.recommendations,citations=[x.model_dump(mode="json") for x in citations],evidence=session.evidence,conflicts=session.conflicts,conclusion=conclusion,created_at=datetime.now(timezone.utc))
        session.report_id=report_obj.report_id
        await self.repository.save_deep_research(session,report_obj)
        await self.memory.remember(user_id,session)
        if self.analytics:
            try:
                await self.analytics.record(user_id,self.analytics_event(session))
            except Exception:
                pass
        return session

    def analytics_event(self,session):
        return self.analytics_event_factory(session)

    @staticmethod
    def analytics_event_factory(session):
        from backend.app.evaluation.schemas import AnalyticsEvent
        return AnalyticsEvent(event="deep_research.completed",category="research",value=session.metrics.confidence_score,success=session.status.value in {"completed","partial"},latency_ms=session.metrics.research_time*1000,agent="AutonomousResearchOrchestrator",tool="Research Engine",metadata=session.metrics.model_dump())

    @staticmethod
    def _deduplicate(items):
        unique={}
        for item in items:
            key=f"{item.source_id}:{item.claim.lower().strip()}"
            if key not in unique or item.score > unique[key].score: unique[key]=item
        return list(unique.values())

    async def get(self,user_id:UUID,session_id:UUID):
        return await self.repository.get_deep_research(user_id,session_id)

    async def report(self,user_id:UUID,report_id:UUID):
        return await self.repository.get_deep_report(user_id,report_id)
