from __future__ import annotations
from enum import StrEnum
from typing import Any
from uuid import UUID, uuid4
from datetime import datetime
from pydantic import BaseModel, Field, ConfigDict

class ResearchDepth(StrEnum):
    ONE = "1-step"
    THREE = "3-step"
    FIVE = "5-step"
    TEN = "10-step"

class ResearchSessionStatus(StrEnum):
    RUNNING = "running"
    COMPLETED = "completed"
    PARTIAL = "partial"
    FAILED = "failed"

class ResearchProject(BaseModel):
    model_config = ConfigDict(extra="forbid")
    project_id: UUID = Field(default_factory=uuid4)
    user_id: UUID
    name: str = Field(min_length=1, max_length=300)
    goal: str = Field(min_length=3, max_length=20000)
    status: str = "active"
    created_at: datetime
    updated_at: datetime

class ResearchPlanStep(BaseModel):
    model_config = ConfigDict(extra="forbid")
    step_id: int = Field(ge=1)
    query: str = Field(min_length=3, max_length=10000)
    objective: str = Field(min_length=1, max_length=1000)
    rationale: str = Field(min_length=1, max_length=2000)
    cycle: int = Field(ge=1)
    completed: bool = False

class ResearchGap(BaseModel):
    model_config = ConfigDict(extra="forbid")
    gap_id: UUID = Field(default_factory=uuid4)
    kind: str
    description: str
    severity: float = Field(ge=0, le=1)
    suggested_query: str
    blocking: bool = False

class EvidenceNode(BaseModel):
    model_config = ConfigDict(extra="forbid")
    node_id: UUID = Field(default_factory=uuid4)
    evidence_id: UUID
    source_id: str
    claim: str
    confidence: float = Field(ge=0, le=1)
    score: float = Field(ge=0, le=1)
    metadata: dict[str, Any] = Field(default_factory=dict)

class EvidenceGraphNode(BaseModel):
    model_config = ConfigDict(extra="forbid")
    id: str
    type: str
    label: str
    confidence: float = Field(default=0.0, ge=0, le=1)
    metadata: dict[str, Any] = Field(default_factory=dict)

class EvidenceGraphEdge(BaseModel):
    model_config = ConfigDict(extra="forbid")
    source: str
    target: str
    relation: str
    weight: float = Field(default=1.0, ge=0, le=1)
    metadata: dict[str, Any] = Field(default_factory=dict)

class EvidenceGraph(BaseModel):
    model_config = ConfigDict(extra="forbid")
    nodes: list[EvidenceGraphNode] = Field(default_factory=list)
    edges: list[EvidenceGraphEdge] = Field(default_factory=list)

class ResearchMetrics(BaseModel):
    research_depth: int = Field(ge=1)
    research_cycles: int = Field(ge=1)
    research_time: float = Field(ge=0)
    evidence_count: int = Field(ge=0)
    conflict_count: int = Field(ge=0)
    confidence_score: float = Field(ge=0, le=1)

class DeepResearchSession(BaseModel):
    model_config = ConfigDict(extra="forbid")
    session_id: UUID = Field(default_factory=uuid4)
    user_id: UUID
    project_id: UUID | None = None
    goal: str
    status: ResearchSessionStatus
    depth: ResearchDepth
    plan: list[ResearchPlanStep] = Field(default_factory=list)
    gaps: list[ResearchGap] = Field(default_factory=list)
    evidence: list[dict[str, Any]] = Field(default_factory=list)
    conflicts: list[dict[str, Any]] = Field(default_factory=list)
    graph: EvidenceGraph = Field(default_factory=EvidenceGraph)
    report_id: UUID | None = None
    conclusion: str | None = None
    metrics: ResearchMetrics
    reused_sessions: list[UUID] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    created_at: datetime
    completed_at: datetime | None = None

class DeepResearchStartRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    goal: str = Field(min_length=3, max_length=20000)
    depth: ResearchDepth | None = None
    project_id: UUID | None = None
    providers: list[str] = Field(default_factory=lambda: ["web", "memory", "knowledge"])
    max_sources_per_step: int = Field(default=8, ge=1, le=50)
    reuse_memory: bool = True
    language: str = "en"
    project_name: str | None = Field(default=None, max_length=300)

class DeepResearchReport(BaseModel):
    model_config = ConfigDict(extra="forbid")
    report_id: UUID
    session_id: UUID
    project_id: UUID | None = None
    goal: str
    executive_summary: str
    detailed_analysis: str
    key_findings: list[str] = Field(default_factory=list)
    recommendations: list[str] = Field(default_factory=list)
    citations: list[dict[str, Any]] = Field(default_factory=list)
    evidence: list[dict[str, Any]] = Field(default_factory=list)
    conflicts: list[dict[str, Any]] = Field(default_factory=list)
    conclusion: str | None = None
    created_at: datetime
