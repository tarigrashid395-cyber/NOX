from __future__ import annotations
import re
from .research_models import ResearchDepth, ResearchPlanStep

class AutonomousResearchPlanner:
    """Creates bounded research sub-queries without replacing the Phase 14 cognitive Planner."""
    _DEPTHS = {ResearchDepth.ONE: 1, ResearchDepth.THREE: 3, ResearchDepth.FIVE: 5, ResearchDepth.TEN: 10}

    def choose_depth(self, goal: str, requested: ResearchDepth | None = None) -> ResearchDepth:
        if requested:
            return requested
        words = len(goal.split())
        complexity = len(re.findall(r"\b(compare|evaluate|impact|history|latest|market|risk|evidence|sources|why|how|قارن|تقييم|تأثير|تاريخ|أحدث|سوق|مخاطر|أدلة|مصادر|لماذا|كيف)\b", goal, re.I))
        if words >= 80 or complexity >= 7:
            return ResearchDepth.TEN
        if words >= 40 or complexity >= 5:
            return ResearchDepth.FIVE
        if words >= 18 or complexity >= 3:
            return ResearchDepth.THREE
        return ResearchDepth.ONE

    def build(self, goal: str, depth: ResearchDepth) -> list[ResearchPlanStep]:
        n = self._DEPTHS[depth]
        clean = " ".join(goal.split())
        templates = [
            (clean, "Establish the core facts and scope of the research goal.", "Directly answer the stated goal."),
            (f"{clean} primary sources authoritative evidence", "Locate authoritative and primary evidence.", "Increase source quality and reduce secondary-source dependence."),
            (f"{clean} independent evidence competing perspectives", "Find independent perspectives and alternative evidence.", "Test whether the initial picture is robust across sources."),
            (f"{clean} limitations risks uncertainty counterarguments", "Investigate limitations, risks, uncertainty and counterarguments.", "Expose weak or one-sided conclusions."),
            (f"{clean} latest developments changes recent evidence", "Check recency and identify changed facts.", "Detect outdated evidence."),
            (f"{clean} quantitative data statistics benchmarks", "Collect quantitative evidence where available.", "Improve measurable support for important claims."),
            (f"{clean} expert analysis methodology review", "Seek expert analysis and methodological context.", "Assess evidence quality and interpretation."),
            (f"{clean} disagreements consensus conflicting claims", "Search specifically for disagreement and consensus.", "Surface conflicts rather than silently averaging them."),
            (f"{clean} missing evidence unanswered questions", "Target likely unanswered areas.", "Close residual coverage gaps."),
            (f"{clean} synthesis evidence hierarchy conclusion", "Verify the evidence hierarchy before synthesis.", "Prepare the final evidence-backed conclusion."),
        ]
        return [ResearchPlanStep(step_id=i+1, query=templates[i][0], objective=templates[i][1], rationale=templates[i][2], cycle=1) for i in range(n)]
