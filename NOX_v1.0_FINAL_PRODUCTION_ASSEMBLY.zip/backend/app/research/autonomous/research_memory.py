from __future__ import annotations
from uuid import UUID
from .research_models import DeepResearchSession

class ResearchMemory:
    """Session-level reuse over the authoritative research repository and Memory Engine."""
    def __init__(self, repository, memory=None):
        self.repository = repository
        self.memory = memory

    async def find_prior_sessions(self, user_id: UUID, goal: str, limit: int = 5) -> list[DeepResearchSession]:
        if not self.repository:
            return []
        return await self.repository.search_goal(user_id, goal, limit)

    async def recall(self, user_id: UUID, goal: str, limit: int = 8) -> list[dict]:
        if not self.memory:
            return []
        try:
            return await self.memory.search(user_id, goal, limit=limit)
        except Exception:
            return []

    async def remember(self, user_id: UUID, session: DeepResearchSession) -> None:
        if not self.memory:
            return
        try:
            from backend.app.domain.memories import MemoryType
            summary = session.conclusion or (session.report_id and f"Deep research session {session.session_id}") or session.goal
            await self.memory.store(user_id, MemoryType.KNOWLEDGE, summary, source="deep_research", metadata={"session_id":str(session.session_id),"project_id":str(session.project_id) if session.project_id else None,"evidence_count":session.metrics.evidence_count,"confidence_score":session.metrics.confidence_score})
        except Exception:
            return
