from __future__ import annotations
from backend.app.schemas.research import EvidenceItem, Conflict

class ResearchValidator:
    def rank(self, evidence: list[EvidenceItem]) -> list[EvidenceItem]:
        return sorted(evidence, key=lambda x: (x.confidence, x.quality, x.relevance, x.score), reverse=True)

    def conflicts(self, evidence: list[EvidenceItem], conflicts: list[Conflict]) -> list[Conflict]:
        valid_ids = {x.source_id for x in evidence}
        return [c for c in conflicts if c.source_a in valid_ids and c.source_b in valid_ids and c.source_a != c.source_b]

    def confidence(self, evidence: list[EvidenceItem], conflicts: list[Conflict]) -> float:
        if not evidence:
            return 0.0
        base = sum(x.confidence for x in evidence) / len(evidence)
        penalty = min(0.35, len(conflicts) * 0.05)
        return round(max(0.0, min(1.0, base - penalty)), 4)
