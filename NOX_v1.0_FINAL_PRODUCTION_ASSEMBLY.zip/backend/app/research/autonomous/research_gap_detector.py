from __future__ import annotations
import re
from collections import Counter
from datetime import datetime, timezone
from backend.app.schemas.research import EvidenceItem, Conflict
from .research_models import ResearchGap

class ResearchGapDetector:
    def __init__(self, min_confidence: float = 0.62, min_coverage: float = 0.55):
        self.min_confidence = min_confidence
        self.min_coverage = min_coverage

    def detect(self, goal: str, evidence: list[EvidenceItem], conflicts: list[Conflict]) -> list[ResearchGap]:
        gaps: list[ResearchGap] = []
        terms = [x for x in re.findall(r"\w+", goal.lower()) if len(x) > 3]
        covered = set()
        for item in evidence:
            covered.update(re.findall(r"\w+", (item.claim + " " + item.excerpt).lower()))
        coverage = len(set(terms) & covered) / max(1, len(set(terms)))
        if not evidence:
            gaps.append(ResearchGap(kind="missing_evidence", description="No usable evidence was collected.", severity=1.0, suggested_query=goal, blocking=True))
        elif coverage < self.min_coverage:
            gaps.append(ResearchGap(kind="insufficient_coverage", description=f"Goal-term coverage is {coverage:.2f}, below the required threshold.", severity=1.0-coverage, suggested_query=f"{goal} evidence details", blocking=True))
        weak = [x for x in evidence if x.confidence < self.min_confidence]
        if weak:
            gaps.append(ResearchGap(kind="weak_confidence", description=f"{len(weak)} evidence items have confidence below {self.min_confidence:.2f}.", severity=min(1.0, len(weak)/max(1,len(evidence))), suggested_query=f"{goal} authoritative primary source", blocking=False))
        if conflicts:
            topics = Counter(c.topic for c in conflicts)
            topic = topics.most_common(1)[0][0]
            gaps.append(ResearchGap(kind="conflicting_sources", description=f"Conflicting claims remain around: {topic}.", severity=min(1.0, len(conflicts)/5), suggested_query=f"{goal} {topic} conflicting evidence", blocking=True))
        source_ids = {x.source_id for x in evidence}
        if len(source_ids) < 2 and evidence:
            gaps.append(ResearchGap(kind="insufficient_source_diversity", description="Evidence relies on fewer than two distinct sources.", severity=.8, suggested_query=f"{goal} independent sources", blocking=False))
        outdated = []
        now = datetime.now(timezone.utc)
        for item in evidence:
            published = item.metadata.get("published_at")
            if published:
                try:
                    dt = datetime.fromisoformat(str(published).replace("Z", "+00:00"))
                    if (now - dt).days > 730: outdated.append(item)
                except (TypeError, ValueError):
                    pass
        if outdated:
            gaps.append(ResearchGap(kind="outdated_claims", description=f"{len(outdated)} evidence items are older than two years and may require recency verification.", severity=min(1.0, len(outdated)/max(1,len(evidence))), suggested_query=f"{goal} latest developments recent evidence", blocking=False))
        unsupported = [x for x in evidence if not x.claim.strip() or not x.excerpt.strip()]
        if unsupported:
            gaps.append(ResearchGap(kind="unsupported_claims", description=f"{len(unsupported)} evidence records lack a complete claim/excerpt.", severity=.9, suggested_query=f"{goal} supporting evidence", blocking=True))
        return gaps
