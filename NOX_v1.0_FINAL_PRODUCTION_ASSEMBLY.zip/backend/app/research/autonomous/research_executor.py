from __future__ import annotations
from uuid import UUID
from backend.app.schemas.research import ResearchRequest

class ResearchExecutor:
    """Executes bounded sub-research using the existing Research Engine search/evidence pipeline."""
    def __init__(self, search_engine, evidence_engine):
        self.search_engine = search_engine
        self.evidence_engine = evidence_engine

    async def execute(self, user_id: UUID, query: str, providers: list[str], max_sources: int):
        raw, warnings = await self.search_engine.search(query, providers, max_sources, user_id)
        return self.evidence_engine.collect(raw, query, max_sources), warnings
