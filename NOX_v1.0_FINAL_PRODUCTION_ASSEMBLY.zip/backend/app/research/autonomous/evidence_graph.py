from __future__ import annotations
from backend.app.schemas.research import EvidenceItem, Conflict
from .research_models import EvidenceGraph, EvidenceGraphEdge, EvidenceGraphNode

class EvidenceGraphBuilder:
    def build(self, evidence: list[EvidenceItem], conflicts: list[Conflict]) -> EvidenceGraph:
        graph = EvidenceGraph()
        seen_claims: dict[str, str] = {}
        for item in evidence:
            source_id = f"source:{item.source_id}"
            evidence_id = f"evidence:{item.id}"
            claim_id = f"claim:{item.id}"
            graph.nodes.extend([
                EvidenceGraphNode(id=source_id,type="source",label=str(item.metadata.get("title") or item.source_id),confidence=item.confidence,metadata={"source_id":item.source_id,"url":item.metadata.get("url")}),
                EvidenceGraphNode(id=evidence_id,type="evidence",label=item.excerpt[:240],confidence=item.confidence,metadata={"evidence_id":str(item.id)}),
                EvidenceGraphNode(id=claim_id,type="claim",label=item.claim,confidence=item.confidence,metadata={"evidence_id":str(item.id)}),
            ])
            graph.edges.extend([
                EvidenceGraphEdge(source=source_id,target=evidence_id,relation="provides",weight=item.quality),
                EvidenceGraphEdge(source=evidence_id,target=claim_id,relation="supports",weight=item.confidence),
            ])
            normalized=" ".join(item.claim.lower().split())
            if normalized in seen_claims and seen_claims[normalized] != claim_id:
                graph.edges.append(EvidenceGraphEdge(source=claim_id,target=seen_claims[normalized],relation="supports_same_claim",weight=item.confidence))
            else:
                seen_claims[normalized]=claim_id
        for conflict in conflicts:
            a=f"source:{conflict.source_a}"; b=f"source:{conflict.source_b}"
            if any(n.id==a for n in graph.nodes) and any(n.id==b for n in graph.nodes):
                graph.edges.append(EvidenceGraphEdge(source=a,target=b,relation="contradicts",weight=min(conflict.confidence_a,conflict.confidence_b),metadata={"topic":conflict.topic}))
        return graph
