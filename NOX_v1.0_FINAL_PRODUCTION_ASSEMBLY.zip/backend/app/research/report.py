from __future__ import annotations
from backend.app.schemas.research import ResearchReport, EvidenceItem, Citation, Conflict

class ReportBuilder:
    def build(self, query: str, evidence: list[EvidenceItem], citations: list[Citation], conflicts: list[Conflict]) -> ResearchReport:
        findings=[f"[{i+1}] {item.claim}" for i,item in enumerate(evidence[:8])]
        summary = self._summary(query,evidence,conflicts)
        analysis_parts=[]
        for index,item in enumerate(evidence[:10],1):
            analysis_parts.append(f"[{index}] {item.excerpt}")
        if conflicts:
            analysis_parts.append("Conflicts: " + "; ".join(c.explanation for c in conflicts[:5]))
        recommendations=self._recommendations(evidence,conflicts)
        table=[{"evidence_id":str(item.id),"source_id":item.source_id,"claim":item.claim,"score":round(item.score,4),"confidence":round(item.confidence,4)} for item in evidence]
        return ResearchReport(executive_summary=summary,detailed_analysis="\n\n".join(analysis_parts),evidence_table=table,source_list=citations,key_findings=findings,recommendations=recommendations)

    @staticmethod
    def _summary(query,evidence,conflicts):
        if not evidence: return f"No verifiable evidence was collected for: {query}."
        base=f"Research on '{query}' collected {len(evidence)} ranked evidence items from {len({x.source_id for x in evidence})} sources."
        if conflicts: base += f" {len(conflicts)} potential evidence conflicts were detected and should be reviewed."
        return base

    @staticmethod
    def _recommendations(evidence,conflicts):
        if not evidence: return ["Configure a web or local knowledge provider and rerun the research query."]
        rec=["Prefer the highest-scoring evidence and inspect primary sources before making high-impact decisions."]
        if conflicts: rec.append("Review conflicting sources and compare publication context, methodology, and confidence before concluding.")
        return rec
