from __future__ import annotations
import re
from backend.app.schemas.research import Conflict, EvidenceItem

class ConflictDetectionEngine:
    NEGATIONS={"not","no","never","false","without","unlikely","cannot","can't","doesn't","doesnt"}

    def detect(self, evidence: list[EvidenceItem]) -> list[Conflict]:
        conflicts=[]
        for i,left in enumerate(evidence):
            for right in evidence[i+1:]:
                overlap=self._topic_overlap(left.claim,right.claim)
                if overlap < 0.45: continue
                a_neg=self._negative(left.claim)
                b_neg=self._negative(right.claim)
                if a_neg == b_neg: continue
                conflicts.append(Conflict(topic=self._topic(left.claim,right.claim),source_a=left.source_id,source_b=right.source_id,confidence_a=left.confidence,confidence_b=right.confidence,explanation="Sources express opposing polarity for substantially overlapping claims; confidence follows evidence scores."))
        return conflicts

    @staticmethod
    def _tokens(text):
        return {x for x in re.findall(r"\w+",text.lower()) if len(x)>3 and x not in ConflictDetectionEngine.NEGATIONS}

    def _topic_overlap(self,a,b):
        x,y=self._tokens(a),self._tokens(b)
        return len(x&y)/max(1,min(len(x),len(y)))

    def _negative(self,text):
        return bool(self._tokens(text) and set(re.findall(r"\w+",text.lower())) & self.NEGATIONS)

    @staticmethod
    def _topic(a,b):
        words=list(ConflictDetectionEngine._tokens(a) & ConflictDetectionEngine._tokens(b))
        return " ".join(words[:8]) or "overlapping claim"
