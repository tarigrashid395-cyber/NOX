from __future__ import annotations
from backend.app.schemas.research import EvidenceItem

class ResearchQualityScorer:
    """Deterministic quality gate for evidence completeness and source metadata."""
    def score(self, item: EvidenceItem) -> float:
        completeness = min(1.0, len(item.excerpt) / 600.0)
        return min(1.0, 0.55 * item.relevance + 0.30 * item.quality + 0.15 * completeness)

    def rank(self, items: list[EvidenceItem]) -> list[EvidenceItem]:
        return sorted(items, key=self.score, reverse=True)
