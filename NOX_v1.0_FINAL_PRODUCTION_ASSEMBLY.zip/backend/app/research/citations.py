from __future__ import annotations
from datetime import datetime, timezone
from backend.app.schemas.research import Citation, EvidenceItem

class CitationEngine:
    def generate(self, evidence: list[EvidenceItem]) -> list[Citation]:
        citations=[]
        for index, item in enumerate(evidence, start=1):
            title=str(item.metadata.get("title") or item.source_id)
            url=item.metadata.get("url")
            source=str(item.metadata.get("provider") or "unknown")
            key=f"src-{index}"
            citations.append(Citation(index=index,citation_key=key,title=title,url=url,source=source,accessed_at=datetime.now(timezone.utc),bibliography={"title":title,"url":url,"source":source}))
        return citations

    def inline(self, text: str, citation: Citation) -> str:
        return f"{text.rstrip()} [{citation.index}]"
