from __future__ import annotations
import re
from backend.app.providers.search.base import SearchResult

class SourceExtractor:
    """Extracts bounded, citation-safe text from provider results without inventing content."""
    def extract(self, result: SearchResult, max_chars: int = 4000) -> str:
        text=(result.content or result.snippet or "").strip()
        text=re.sub(r"\s+"," ",text)
        return text[:max_chars]
