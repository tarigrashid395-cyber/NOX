from __future__ import annotations
import hashlib
import re
from backend.app.providers.search.base import SearchResult
from backend.app.schemas.research import EvidenceItem

class EvidenceEngine:
    def collect(self, results: list[SearchResult], query: str, limit: int) -> list[EvidenceItem]:
        dedup: dict[str, EvidenceItem] = {}
        for result in results:
            excerpt = (result.content or result.snippet).strip()
            if not excerpt:
                continue
            relevance = self._relevance(query, result.title + " " + excerpt)
            quality = self._quality(result)
            score = min(1.0, 0.60 * relevance + 0.25 * quality + 0.15 * (1.0 if result.url else 0.5))
            key = self._dedup_key(result)
            item = EvidenceItem(
                source_id=result.source_id,
                claim=self._claim(excerpt),
                excerpt=excerpt[:4000],
                score=score,
                relevance=relevance,
                quality=quality,
                confidence=score,
                metadata={"title": result.title, "url": result.url, "provider": result.provider, **result.metadata},
            )
            current = dedup.get(key)
            if current is None or item.score > current.score:
                dedup[key] = item
        return sorted(dedup.values(), key=lambda x: x.score, reverse=True)[:limit]

    @staticmethod
    def _dedup_key(result: SearchResult) -> str:
        raw = (result.url or result.title + result.snippet).strip().lower()
        return hashlib.sha256(raw.encode()).hexdigest()

    @staticmethod
    def _relevance(query: str, text: str) -> float:
        terms = {t for t in re.findall(r"\w+", query.lower()) if len(t) > 2}
        if not terms:
            return 0.0
        words = set(re.findall(r"\w+", text.lower()))
        return min(1.0, len(terms & words) / len(terms))

    @staticmethod
    def _quality(result: SearchResult) -> float:
        score = 0.45 if result.url else 0.20
        if result.provider == "web": score += 0.20
        if result.published_at: score += 0.10
        if len(result.content or result.snippet) >= 300: score += 0.15
        if result.title: score += 0.10
        return min(1.0, score)

    @staticmethod
    def _claim(text: str) -> str:
        sentence = re.split(r"(?<=[.!?])\s+", text, maxsplit=1)[0]
        return sentence[:500]
