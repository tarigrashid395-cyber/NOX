from __future__ import annotations
from datetime import datetime, timezone
from uuid import UUID, uuid4
from backend.app.schemas.research import ResearchRequest, ResearchResult
from backend.app.research.search import SearchEngine
from backend.app.research.evidence import EvidenceEngine
from backend.app.research.citations import CitationEngine
from backend.app.research.conflicts import ConflictDetectionEngine
from backend.app.research.report import ReportBuilder

class ResearchOrchestrator:
    def __init__(self, search_engine, evidence_engine=None, citation_engine=None, conflict_engine=None, report_builder=None, repository=None, memory=None):
        self.search_engine=search_engine; self.evidence_engine=evidence_engine or EvidenceEngine(); self.citation_engine=citation_engine or CitationEngine(); self.conflict_engine=conflict_engine or ConflictDetectionEngine(); self.report_builder=report_builder or ReportBuilder(); self.repository=repository; self.memory=memory

    async def run(self,user_id:UUID,request:ResearchRequest,research_id:UUID|None=None)->ResearchResult:
        created=datetime.now(timezone.utc); rid=research_id or uuid4(); reused=[]; warnings=[]
        if request.reuse_memory and self.memory:
            try: reused=await self.memory.search(user_id,request.query,limit=min(request.max_sources,8))
            except Exception as exc: warnings.append(f"Memory reuse unavailable: {exc}")
        raw,warns=await self.search_engine.search(request.query,request.providers,request.max_sources,user_id)
        warnings.extend(warns)
        evidence=self.evidence_engine.collect(raw,request.query,request.max_sources)
        citations=self.citation_engine.generate(evidence)
        conflicts=self.conflict_engine.detect(evidence)
        report=self.report_builder.build(request.query,evidence,citations,conflicts) if request.include_report else None
        status="completed" if evidence else "partial"
        result=ResearchResult(id=rid,user_id=user_id,query=request.query,status=status,evidence=evidence,citations=citations,conflicts=conflicts,report=report,reused_memory=reused,warnings=warnings,created_at=created,completed_at=datetime.now(timezone.utc))
        if self.repository: await self.repository.save(result)
        if self.memory and (evidence or report):
            content=report.executive_summary if report else " ".join(x.claim for x in evidence[:3])
            try:
                from backend.app.domain.memories import MemoryType
                await self.memory.store(user_id,MemoryType.KNOWLEDGE,content,source="research",metadata={"research_id":str(rid),"query":request.query,"citation_count":len(citations)})
            except Exception as exc: result.warnings.append(f"Research memory write unavailable: {exc}")
        return result

    async def get(self,user_id:UUID,research_id:UUID):
        return await self.repository.get(user_id,research_id) if self.repository else None

    async def history(self,user_id:UUID,limit:int=50):
        return await self.repository.history(user_id,limit) if self.repository else []
