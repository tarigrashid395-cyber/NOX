from __future__ import annotations
import asyncio
from backend.app.providers.search.base import SearchProvider, SearchResult
from uuid import UUID

class SearchEngine:
    def __init__(self, providers: dict[str, SearchProvider]):
        self.providers = providers

    async def search(self, query: str, provider_names: list[str], limit: int, user_id: UUID | None = None) -> tuple[list[SearchResult], list[str]]:
        selected = []
        for name in provider_names:
            provider = self.providers.get(name)
            if provider is None:
                continue
            scoped = provider.for_user(user_id) if user_id is not None and hasattr(provider, "for_user") else provider
            selected.append(scoped)
        warnings: list[str] = []
        if not selected:
            return [], ["No configured research search providers matched the request"]
        results = await asyncio.gather(*(p.search(query, limit) for p in selected), return_exceptions=True)
        merged: list[SearchResult] = []
        for provider, result in zip(selected, results):
            if isinstance(result, Exception):
                warnings.append(f"{provider.name}: {result}")
            else:
                merged.extend(result)
        return merged, warnings
