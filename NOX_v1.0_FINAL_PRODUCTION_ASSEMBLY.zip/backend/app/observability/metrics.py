from __future__ import annotations
from collections import defaultdict
from dataclasses import dataclass
from time import perf_counter
@dataclass
class MetricSnapshot:
    count:int=0; errors:int=0; total_latency_ms:float=0.0; total_value:float=0.0
    @property
    def success_rate(self): return (self.count-self.errors)/max(1,self.count)
    @property
    def avg_latency_ms(self): return self.total_latency_ms/max(1,self.count)
class MetricsRegistry:
    def __init__(self): self.data=defaultdict(MetricSnapshot)
    def observe(self,name,value=1.0,latency_ms=0.0,error=False):
        m=self.data[name]; m.count+=1; m.errors+=int(error); m.total_value+=value; m.total_latency_ms+=latency_ms
    def snapshot(self): return {k:{'count':v.count,'errors':v.errors,'success_rate':v.success_rate,'avg_latency_ms':v.avg_latency_ms,'total_value':v.total_value} for k,v in self.data.items()}
class MetricTimer:
    def __init__(self,registry,name): self.registry=registry; self.name=name; self.started=0
    def __enter__(self): self.started=perf_counter(); return self
    def __exit__(self,exc_type,exc,tb): self.registry.observe(self.name,latency_ms=(perf_counter()-self.started)*1000,error=exc is not None); return False
