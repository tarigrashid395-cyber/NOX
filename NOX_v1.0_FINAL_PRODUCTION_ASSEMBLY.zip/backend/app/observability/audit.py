from __future__ import annotations
from datetime import datetime,timezone
from collections import deque
from uuid import uuid4
class AuditLogger:
    def __init__(self,max_events=10000): self.events=deque(maxlen=max_events)
    def record(self,action,user_id=None,resource=None,metadata=None):
        item={'id':str(uuid4()),'action':action,'user_id':str(user_id) if user_id else None,'resource':resource,'metadata':metadata or {},'timestamp':datetime.now(timezone.utc).isoformat()}; self.events.append(item); return item
    def recent(self,limit=100): return list(self.events)[-limit:]
