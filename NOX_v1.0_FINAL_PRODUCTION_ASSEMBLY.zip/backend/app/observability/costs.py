from __future__ import annotations
from collections import defaultdict
class CostTracker:
    def __init__(self): self.data=defaultdict(float)
    def record(self,provider,amount): self.data[provider]+=float(amount)
    def summary(self): return dict(self.data)
