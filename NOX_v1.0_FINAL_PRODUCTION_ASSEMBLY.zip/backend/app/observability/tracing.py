from __future__ import annotations
from contextlib import contextmanager
from dataclasses import dataclass,field
from time import perf_counter
from uuid import uuid4
@dataclass
class Span:
    name:str; trace_id:str; span_id:str; started:float; attributes:dict=field(default_factory=dict); ended:float|None=None; error:str|None=None
    @property
    def duration_ms(self): return ((self.ended or perf_counter())-self.started)*1000
class Tracer:
    def __init__(self): self.spans=[]
    @contextmanager
    def span(self,name,**attributes):
        s=Span(name,str(uuid4()),str(uuid4()),perf_counter(),attributes); self.spans.append(s)
        try: yield s
        except Exception as exc: s.error=str(exc); raise
        finally: s.ended=perf_counter()
    def recent(self,limit=100): return self.spans[-limit:]
