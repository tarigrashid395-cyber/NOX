from __future__ import annotations
import re
class Redactor:
    PATTERNS=(re.compile(r'(?i)(password|token|secret|api[_-]?key)\s*[:=]\s*[^\s,;]+'),re.compile(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b'))
    def redact(self,text):
        value=text
        for pattern in self.PATTERNS: value=pattern.sub('[REDACTED]',value)
        return value
