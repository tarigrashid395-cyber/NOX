from contextlib import asynccontextmanager
from fastapi import FastAPI
from backend.app.config import get_settings
from backend.app.db.session import Database
from backend.app.core.container import build_container
from backend.app.agents.planning.agent import PlanningAgent
from backend.app.agents.study.agent import StudyAgent
from backend.app.agents.research.agent import ResearchAgent
from backend.app.agents.memory.agent import MemoryAgent
from backend.app.agents.file.agent import FileAgent
from backend.app.agents.visual.agent import VisualAgent
from backend.app.agents.motion.agent import MotionAgent
from backend.app.agents.creation.agent import CreationAgent
from backend.app.agents.export.agent import ExportAgent
from backend.app.security.auth import AuthRepository, AuthService
from backend.app.providers.redis.factory import build_redis_provider

class RedisClient:
    """Compatibility facade preserving the existing NOX Redis abstraction."""
    def __init__(self, settings_or_url):
        self._settings = settings_or_url if hasattr(settings_or_url, "redis_provider") else None
        self.url = getattr(settings_or_url, "redis_url", settings_or_url)
        self._client = None

    async def connect(self):
        try:
            if self._settings is not None:
                self._client = build_redis_provider(self._settings)
                if hasattr(self._client, "connect"):
                    await self._client.connect()
            else:
                from redis.asyncio import from_url
                self._client = from_url(self.url, decode_responses=True)
                await self._client.ping()
        except Exception:
            self._client = None

    async def ping(self):
        if self._client is None: raise RuntimeError('Redis unavailable')
        return await self._client.ping()

    async def rate_limit(self, key: str, limit: int, window: int) -> bool:
        if self._client is None: raise RuntimeError('Redis unavailable')
        if hasattr(self._client, "rate_limit"):
            return await self._client.rate_limit(key, limit, window)
        return True

    async def close(self):
        if self._client:
            if hasattr(self._client, "close"):
                await self._client.close()
            else:
                await self._client.aclose()

    def __getattr__(self, name):
        if name.startswith("_"):
            raise AttributeError(name)
        if self._client is None:
            raise AttributeError(name)
        return getattr(self._client, name)

class ObjectStorage:
    def __init__(self,settings): self.settings=settings
    async def ping(self):
        # MinIO is accessed through the provider layer; this foundation keeps a deterministic health contract.
        return True

@asynccontextmanager
async def lifespan(app:FastAPI):
    settings=get_settings(); database=Database(settings); redis=RedisClient(settings); storage=ObjectStorage(settings)
    await redis.connect()
    database.connect()
    production = settings.app_env.lower() in {"production", "prod"}
    if production and database.session_factory is None:
        raise RuntimeError("PostgreSQL driver/connection is required in production")
    if production and redis._client is None:
        raise RuntimeError("Redis connection is required in production")
    container=build_container(settings,database,redis,storage)
    auth_repo=AuthRepository(database.session_factory); await auth_repo.ensure_schema()
    if production and not auth_repo._db_ready:
        raise RuntimeError("Authentication database schema is unavailable in production")
    app.state.auth_service=AuthService(auth_repo,settings,redis=redis)
    app.state.oauth={k:v for k,v in {
        "google":{"client_id":getattr(settings,"google_client_id",None),"redirect_uri":getattr(settings,"google_redirect_uri",None),"authorize_url":"https://accounts.google.com/o/oauth2/v2/auth","scope":"openid email profile"},
        "github":{"client_id":getattr(settings,"github_client_id",None),"redirect_uri":getattr(settings,"github_redirect_uri",None),"authorize_url":"https://github.com/login/oauth/authorize","scope":"read:user user:email"}}.items() if v["client_id"] and v["redirect_uri"]}
    if hasattr(container.deep_research.repository, "ensure_deep_research_schema"):
        try: await container.deep_research.repository.ensure_deep_research_schema()
        except Exception:
            if production: raise
    if hasattr(container.research.repository, "ensure_schema"):
        try:
            await container.research.repository.ensure_schema()
        except Exception:
            if production: raise
    if hasattr(container.visual.repository, "ensure_schema"):
        try: await container.visual.repository.ensure_schema()
        except Exception:
            if production: raise
    if hasattr(container.motion.repository, "ensure_schema"):
        try: await container.motion.repository.ensure_schema()
        except Exception:
            if production: raise
    if hasattr(container.creation.repository, "ensure_schema"):
        try: await container.creation.repository.ensure_schema()
        except Exception:
            if production: raise
    if hasattr(container.export.repository, "ensure_schema"):
        try: await container.export.repository.ensure_schema()
        except Exception:
            if production: raise
    if hasattr(container.files.repository, "ensure_schema"):
        try: await container.files.repository.ensure_schema()
        except Exception:
            if production: raise
    for agent in [PlanningAgent(),StudyAgent(),ResearchAgent(container.research),MemoryAgent(),FileAgent(container.files),VisualAgent(container.visual),MotionAgent(container.motion),CreationAgent(container.creation),ExportAgent(container.export)]:
        container.registry.register(agent)
    container.workforce.register_defaults({'research':container.registry.get('research'),'file':container.registry.get('file'),'visual':container.registry.get('visual'),'creation':container.registry.get('creation')})
    await container.workforce.persist_definitions()
    if hasattr(container.evaluation.repository, 'ensure_schema'):
        try: await container.evaluation.repository.ensure_schema()
        except Exception:
            if production: raise
    if hasattr(container.analytics, 'ensure_schema'):
        try: await container.analytics.ensure_schema()
        except Exception:
            if production: raise
    await container.workforce.ensure_schema()
    for phase18_service in (container.execution, container.artifacts, container.workspaces.repository, container.missions):
        if hasattr(phase18_service, 'ensure_schema'):
            try: await phase18_service.ensure_schema()
            except Exception:
                if production: raise
    if database.session_factory:
        from sqlalchemy import text
        async with database.session_factory() as session:
            for skill in container.skills.registry.list():
                await session.execute(text('INSERT INTO skills(name,description,inputs,outputs,tool_requirements,memory_requirements,quality_requirements,confidence_requirements,agent_id,template) VALUES (:name,:description,:inputs,:outputs,:tools,:memory,:quality,:confidence,:agent,:template) ON CONFLICT (name) DO UPDATE SET description=EXCLUDED.description,inputs=EXCLUDED.inputs,outputs=EXCLUDED.outputs,tool_requirements=EXCLUDED.tool_requirements,memory_requirements=EXCLUDED.memory_requirements,quality_requirements=EXCLUDED.quality_requirements,confidence_requirements=EXCLUDED.confidence_requirements,agent_id=EXCLUDED.agent_id,template=EXCLUDED.template'), {'name':skill.name,'description':skill.description,'inputs':skill.inputs,'outputs':skill.outputs,'tools':skill.tool_requirements,'memory':skill.memory_requirements,'quality':skill.quality_requirements,'confidence':skill.confidence_requirements,'agent':skill.agent_id,'template':skill.template})
            await session.commit()
    for cognitive_service in (container.planner_service, container.reviewer_service):
        try: await cognitive_service.ensure_schema()
        except Exception:
            if production: raise
    if hasattr(container.graph.repository, 'ensure_schema'):
        try: await container.graph.repository.ensure_schema()
        except Exception:
            if production: raise
    if production and hasattr(container.files.storage, "ensure_bucket"):
        await container.files.storage.ensure_bucket()
    if production and hasattr(container.files.storage, "ping"):
        if not await container.files.storage.ping():
            raise RuntimeError("Object storage health check failed in production")
    container.graph.sources['agents']=[{'agent_type':a} for a in sorted(container.registry.names())]
    if production and container.llm is None:
        raise RuntimeError("A production LLM provider is required")
    app.state.container=container
    yield
    await redis.close(); await database.close()
