from backend.app.db.base import Base
# SQLAlchemy ORM models are introduced with their corresponding migration phase.
__all__=['Base']
