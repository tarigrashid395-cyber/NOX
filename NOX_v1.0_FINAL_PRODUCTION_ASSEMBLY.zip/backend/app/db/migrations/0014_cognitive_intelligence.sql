CREATE TABLE IF NOT EXISTS execution_plans (
  plan_id UUID PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  conversation_id UUID NULL,
  goal TEXT NOT NULL,
  task_type VARCHAR(64) NOT NULL,
  complexity VARCHAR(16) NOT NULL,
  complexity_score DOUBLE PRECISION NOT NULL CHECK (complexity_score BETWEEN 0 AND 100),
  difficulty_score DOUBLE PRECISION NOT NULL CHECK (difficulty_score BETWEEN 0 AND 100),
  risk_score DOUBLE PRECISION NOT NULL CHECK (risk_score BETWEEN 0 AND 100),
  required_agents JSONB NOT NULL,
  required_tools JSONB NOT NULL,
  execution_steps JSONB NOT NULL,
  estimated_context_size INTEGER NOT NULL CHECK (estimated_context_size >= 0),
  estimated_cost DOUBLE PRECISION NOT NULL CHECK (estimated_cost >= 0),
  confidence DOUBLE PRECISION NOT NULL CHECK (confidence BETWEEN 0 AND 1),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS ix_execution_plans_user_id ON execution_plans(user_id);
CREATE INDEX IF NOT EXISTS ix_execution_plans_created_at ON execution_plans(created_at);
CREATE TABLE IF NOT EXISTS review_reports (
  review_id UUID PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  plan_id UUID NULL,
  iteration INTEGER NOT NULL CHECK (iteration BETWEEN 1 AND 2),
  accuracy_score DOUBLE PRECISION NOT NULL CHECK (accuracy_score BETWEEN 0 AND 100),
  reasoning_score DOUBLE PRECISION NOT NULL CHECK (reasoning_score BETWEEN 0 AND 100),
  clarity_score DOUBLE PRECISION NOT NULL CHECK (clarity_score BETWEEN 0 AND 100),
  completeness_score DOUBLE PRECISION NOT NULL CHECK (completeness_score BETWEEN 0 AND 100),
  educational_quality_score DOUBLE PRECISION NOT NULL CHECK (educational_quality_score BETWEEN 0 AND 100),
  source_score DOUBLE PRECISION NOT NULL CHECK (source_score BETWEEN 0 AND 100),
  confidence_score DOUBLE PRECISION NOT NULL CHECK (confidence_score BETWEEN 0 AND 100),
  overall_score DOUBLE PRECISION NOT NULL CHECK (overall_score BETWEEN 0 AND 100),
  needs_revision BOOLEAN NOT NULL,
  feedback JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS ix_review_reports_user_id ON review_reports(user_id);
CREATE INDEX IF NOT EXISTS ix_review_reports_plan_id ON review_reports(plan_id);
