-- NOX Phase 16 — Autonomous Deep Research
CREATE TABLE IF NOT EXISTS deep_research_projects (
    project_id UUID PRIMARY KEY,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    goal TEXT NOT NULL,
    status VARCHAR(32) NOT NULL DEFAULT 'active',
    created_at TIMESTAMPTZ NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_deep_research_projects_user_id ON deep_research_projects(user_id);

CREATE TABLE IF NOT EXISTS deep_research_sessions (
    session_id UUID PRIMARY KEY,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    project_id UUID NULL REFERENCES deep_research_projects(project_id) ON DELETE SET NULL,
    goal TEXT NOT NULL,
    status VARCHAR(32) NOT NULL,
    depth VARCHAR(16) NOT NULL,
    session_json JSONB NOT NULL,
    report_id UUID NULL,
    created_at TIMESTAMPTZ NOT NULL,
    completed_at TIMESTAMPTZ NULL
);
CREATE INDEX IF NOT EXISTS ix_deep_research_sessions_user_id ON deep_research_sessions(user_id);
CREATE INDEX IF NOT EXISTS ix_deep_research_sessions_project_id ON deep_research_sessions(project_id);

CREATE TABLE IF NOT EXISTS deep_research_sources (
    source_key TEXT NOT NULL,
    session_id UUID NOT NULL REFERENCES deep_research_sessions(session_id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    url TEXT NULL,
    provider TEXT NOT NULL,
    metadata JSONB NOT NULL,
    PRIMARY KEY (session_id, source_key)
);

CREATE TABLE IF NOT EXISTS deep_research_evidence (
    evidence_id UUID PRIMARY KEY,
    session_id UUID NOT NULL REFERENCES deep_research_sessions(session_id) ON DELETE CASCADE,
    source_id TEXT NOT NULL,
    claim TEXT NOT NULL,
    excerpt TEXT NOT NULL,
    score DOUBLE PRECISION NOT NULL,
    confidence DOUBLE PRECISION NOT NULL,
    evidence_json JSONB NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_deep_research_evidence_session_id ON deep_research_evidence(session_id);

CREATE TABLE IF NOT EXISTS deep_research_reports (
    report_id UUID PRIMARY KEY,
    session_id UUID NOT NULL REFERENCES deep_research_sessions(session_id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    project_id UUID NULL REFERENCES deep_research_projects(project_id) ON DELETE SET NULL,
    report_json JSONB NOT NULL,
    created_at TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_deep_research_reports_user_id ON deep_research_reports(user_id);

CREATE TABLE IF NOT EXISTS deep_research_evidence_edges (
    id UUID PRIMARY KEY,
    session_id UUID NOT NULL REFERENCES deep_research_sessions(session_id) ON DELETE CASCADE,
    source_node TEXT NOT NULL,
    target_node TEXT NOT NULL,
    relation TEXT NOT NULL,
    weight DOUBLE PRECISION NOT NULL,
    metadata JSONB NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_deep_research_evidence_edges_session_id ON deep_research_evidence_edges(session_id);
