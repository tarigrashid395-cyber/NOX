BEGIN;

CREATE TABLE IF NOT EXISTS workspaces (
    id UUID PRIMARY KEY,
    owner_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    archived BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS ix_workspaces_owner ON workspaces(owner_id);

CREATE TABLE IF NOT EXISTS tasks (
    id UUID PRIMARY KEY,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    workspace_id UUID NULL REFERENCES workspaces(id) ON DELETE SET NULL,
    conversation_id UUID NULL,
    goal TEXT NOT NULL,
    status VARCHAR(20) NOT NULL CHECK (status IN ('queued','planning','running','waiting','retrying','completed','failed','cancelled')),
    task_type VARCHAR(64) NOT NULL,
    complexity VARCHAR(16) NOT NULL,
    plan_id UUID NULL,
    progress DOUBLE PRECISION NOT NULL DEFAULT 0 CHECK (progress >= 0 AND progress <= 100),
    current_step INTEGER NOT NULL DEFAULT 0 CHECK (current_step >= 0),
    total_steps INTEGER NOT NULL DEFAULT 0 CHECK (total_steps >= 0),
    retry_count INTEGER NOT NULL DEFAULT 0 CHECK (retry_count >= 0),
    max_retries INTEGER NOT NULL DEFAULT 3 CHECK (max_retries >= 0),
    metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
    error TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    started_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS ix_tasks_user_status ON tasks(user_id,status);
CREATE INDEX IF NOT EXISTS ix_tasks_workspace ON tasks(workspace_id);
CREATE INDEX IF NOT EXISTS ix_tasks_created_at ON tasks(created_at);

CREATE TABLE IF NOT EXISTS task_steps (
    id UUID PRIMARY KEY,
    task_id UUID NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    step_number INTEGER NOT NULL CHECK (step_number > 0),
    objective TEXT NOT NULL,
    status VARCHAR(20) NOT NULL,
    agent VARCHAR(120),
    tool VARCHAR(120),
    input JSONB NOT NULL DEFAULT '{}'::jsonb,
    output JSONB NOT NULL DEFAULT '{}'::jsonb,
    confidence DOUBLE PRECISION NOT NULL DEFAULT 0 CHECK (confidence >= 0 AND confidence <= 1),
    retry_count INTEGER NOT NULL DEFAULT 0,
    started_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    error TEXT,
    UNIQUE(task_id,step_number)
);
CREATE INDEX IF NOT EXISTS ix_task_steps_task ON task_steps(task_id,step_number);

CREATE TABLE IF NOT EXISTS task_events (
    id UUID PRIMARY KEY,
    task_id UUID NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    event VARCHAR(100) NOT NULL,
    status VARCHAR(20),
    progress DOUBLE PRECISION,
    payload JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS ix_task_events_task_created ON task_events(task_id,created_at);

CREATE TABLE IF NOT EXISTS task_results (
    id UUID PRIMARY KEY,
    task_id UUID NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    status VARCHAR(20) NOT NULL,
    content TEXT NOT NULL,
    confidence DOUBLE PRECISION NOT NULL CHECK (confidence >= 0 AND confidence <= 1),
    review_score DOUBLE PRECISION CHECK (review_score IS NULL OR (review_score >= 0 AND review_score <= 100)),
    artifact_ids JSONB NOT NULL DEFAULT '[]'::jsonb,
    metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS ix_task_results_task ON task_results(task_id,created_at);

CREATE TABLE IF NOT EXISTS task_artifacts (
    id UUID PRIMARY KEY,
    owner_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    task_id UUID NULL REFERENCES tasks(id) ON DELETE SET NULL,
    mission_id UUID NULL,
    workspace_id UUID NULL REFERENCES workspaces(id) ON DELETE SET NULL,
    title TEXT NOT NULL,
    type VARCHAR(40) NOT NULL,
    storage_key TEXT NOT NULL UNIQUE,
    download_url TEXT NOT NULL,
    size_bytes BIGINT NOT NULL CHECK (size_bytes >= 0),
    content_type TEXT NOT NULL,
    metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS ix_task_artifacts_owner ON task_artifacts(owner_id,created_at);
CREATE INDEX IF NOT EXISTS ix_task_artifacts_task ON task_artifacts(task_id);
CREATE INDEX IF NOT EXISTS ix_task_artifacts_workspace ON task_artifacts(workspace_id);

CREATE TABLE IF NOT EXISTS missions (
    id UUID PRIMARY KEY,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    workspace_id UUID NULL REFERENCES workspaces(id) ON DELETE SET NULL,
    conversation_id UUID NULL,
    goal TEXT NOT NULL,
    status VARCHAR(20) NOT NULL CHECK (status IN ('queued','running','reviewing','completed','failed','cancelled')),
    selected_agents JSONB NOT NULL DEFAULT '[]'::jsonb,
    progress DOUBLE PRECISION NOT NULL DEFAULT 0 CHECK (progress >= 0 AND progress <= 100),
    result TEXT NOT NULL DEFAULT '',
    confidence DOUBLE PRECISION NOT NULL DEFAULT 0 CHECK (confidence >= 0 AND confidence <= 1),
    artifact_ids JSONB NOT NULL DEFAULT '[]'::jsonb,
    metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
    error TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS ix_missions_user_status ON missions(user_id,status);
CREATE INDEX IF NOT EXISTS ix_missions_workspace ON missions(workspace_id);

CREATE TABLE IF NOT EXISTS tool_executions (
    id UUID PRIMARY KEY,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    tool_id VARCHAR(120) NOT NULL,
    status VARCHAR(32) NOT NULL,
    duration_ms DOUBLE PRECISION NOT NULL DEFAULT 0,
    success BOOLEAN NOT NULL,
    metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS ix_tool_executions_user ON tool_executions(user_id,created_at);

COMMIT;
