-- NOX Phase 17: Autonomous Agent Workforce
CREATE TABLE IF NOT EXISTS agents (
    id VARCHAR(100) PRIMARY KEY,
    name VARCHAR(160) NOT NULL,
    description TEXT NOT NULL,
    capabilities JSONB NOT NULL,
    tools JSONB NOT NULL,
    confidence DOUBLE PRECISION NOT NULL CHECK (confidence BETWEEN 0 AND 1),
    specialization TEXT NOT NULL,
    status VARCHAR(32) NOT NULL,
    cost_profile JSONB NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS agent_sessions (
    id UUID PRIMARY KEY,
    user_id UUID NOT NULL,
    mode VARCHAR(32) NOT NULL,
    selected_agents JSONB NOT NULL,
    started_at TIMESTAMPTZ NOT NULL,
    completed_at TIMESTAMPTZ
);
CREATE TABLE IF NOT EXISTS agent_executions (
    id UUID PRIMARY KEY,
    session_id UUID NOT NULL REFERENCES agent_sessions(id) ON DELETE CASCADE,
    agent_id VARCHAR(100) NOT NULL,
    status VARCHAR(32) NOT NULL,
    content TEXT NOT NULL,
    confidence DOUBLE PRECISION NOT NULL CHECK (confidence BETWEEN 0 AND 1),
    findings JSONB NOT NULL,
    conclusions JSONB NOT NULL,
    observations JSONB NOT NULL,
    error TEXT,
    metrics JSONB NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS skills (
    name VARCHAR(120) PRIMARY KEY,
    description TEXT NOT NULL,
    inputs JSONB NOT NULL,
    outputs JSONB NOT NULL,
    tool_requirements JSONB NOT NULL,
    memory_requirements JSONB NOT NULL,
    quality_requirements JSONB NOT NULL,
    confidence_requirements DOUBLE PRECISION NOT NULL CHECK (confidence_requirements BETWEEN 0 AND 1),
    agent_id VARCHAR(100) NOT NULL,
    template TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS skill_executions (
    id UUID PRIMARY KEY,
    user_id UUID NOT NULL,
    skill VARCHAR(120) NOT NULL REFERENCES skills(name),
    status VARCHAR(32) NOT NULL,
    output JSONB NOT NULL,
    confidence DOUBLE PRECISION NOT NULL CHECK (confidence BETWEEN 0 AND 1),
    chained JSONB NOT NULL,
    error TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS agent_metrics (
    id UUID PRIMARY KEY,
    user_id UUID NOT NULL,
    agent_id VARCHAR(100),
    event VARCHAR(100) NOT NULL,
    value DOUBLE PRECISION NOT NULL,
    success BOOLEAN NOT NULL,
    metadata JSONB NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS agent_memory (
    id UUID PRIMARY KEY,
    user_id UUID NOT NULL,
    agent_id VARCHAR(100) NOT NULL,
    memory_type VARCHAR(64) NOT NULL,
    content JSONB NOT NULL,
    confidence DOUBLE PRECISION NOT NULL CHECK (confidence BETWEEN 0 AND 1),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_agent_sessions_user ON agent_sessions(user_id, started_at DESC);
CREATE INDEX IF NOT EXISTS idx_agent_executions_session ON agent_executions(session_id, created_at);
CREATE INDEX IF NOT EXISTS idx_agent_metrics_user ON agent_metrics(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_agent_memory_user_agent ON agent_memory(user_id, agent_id, created_at DESC);
