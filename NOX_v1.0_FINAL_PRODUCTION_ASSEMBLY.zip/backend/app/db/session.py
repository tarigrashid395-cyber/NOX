from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from urllib.parse import urlparse
from sqlalchemy.ext.asyncio import AsyncEngine, AsyncSession, async_sessionmaker, create_async_engine
from backend.app.config import Settings

class Database:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.engine: AsyncEngine | None = None
        self.session_factory = None

    def connect(self):
        if self.engine is None and self.session_factory is None:
            if not self.settings.database_url:
                raise RuntimeError("DATABASE_URL is required")
            kwargs = {
                "pool_pre_ping": True,
                "pool_recycle": 1800,
                "pool_size": self.settings.database_pool_size,
                "max_overflow": self.settings.database_max_overflow,
            }
            host = (urlparse(self.settings.database_url).hostname or "").lower()
            if "supabase.co" in host:
                kwargs["connect_args"] = {"ssl": "require", "statement_cache_size": 0}
            try:
                self.engine = create_async_engine(self.settings.database_url, **kwargs)
                self.session_factory = async_sessionmaker(self.engine, expire_on_commit=False)
            except ModuleNotFoundError:
                if self.settings.app_env.lower() in {"production", "prod"}:
                    raise
                self.engine = None
                self.session_factory = None
        return self

    async def ping(self) -> bool:
        self.connect()
        from sqlalchemy import text
        async with self.engine.connect() as conn:
            await conn.execute(text("SELECT 1"))
        return True

    async def close(self):
        if self.engine:
            await self.engine.dispose()
            self.engine = None
            self.session_factory = None

    @asynccontextmanager
    async def session(self) -> AsyncIterator[AsyncSession]:
        self.connect()
        async with self.session_factory() as session:
            yield session
