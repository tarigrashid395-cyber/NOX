from typing import Generic, TypeVar
from uuid import UUID
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
T=TypeVar('T')
class Repository(Generic[T]):
    def __init__(self, session: AsyncSession, model:type[T]): self.session=session; self.model=model
    async def get(self, entity_id:UUID): return await self.session.get(self.model, entity_id)
    async def add(self, entity:T)->T: self.session.add(entity); await self.session.flush(); return entity
    async def list(self, limit:int=50): return list((await self.session.execute(select(self.model).limit(limit))).scalars())
