from __future__ import annotations
from datetime import datetime, timezone
from typing import Literal
from uuid import UUID, uuid4
from pydantic import BaseModel, ConfigDict, Field

ArtifactType = Literal['markdown','html','json','csv','txt','research_report','study_notes','project_report']

class Artifact(BaseModel):
    model_config = ConfigDict(extra='forbid')
    id: UUID = Field(default_factory=uuid4)
    title: str
    type: ArtifactType
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    owner_id: UUID
    task_id: UUID | None = None
    mission_id: UUID | None = None
    workspace_id: UUID | None = None
    download_url: str
    size_bytes: int = Field(ge=0)
    content_type: str
    metadata: dict = Field(default_factory=dict)
    content: str | None = None
