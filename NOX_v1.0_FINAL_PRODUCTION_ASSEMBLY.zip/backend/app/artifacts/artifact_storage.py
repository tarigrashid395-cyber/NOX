from __future__ import annotations
from typing import Protocol

class ArtifactStorage(Protocol):
    async def put(self, key: str, data: bytes, content_type: str) -> str: ...
    async def get(self, key: str) -> bytes: ...
    async def delete(self, key: str) -> None: ...

class InMemoryArtifactStorage:
    def __init__(self): self._objects: dict[str, bytes] = {}
    async def put(self,key,data,content_type): self._objects[key]=data; return key
    async def get(self,key):
        if key not in self._objects: raise KeyError(key)
        return self._objects[key]
    async def delete(self,key): self._objects.pop(key,None)

class ProviderArtifactStorage:
    def __init__(self, provider): self.provider=provider
    async def put(self,key,data,content_type): return await self.provider.put(key,data,content_type)
    async def get(self,key): return await self.provider.get(key)
    async def delete(self,key): return await self.provider.delete(key)
