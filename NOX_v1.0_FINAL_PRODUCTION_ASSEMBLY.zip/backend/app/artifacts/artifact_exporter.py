from __future__ import annotations
import csv, io, json

class ArtifactExporter:
    CONTENT_TYPES = {
        'markdown':'text/markdown; charset=utf-8','html':'text/html; charset=utf-8','json':'application/json',
        'csv':'text/csv; charset=utf-8','txt':'text/plain; charset=utf-8','research_report':'text/markdown; charset=utf-8',
        'study_notes':'text/markdown; charset=utf-8','project_report':'text/markdown; charset=utf-8'
    }
    def render(self, artifact_type: str, content) -> tuple[bytes,str,str]:
        if artifact_type == 'json':
            text=json.dumps(content, ensure_ascii=False, indent=2, default=str)
        elif artifact_type == 'csv':
            rows=content if isinstance(content,list) else content.get('rows',[]) if isinstance(content,dict) else []
            output=io.StringIO();
            if rows:
                fields=sorted({k for row in rows if isinstance(row,dict) for k in row})
                writer=csv.DictWriter(output,fieldnames=fields); writer.writeheader(); writer.writerows(rows)
            text=output.getvalue()
        elif artifact_type == 'html':
            raw=str(content); text=f'<!doctype html><html><head><meta charset="utf-8"><title>NOX Artifact</title></head><body>{raw}</body></html>'
        else:
            text=str(content)
        ext='md' if artifact_type in {'markdown','research_report','study_notes','project_report'} else artifact_type
        return text.encode('utf-8'), self.CONTENT_TYPES[artifact_type], ext
