from __future__ import annotations
import re
from uuid import UUID
from .artifact_models import Artifact
from .artifact_exporter import ArtifactExporter
from .artifact_storage import ArtifactStorage

class ArtifactGenerator:
    def __init__(self, storage: ArtifactStorage, exporter: ArtifactExporter, session_factory=None):
        self.storage,self.exporter,self.session_factory=storage,exporter,session_factory
        self._items: dict[UUID,Artifact] = {}

    async def ensure_schema(self):
        if not self.session_factory: return
        from sqlalchemy import text
        async with self.session_factory() as s:
            await s.execute(text('CREATE TABLE IF NOT EXISTS task_artifacts (id UUID PRIMARY KEY,owner_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,task_id UUID NULL,mission_id UUID NULL,workspace_id UUID NULL,title TEXT NOT NULL,type VARCHAR(40) NOT NULL,storage_key TEXT NOT NULL UNIQUE,download_url TEXT NOT NULL,size_bytes BIGINT NOT NULL,content_type TEXT NOT NULL,metadata JSONB NOT NULL DEFAULT \'{}\'::jsonb,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW())'))
            await s.execute(text('CREATE INDEX IF NOT EXISTS ix_task_artifacts_owner ON task_artifacts(owner_id)')); await s.execute(text('CREATE INDEX IF NOT EXISTS ix_task_artifacts_task ON task_artifacts(task_id)')); await s.commit()

    async def create(self, owner_id: UUID, title: str, artifact_type: str, content, task_id=None, mission_id=None, workspace_id=None, metadata=None) -> Artifact:
        data, mime, ext = self.exporter.render(artifact_type, content)
        artifact_id=__import__('uuid').uuid4(); safe=re.sub(r'[^A-Za-z0-9._-]+','_',title).strip('_') or 'artifact'; key=f'artifacts/{owner_id}/{artifact_id}/{safe}.{ext}'
        await self.storage.put(key,data,mime)
        artifact=Artifact(id=artifact_id,title=title,type=artifact_type,owner_id=owner_id,task_id=task_id,mission_id=mission_id,workspace_id=workspace_id,download_url=f'/api/v1/artifacts/{artifact_id}',size_bytes=len(data),content_type=mime,metadata=metadata or {},content=content if isinstance(content,str) else None)
        self._items[artifact.id]=artifact
        if self.session_factory:
            from sqlalchemy import text
            async with self.session_factory() as s:
                await s.execute(text('INSERT INTO task_artifacts(id,owner_id,task_id,mission_id,workspace_id,title,type,storage_key,download_url,size_bytes,content_type,metadata) VALUES (:id,:owner,:task,:mission,:workspace,:title,:type,:key,:url,:size,:mime,:metadata)'),{'id':artifact.id,'owner':owner_id,'task':task_id,'mission':mission_id,'workspace':workspace_id,'title':title,'type':artifact_type,'key':key,'url':artifact.download_url,'size':len(data),'mime':mime,'metadata':artifact.metadata}); await s.commit()
        return artifact

    async def get(self, owner_id: UUID, artifact_id: UUID, include_content=False) -> Artifact | None:
        artifact=self._items.get(artifact_id)
        key=None
        if artifact is None and self.session_factory:
            from sqlalchemy import text
            async with self.session_factory() as s:
                row=(await s.execute(text('SELECT * FROM task_artifacts WHERE id=:id AND owner_id=:owner'),{'id':artifact_id,'owner':owner_id})).mappings().first()
            if row:
                artifact=Artifact(id=row['id'],title=row['title'],type=row['type'],owner_id=row['owner_id'],task_id=row['task_id'],mission_id=row['mission_id'],workspace_id=row['workspace_id'],download_url=row['download_url'],size_bytes=row['size_bytes'],content_type=row['content_type'],metadata=row['metadata']); key=row['storage_key']; self._items[artifact.id]=artifact
        if artifact is None or artifact.owner_id != owner_id: return None
        if include_content and artifact.content is None:
            if key is None: key=f'artifacts/{owner_id}/{artifact.id}'
            try: artifact.content=(await self.storage.get(key)).decode('utf-8')
            except Exception:
                artifact.content = None
        return artifact
