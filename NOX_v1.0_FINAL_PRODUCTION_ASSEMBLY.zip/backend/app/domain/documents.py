from dataclasses import dataclass, field
from datetime import datetime
from uuid import UUID, uuid4
from typing import Any

@dataclass(frozen=True)
class Document:
    id: UUID = field(default_factory=uuid4)
    user_id: UUID = field(default_factory=uuid4)
    filename: str = ""
    media_type: str = "application/octet-stream"
    size_bytes: int = 0
    status: str = "uploaded"
    metadata: dict[str, Any] = field(default_factory=dict)
    created_at: datetime | None = None
