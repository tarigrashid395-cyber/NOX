from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any
from uuid import UUID, uuid4

@dataclass(slots=True)
class VisualArtifactRecord:
    id: UUID
    user_id: UUID
    visual_type: str
    title: str
    schema_version: str
    payload: dict[str, Any]
    source_refs: list[str] = field(default_factory=list)
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
