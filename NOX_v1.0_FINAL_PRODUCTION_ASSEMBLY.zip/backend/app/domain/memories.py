from __future__ import annotations
from datetime import datetime
from enum import StrEnum
from typing import Any
from uuid import UUID, uuid4
from pydantic import BaseModel, Field, ConfigDict

class MemoryType(StrEnum):
    USER = "user"
    CONVERSATION = "conversation"
    SEMANTIC = "semantic"
    KNOWLEDGE = "knowledge"
    GOAL = "goal"
    PROJECT = "project"

class MemoryBase(BaseModel):
    model_config = ConfigDict(extra="forbid")
    id: UUID = Field(default_factory=uuid4)
    user_id: UUID
    content: str = Field(min_length=1)
    importance: float = Field(default=0.5, ge=0, le=1)
    confidence: float = Field(default=1.0, ge=0, le=1)
    tags: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)
    source: str = "user"
    created_at: datetime | None = None
    updated_at: datetime | None = None
    archived_at: datetime | None = None

class UserMemory(MemoryBase):
    memory_type: MemoryType = MemoryType.USER

class ConversationMemory(MemoryBase):
    memory_type: MemoryType = MemoryType.CONVERSATION
    conversation_id: UUID | None = None

class SemanticMemory(MemoryBase):
    memory_type: MemoryType = MemoryType.SEMANTIC

class KnowledgeMemory(MemoryBase):
    memory_type: MemoryType = MemoryType.KNOWLEDGE
    source_uri: str | None = None

class GoalMemory(MemoryBase):
    memory_type: MemoryType = MemoryType.GOAL
    goal_status: str = "active"
    target_date: datetime | None = None

class ProjectMemory(MemoryBase):
    memory_type: MemoryType = MemoryType.PROJECT
    project_id: UUID | None = None
