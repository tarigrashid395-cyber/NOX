from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any
from uuid import UUID
@dataclass(slots=True)
class ArtifactRecord:
    id: UUID
    user_id: UUID
    kind: str
    title: str
    payload: dict[str, Any]
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
