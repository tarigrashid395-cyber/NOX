from dataclasses import dataclass, field
from uuid import UUID, uuid4
from typing import Any

@dataclass(frozen=True)
class KnowledgeItem:
    id: UUID = field(default_factory=uuid4)
    document_id: UUID = field(default_factory=uuid4)
    kind: str = "fact"
    subject: str = ""
    predicate: str = ""
    object: str = ""
    confidence: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)
