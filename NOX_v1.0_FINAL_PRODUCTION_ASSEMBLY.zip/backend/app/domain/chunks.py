from dataclasses import dataclass, field
from uuid import UUID, uuid4
from typing import Any

@dataclass(frozen=True)
class DocumentChunk:
    id: UUID = field(default_factory=uuid4)
    document_id: UUID = field(default_factory=uuid4)
    ordinal: int = 0
    content: str = ""
    heading_path: tuple[str, ...] = ()
    metadata: dict[str, Any] = field(default_factory=dict)
