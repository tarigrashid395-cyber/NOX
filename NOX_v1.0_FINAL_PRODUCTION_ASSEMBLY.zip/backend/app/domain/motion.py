from dataclasses import dataclass
from datetime import datetime, timezone
from uuid import UUID
@dataclass(slots=True)
class MotionProjectRecord:
    id: UUID; user_id: UUID; title: str; topic: str; created_at: datetime = None
    def __post_init__(self):
        if self.created_at is None: self.created_at=datetime.now(timezone.utc)
