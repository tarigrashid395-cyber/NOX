from __future__ import annotations
from enum import StrEnum
from uuid import UUID
from datetime import datetime
from pydantic import BaseModel, Field

class ResearchStatus(StrEnum):
    COMPLETED="completed"
    PARTIAL="partial"
    FAILED="failed"

class ResearchRun(BaseModel):
    id: UUID
    user_id: UUID
    query: str
    status: ResearchStatus
    created_at: datetime
    completed_at: datetime | None = None
    evidence_count: int = Field(default=0, ge=0)
    citation_count: int = Field(default=0, ge=0)
    conflict_count: int = Field(default=0, ge=0)
