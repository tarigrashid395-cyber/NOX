from __future__ import annotations
from datetime import datetime
from pydantic import BaseModel

class SourceReference(BaseModel):
    source_id: str
    title: str
    url: str | None = None
    provider: str
    accessed_at: datetime
