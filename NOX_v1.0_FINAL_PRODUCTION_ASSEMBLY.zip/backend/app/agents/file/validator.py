class FileResponseValidator:
    def validate(self,result:dict)->None:
        if not isinstance(result,dict): raise ValueError("File result must be an object")
        if "file" not in result and "answer" not in result: raise ValueError("File result missing expected payload")
