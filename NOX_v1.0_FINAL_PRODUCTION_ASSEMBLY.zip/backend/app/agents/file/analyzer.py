from backend.app.files.analyzer import FileAnalyzer
class AgentFileAnalyzer(FileAnalyzer): pass
