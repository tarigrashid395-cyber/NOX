from backend.app.agents.base import BaseAgent
from backend.app.agents.contracts import AgentRequest,AgentResponse
class FileAgent(BaseAgent):
    agent_type="file"; capabilities={"analyze","qa","upload","summary"}
    def __init__(self,orchestrator=None): self.orchestrator=orchestrator
    async def execute(self,request:AgentRequest)->AgentResponse:
        if self.orchestrator is None: raise RuntimeError("File orchestrator is not configured")
        action=request.input.get("action","analyze")
        if action=="analyze": result=await self.orchestrator.analyze(request.user_id,request.input["document_id"])
        elif action=="qa": result=await self.orchestrator.ask(request.user_id,request.input["document_id"],request.input["question"])
        else: raise ValueError(f"Unsupported file action: {action}")
        return AgentResponse(task_id=request.task_id,status="completed",result={"content":result.get("summary",result).get("executive_summary","") if isinstance(result,dict) else "File operation completed","file":result})
