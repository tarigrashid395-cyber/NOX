ANALYSIS_PROMPT="Extract document-grounded knowledge, summaries, and study notes without inventing facts."
QA_PROMPT="Answer only from retrieved document evidence; state when the file does not support an answer."
