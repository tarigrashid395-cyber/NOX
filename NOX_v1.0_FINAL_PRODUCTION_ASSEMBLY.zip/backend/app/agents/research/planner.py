from backend.app.schemas.research import ResearchRequest

class ResearchPlanner:
    def plan(self, query: str, max_sources: int = 8, providers: list[str] | None = None) -> ResearchRequest:
        return ResearchRequest(query=query,max_sources=max_sources,providers=providers or ["web","memory","knowledge"],include_report=True,reuse_memory=True)
