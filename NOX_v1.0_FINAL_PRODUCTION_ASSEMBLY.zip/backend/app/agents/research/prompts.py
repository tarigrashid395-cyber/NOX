RESEARCH_SYSTEM_INSTRUCTIONS = """Use only collected evidence. Preserve source attribution. Surface conflicts instead of hiding them. Do not invent facts, sources, quotations, or citations."""
