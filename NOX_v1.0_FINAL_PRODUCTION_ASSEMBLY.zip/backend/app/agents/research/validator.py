from backend.app.schemas.research import ResearchResult

class ResearchValidator:
    def validate(self,result: ResearchResult) -> list[str]:
        errors=[]
        if not result.query.strip(): errors.append("Research query is empty")
        if result.status not in {"completed","partial","failed"}: errors.append("Invalid research status")
        for citation in result.citations:
            if citation.index < 1: errors.append("Citation index must be positive")
        return errors
