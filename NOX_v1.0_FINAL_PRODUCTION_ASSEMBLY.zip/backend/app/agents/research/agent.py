from backend.app.agents.base import BaseAgent
from backend.app.agents.contracts import AgentRequest, AgentResponse

class ResearchAgent(BaseAgent):
    agent_type="research"
    capabilities={"research","citations","evidence","conflict_detection"}

    def __init__(self, orchestrator=None):
        self.orchestrator=orchestrator

    async def execute(self,request:AgentRequest)->AgentResponse:
        if self.orchestrator is None:
            raise RuntimeError("Research orchestrator is not configured")
        from backend.app.schemas.research import ResearchRequest
        research_request=ResearchRequest.model_validate(request.input.get("research") or {"query":request.input.get("text","")})
        result=await self.orchestrator.run(request.user_id,research_request)
        return AgentResponse(task_id=request.task_id,status=result.status,result={"content":result.report.executive_summary if result.report else "Research completed.","research":result.model_dump(mode="json")},citations=[c.model_dump(mode="json") for c in result.citations],warnings=result.warnings)
