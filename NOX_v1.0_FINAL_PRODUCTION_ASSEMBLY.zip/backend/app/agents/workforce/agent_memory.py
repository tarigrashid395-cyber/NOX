from __future__ import annotations
from collections import defaultdict
from typing import Any
from uuid import UUID
from sqlalchemy import text

class AgentMemory:
    def __init__(self, session_factory=None, memory_engine=None):
        self.session_factory=session_factory; self.memory_engine=memory_engine
        self._history=defaultdict(list)

    async def ensure_schema(self):
        if not self.session_factory: return
        async with self.session_factory() as s:
            await s.execute(text('''CREATE TABLE IF NOT EXISTS agent_memory (
                id UUID PRIMARY KEY, user_id UUID NOT NULL, agent_id VARCHAR(100) NOT NULL,
                memory_type VARCHAR(64) NOT NULL, content JSONB NOT NULL, confidence DOUBLE PRECISION NOT NULL,
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
            )''')); await s.commit()

    async def record(self,user_id:UUID,agent_id:str,memory_type:str,content:dict[str,Any],confidence:float=0.0):
        item={'agent_id':agent_id,'type':memory_type,'content':content,'confidence':confidence}
        self._history[user_id].append(item)
        if self.session_factory:
            from uuid import uuid4
            async with self.session_factory() as s:
                await s.execute(text('INSERT INTO agent_memory(id,user_id,agent_id,memory_type,content,confidence) VALUES (:id,:uid,:agent,:typ,:content,:conf)'),{'id':uuid4(),'uid':user_id,'agent':agent_id,'typ':memory_type,'content':content,'conf':confidence}); await s.commit()

    async def history(self,user_id:UUID,agent_id:str|None=None,limit:int=50):
        if self.session_factory:
            q='SELECT agent_id,memory_type,content,confidence,created_at FROM agent_memory WHERE user_id=:uid'
            params={'uid':user_id}
            if agent_id: q+=' AND agent_id=:agent'; params['agent']=agent_id
            q+=' ORDER BY created_at DESC LIMIT :limit'; params['limit']=limit
            async with self.session_factory() as s:
                rows=(await s.execute(text(q),params)).mappings().all()
            return [dict(r) for r in rows]
        rows=self._history.get(user_id,[])
        return [x for x in rows if not agent_id or x['agent_id']==agent_id][-limit:]

    async def relevant(self,user_id:UUID,agent_id:str,goal:str,limit:int=8):
        if self.memory_engine:
            try:
                results=await self.memory_engine.search(user_id,goal,limit=limit)
                return results if isinstance(results,list) else []
            except Exception:
                return await self.history(user_id,agent_id,limit)
        return await self.history(user_id,agent_id,limit)
