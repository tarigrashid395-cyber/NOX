from __future__ import annotations
from .agent_models import AgentDefinition, CostProfile, AgentExecutionRequest
from .agent_registry import AgentRegistry, LegacyAgentAdapter, MemoryWorkforceAgent, LLMWorkforceAgent
from .agent_router import AgentRouter
from .agent_memory import AgentMemory
from .agent_metrics import AgentMetrics
from backend.app.agents.workforce.agent_capabilities import CAPABILITIES

PROMPTS={
'research':'You are NOX Research Specialist. Produce evidence-backed research, distinguish facts from inference, surface uncertainty and cite sources when available. Never invent evidence.',
'study':'You are NOX Study Specialist. Teach clearly at the user\'s level, use structured explanations and practical checks for understanding. Do not fabricate facts.',
'coding':'You are NOX Coding Specialist. Design and reason about production software, prioritize correctness, security, maintainability and tests. State assumptions explicitly.',
'writing':'You are NOX Writing Specialist. Produce polished, audience-appropriate writing while preserving factual accuracy and requested intent.',
'analysis':'You are NOX Analysis Specialist. Compare evidence, identify assumptions, counterarguments, risks and conclusions. Separate observed facts from interpretation.',
'business':'You are NOX Business Specialist. Analyze markets, strategy, operations and commercial tradeoffs using evidence and explicit uncertainty.',
'project':'You are NOX Project Specialist. Turn goals into executable work with dependencies, milestones, risks, acceptance criteria and measurable outcomes.',
'file':'You are NOX File Intelligence Specialist. Ground every claim in supplied document context and clearly identify missing information.',
'creative':'You are NOX Creative Specialist. Develop original concepts, narratives and content systems aligned with the brief, audience and constraints.',
'visual':'You are NOX Visual Intelligence Specialist. Translate information into clear visual structures and use the existing Visual Engine when a rendered artifact is required.',
}

def _definition(agent_id,cap):
    c=CAPABILITIES[cap]
    return AgentDefinition(id=cap,name=f'{cap.title()} Agent',description=c.description,capabilities=[cap,c.name]+list(c.tools),tools=list(c.tools),confidence=.8,specialization=c.description,status='active',cost_profile=CostProfile(tier='standard',relative_cost=1.0,latency_weight=1.0))

class AgentWorkforce:
    def __init__(self,legacy_registry,session_factory,memory,llm,analytics):
        self.legacy_registry=legacy_registry; self.session_factory=session_factory
        self.memory=AgentMemory(session_factory,memory); self.metrics=AgentMetrics(analytics); self.registry=AgentRegistry(legacy_registry); self.router=AgentRouter(self.registry,self.metrics,self.memory)
        self.llm=llm
    async def ensure_schema(self):
        if not self.session_factory:return
        from sqlalchemy import text
        async with self.session_factory() as s:
            await s.execute(text('''CREATE TABLE IF NOT EXISTS agents (id VARCHAR(100) PRIMARY KEY,name VARCHAR(160) NOT NULL,description TEXT NOT NULL,capabilities JSONB NOT NULL,tools JSONB NOT NULL,confidence DOUBLE PRECISION NOT NULL,status VARCHAR(32) NOT NULL,specialization TEXT NOT NULL,cost_profile JSONB NOT NULL,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW())'''))
            await s.execute(text('''CREATE TABLE IF NOT EXISTS agent_sessions (id UUID PRIMARY KEY,user_id UUID NOT NULL,mode VARCHAR(32) NOT NULL,selected_agents JSONB NOT NULL,started_at TIMESTAMPTZ NOT NULL,completed_at TIMESTAMPTZ)'''))
            await s.execute(text('''CREATE TABLE IF NOT EXISTS agent_executions (id UUID PRIMARY KEY,session_id UUID NOT NULL,agent_id VARCHAR(100) NOT NULL,status VARCHAR(32) NOT NULL,content TEXT NOT NULL,confidence DOUBLE PRECISION NOT NULL,findings JSONB NOT NULL,conclusions JSONB NOT NULL,observations JSONB NOT NULL,error TEXT,metrics JSONB NOT NULL,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW())'''))
            await s.execute(text('''CREATE TABLE IF NOT EXISTS agent_metrics (id UUID PRIMARY KEY,user_id UUID NOT NULL,agent_id VARCHAR(100),event VARCHAR(100) NOT NULL,value DOUBLE PRECISION NOT NULL,success BOOLEAN NOT NULL,metadata JSONB NOT NULL,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW())'''))
            await s.execute(text('''CREATE TABLE IF NOT EXISTS skills (name VARCHAR(120) PRIMARY KEY,description TEXT NOT NULL,inputs JSONB NOT NULL,outputs JSONB NOT NULL,tool_requirements JSONB NOT NULL,memory_requirements JSONB NOT NULL,quality_requirements JSONB NOT NULL,confidence_requirements DOUBLE PRECISION NOT NULL,agent_id VARCHAR(100) NOT NULL,template TEXT NOT NULL,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW())'''))
            await s.execute(text('''CREATE TABLE IF NOT EXISTS skill_executions (id UUID PRIMARY KEY,user_id UUID NOT NULL,skill VARCHAR(120) NOT NULL,status VARCHAR(32) NOT NULL,output JSONB NOT NULL,confidence DOUBLE PRECISION NOT NULL,chained JSONB NOT NULL,error TEXT,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW())''')); await s.commit()
    def register_defaults(self,existing):
        for cap in CAPABILITIES:
            definition=_definition(cap,cap)
            impl=None
            if cap=='research' and existing.get('research'): impl=LegacyAgentAdapter(cap,existing['research'])
            elif cap=='file' and existing.get('file'): impl=LegacyAgentAdapter(cap,existing['file'])
            elif cap=='visual' and existing.get('visual'): impl=LegacyAgentAdapter(cap,existing['visual'])
            elif cap=='creative' and existing.get('creation'): impl=LegacyAgentAdapter(cap,existing['creation'])
            elif cap=='memory': impl=MemoryWorkforceAgent(self.memory.memory_engine)
            else: impl=LLMWorkforceAgent(cap,definition,self.llm,self.memory,PROMPTS[cap])
            self.registry.register(definition,impl)
    async def persist_definitions(self):
        if not self.session_factory: return
        from sqlalchemy import text
        async with self.session_factory() as s:
            for d in self.definitions():
                await s.execute(text('INSERT INTO agents(id,name,description,capabilities,tools,confidence,status,specialization,cost_profile) VALUES (:id,:name,:description,:capabilities,:tools,:confidence,:status,:specialization,:cost) ON CONFLICT (id) DO UPDATE SET name=EXCLUDED.name,description=EXCLUDED.description,capabilities=EXCLUDED.capabilities,tools=EXCLUDED.tools,confidence=EXCLUDED.confidence,status=EXCLUDED.status,specialization=EXCLUDED.specialization,cost_profile=EXCLUDED.cost_profile'),{'id':d.id,'name':d.name,'description':d.description,'capabilities':d.capabilities,'tools':d.tools,'confidence':d.confidence,'status':d.status.value,'specialization':d.specialization,'cost':d.cost_profile.model_dump(mode='json')})
            await s.commit()
    def definitions(self): return self.registry.list_definitions()
    def ready_for(self,task_type):
        cap=task_type if task_type in CAPABILITIES else None
        if cap is None: return False
        if cap not in self.registry.names(): return False
        _, implementation=self.registry.get(cap)
        return self.llm is not None or isinstance(implementation,(LegacyAgentAdapter,MemoryWorkforceAgent))
    async def execute(self,user_id,request):
        return await self.router.execute(request,user_id,request.conversation_id)

