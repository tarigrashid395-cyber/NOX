from __future__ import annotations
import asyncio
from time import perf_counter
from .agent_models import AgentExecutionRequest, AgentExecutionResult, WorkforceResult
from .agent_capabilities import TASK_CAPABILITIES

class AgentRouter:
    def __init__(self,registry,metrics=None,memory=None): self.registry=registry; self.metrics=metrics; self.memory=memory
    def candidates(self,required_capabilities=None,preferred_agents=None):
        required=set(required_capabilities or []); preferred=set(preferred_agents or []); scored=[]
        for a in self.registry.list_definitions():
            if a.status.value!='active': continue
            overlap=len(required & set(a.capabilities)); preference=2 if a.id in preferred else 0
            if required and overlap==0: continue
            scored.append((overlap*5+preference+a.confidence*2-a.cost_profile.relative_cost,a))
        return [a for _,a in sorted(scored,key=lambda x:x[0],reverse=True)]
    def route(self,task_type='chat',complexity='MEDIUM',mode='auto',max_agents=4,required_capabilities=None,preferred_agents=None):
        required=list(dict.fromkeys((required_capabilities or [])+TASK_CAPABILITIES.get(task_type,['analysis'])))
        if preferred_agents and mode in {'dual','team','workforce'}:
            preferred=[self.registry.get(x)[0] for x in preferred_agents if x in self.registry.names()]
            remaining=[a for a in self.candidates(required,preferred_agents) if a.id not in {x.id for x in preferred}]
            candidates=preferred+remaining
        else:
            candidates=self.candidates(required,preferred_agents) or self.candidates(['analysis'],preferred_agents)
        if mode=='single' or (mode=='auto' and complexity in {'SIMPLE','MEDIUM'}): return candidates[:1]
        if mode=='dual': return candidates[:2]
        if mode=='team': return candidates[:min(3,max_agents)]
        if mode=='workforce': return candidates[:max_agents]
        return candidates[:min(max_agents,3 if complexity=='EXPERT' else 2)]
    async def execute(self,request:AgentExecutionRequest,user_id,conversation_id=None):
        task_type=request.context.get('task_type','chat'); selected=self.route(task_type,request.complexity,request.mode,request.max_agents,request.required_capabilities,request.preferred_agents)
        if not selected: raise RuntimeError('No active workforce agent satisfies the requested capabilities')
        context=dict(request.context); context.update({'user_id':user_id,'conversation_id':conversation_id})
        started=perf_counter()
        for definition in selected:
            if self.metrics: await self.metrics.record(user_id,'agent_selected',1,True,definition.id,{'mode':request.mode,'complexity':request.complexity})
        async def one(definition):
            _,implementation=self.registry.get(definition.id)
            try:
                result=await implementation.execute(request,context)
                if self.memory: await self.memory.record(user_id,definition.id,'execution',result.model_dump(mode='json'),result.confidence)
                if self.metrics:
                    await self.metrics.record(user_id,'agent_completed',1,True,definition.id,{'confidence':result.confidence},result.metrics.get('latency_ms',0))
                    await self.metrics.record(user_id,'confidence_score',result.confidence,True,definition.id)
                return result
            except Exception as exc:
                if self.metrics: await self.metrics.record(user_id,'agent_failed',1,False,definition.id,{'error':type(exc).__name__})
                return AgentExecutionResult(agent_id=definition.id,status='failed',error=str(exc),confidence=0)
        executions=await asyncio.gather(*(one(a) for a in selected))
        confidence_exchange={x.agent_id:x.confidence for x in executions if x.status=='completed'}
        for execution in executions:
            execution.confidence_exchange=confidence_exchange
            
            from .agent_models import AgentMessage
            execution.messages=[AgentMessage(sender=execution.agent_id,recipient=other.agent_id,message_type='confidence_exchange',content=f'confidence={execution.confidence:.3f}',confidence=execution.confidence) for other in executions if other.agent_id != execution.agent_id and other.status=='completed']
        good=[x for x in executions if x.status=='completed' and x.content]
        merged=self._merge(good,request.goal)
        mode='single' if len(selected)==1 else ('dual' if len(selected)==2 else ('team' if request.mode in {'team','auto'} else 'workforce'))
        if self.metrics: await self.metrics.record(user_id,'team_execution' if len(selected)>1 else 'agent_completed',1,all(x.status=='completed' for x in executions),metadata={'agents':[x.agent_id for x in executions],'latency_ms':(perf_counter()-started)*1000})
        if len(selected)>3 and self.metrics: await self.metrics.record(user_id,'workforce_execution',1,all(x.status=='completed' for x in executions),metadata={'agents':[x.agent_id for x in executions]})
        confidence=sum(x.confidence for x in good)/max(1,len(good))
        return WorkforceResult(mode=mode,selected_agents=[a.id for a in selected],executions=executions,merged_response=merged,confidence=confidence,completed_at=__import__('datetime').datetime.now(__import__('datetime').timezone.utc))
    def _merge(self,results,goal):
        if not results: return ''
        if len(results)==1: return results[0].content
        parts=[]
        for r in results: parts.append(f'[{r.agent_id}]\n{r.content}')
        return f'Coordinated workforce result for: {goal}\n\n'+'\n\n'.join(parts)
