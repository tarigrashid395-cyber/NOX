from __future__ import annotations
from dataclasses import dataclass

@dataclass(frozen=True)
class AgentCapability:
    name: str
    description: str
    tools: tuple[str, ...]

CAPABILITIES = {
    'research': AgentCapability('research','Evidence discovery, source evaluation, citations and conflict analysis',('Research Engine','Web Search','Memory Engine')),
    'memory': AgentCapability('memory','Relevant personal-context retrieval and durable memory operations',('Memory Engine','Knowledge Graph')),
    'study': AgentCapability('study','Teaching, explanations, practice, quizzes and learning plans',('Memory Engine','Research Engine')),
    'coding': AgentCapability('coding','Software design, implementation, debugging, testing and code review',('Memory Engine','File Intelligence')),
    'writing': AgentCapability('writing','Drafting, rewriting, editing and structured professional communication',('Memory Engine','Research Engine')),
    'analysis': AgentCapability('analysis','Reasoning, comparison, synthesis, audit and evidence-based analysis',('Research Engine','Memory Engine')),
    'business': AgentCapability('business','Market, strategy, operations, product and commercial analysis',('Research Engine','Memory Engine')),
    'project': AgentCapability('project','Project planning, sequencing, milestones, risks and dependencies',('Memory Engine','Analytics Engine')),
    'file': AgentCapability('file','Document inspection, extraction, Q&A and file-grounded analysis',('File Intelligence','Memory Engine')),
    'creative': AgentCapability('creative','Creative concepts, campaigns, narratives and content systems',('Creation Engine','Memory Engine')),
    'visual': AgentCapability('visual','Visual structures, diagrams, maps and visual intelligence',('Visual Engine','Creation Engine')),
}

TASK_CAPABILITIES = {
    'research':['research'], 'learning':['study'], 'coding':['coding'], 'writing':['writing'],
    'analysis':['analysis'], 'business':['business'], 'project':['project'], 'file_processing':['file'],
    'visual':['visual'], 'motion':['creative'], 'chat':['analysis'],
}
