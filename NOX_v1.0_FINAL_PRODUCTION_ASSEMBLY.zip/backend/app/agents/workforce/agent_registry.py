from __future__ import annotations
from typing import Any
from backend.app.agents.contracts import AgentRequest
from backend.app.providers.llm.base import LLMMessage, LLMRequest
from .agent_models import AgentDefinition, AgentExecutionRequest, AgentExecutionResult

class WorkforceAgent:
    async def execute(self, request: AgentExecutionRequest, context: dict[str, Any]) -> AgentExecutionResult:
        raise RuntimeError('Workforce agent implementation is unavailable')

class LegacyAgentAdapter(WorkforceAgent):
    def __init__(self,agent_id,legacy_agent): self.agent_id=agent_id; self.legacy_agent=legacy_agent
    async def execute(self,request,context):
        from uuid import uuid4
        started=__import__('time').perf_counter()
        payload=dict(context); payload['text']=request.goal; payload['workforce_agent']=self.agent_id
        response=await self.legacy_agent.execute(AgentRequest(task_id=uuid4(),user_id=context['user_id'],conversation_id=context.get('conversation_id'),input=payload,trace_id=str(request.conversation_id or uuid4())))
        content=str(response.result.get('content','')) if response.result else ''
        return AgentExecutionResult(agent_id=self.agent_id,status=response.status,content=content,findings=[content] if content else [],confidence=float(response.metrics.get('confidence',.75)),citations=response.citations,artifacts=response.artifacts,metrics={'latency_ms':(__import__('time').perf_counter()-started)*1000})

class MemoryWorkforceAgent(WorkforceAgent):
    def __init__(self,memory): self.memory=memory
    async def execute(self,request,context):
        from time import perf_counter
        started=perf_counter(); results=await self.memory.search(context['user_id'],request.goal,limit=12)
        content='\n'.join(str(x.get('content',x)) for x in results) if results else 'No relevant durable memory was found.'
        return AgentExecutionResult(agent_id='memory',status='completed',content=content,findings=[str(x.get('content',x)) for x in results],confidence=.9 if results else .55,metrics={'latency_ms':(perf_counter()-started)*1000,'memory_items':len(results)})

class LLMWorkforceAgent(WorkforceAgent):
    def __init__(self,agent_id,definition,llm,memory,prompt): self.agent_id=agent_id; self.definition=definition; self.llm=llm; self.memory=memory; self.prompt=prompt
    async def execute(self,request,context):
        if self.llm is None: raise RuntimeError(f'LLM provider is required for workforce agent: {self.agent_id}')
        from time import perf_counter
        started=perf_counter(); user_id=context['user_id']; memory_items=await self.memory.relevant(user_id,self.agent_id,request.goal,limit=8) if self.memory else []
        memory_text='\n'.join(str(x) for x in memory_items)
        messages=[LLMMessage(role='system',content=self.prompt),LLMMessage(role='system',content=f'Available prior context:\n{memory_text[:12000]}'),LLMMessage(role='user',content=request.goal)]
        response=await self.llm.complete(LLMRequest(messages=messages,temperature=.2,max_tokens=4096))
        content=response.content.strip()
        confidence=self.definition.confidence
        return AgentExecutionResult(agent_id=self.agent_id,status='completed',content=content,findings=[content],conclusions=[content],confidence=confidence,metrics={'latency_ms':(perf_counter()-started)*1000,'model':response.model,'usage':response.usage})

class AgentRegistry:
    def __init__(self,legacy_registry=None): self._definitions={}; self._implementations={}; self.legacy=legacy_registry
    def register(self,definition:AgentDefinition,implementation):
        if definition.id in self._definitions: raise ValueError(f'Duplicate workforce agent: {definition.id}')
        self._definitions[definition.id]=definition; self._implementations[definition.id]=implementation
    def get(self,agent_id):
        if agent_id not in self._definitions: raise KeyError(f'Unknown workforce agent: {agent_id}')
        return self._definitions[agent_id],self._implementations[agent_id]
    def list_definitions(self): return list(self._definitions.values())
    def names(self): return set(self._definitions)
