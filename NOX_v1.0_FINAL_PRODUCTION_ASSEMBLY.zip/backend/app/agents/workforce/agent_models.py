from __future__ import annotations
from datetime import datetime, timezone
from enum import StrEnum
from typing import Any
from uuid import UUID, uuid4
from pydantic import BaseModel, Field, ConfigDict

class AgentStatus(StrEnum):
    ACTIVE='active'; DEGRADED='degraded'; DISABLED='disabled'

class CostProfile(BaseModel):
    model_config=ConfigDict(extra='forbid')
    tier: str = 'standard'
    relative_cost: float = Field(default=1.0, ge=0)
    latency_weight: float = Field(default=1.0, ge=0)

class AgentDefinition(BaseModel):
    model_config=ConfigDict(extra='forbid')
    id: str = Field(min_length=1, max_length=100)
    name: str = Field(min_length=1, max_length=160)
    description: str = Field(min_length=1, max_length=2000)
    capabilities: list[str] = Field(default_factory=list)
    tools: list[str] = Field(default_factory=list)
    confidence: float = Field(default=.75, ge=0, le=1)
    specialization: str = Field(min_length=1, max_length=2000)
    status: AgentStatus = AgentStatus.ACTIVE
    cost_profile: CostProfile = Field(default_factory=CostProfile)

class AgentExecutionRequest(BaseModel):
    model_config=ConfigDict(extra='forbid')
    goal: str = Field(min_length=1, max_length=50000)
    conversation_id: UUID | None = None
    complexity: str = 'MEDIUM'
    required_capabilities: list[str] = Field(default_factory=list)
    preferred_agents: list[str] = Field(default_factory=list)
    mode: str = 'auto'
    max_agents: int = Field(default=4, ge=1, le=11)
    context: dict[str, Any] = Field(default_factory=dict)

class AgentMessage(BaseModel):
    sender: str
    recipient: str | None = None
    message_type: str
    content: str
    confidence: float = Field(ge=0, le=1)

class AgentObservation(BaseModel):
    agent_id: str
    message_type: str
    content: str
    confidence: float = Field(ge=0, le=1)
    references: list[str] = Field(default_factory=list)

class AgentExecutionResult(BaseModel):
    execution_id: UUID = Field(default_factory=uuid4)
    agent_id: str
    status: str
    content: str = ''
    findings: list[str] = Field(default_factory=list)
    conclusions: list[str] = Field(default_factory=list)
    observations: list[AgentObservation] = Field(default_factory=list)
    messages: list[AgentMessage] = Field(default_factory=list)
    disagreements: list[str] = Field(default_factory=list)
    confidence_exchange: dict[str,float] = Field(default_factory=dict)
    confidence: float = Field(default=0, ge=0, le=1)
    citations: list[dict[str, Any]] = Field(default_factory=list)
    artifacts: list[dict[str, Any]] = Field(default_factory=list)
    metrics: dict[str, Any] = Field(default_factory=dict)
    error: str | None = None

class WorkforceResult(BaseModel):
    session_id: UUID = Field(default_factory=uuid4)
    mode: str
    selected_agents: list[str]
    executions: list[AgentExecutionResult]
    merged_response: str
    confidence: float = Field(ge=0, le=1)
    started_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    completed_at: datetime | None = None
