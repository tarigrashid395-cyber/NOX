from __future__ import annotations
from collections import defaultdict
from typing import Any
from uuid import UUID

class AgentMetrics:
    EVENTS=('agent_selected','agent_completed','agent_failed','skill_used','skill_success','skill_failure','team_execution','workforce_execution','confidence_score')
    def __init__(self,analytics=None): self.analytics=analytics; self.local=defaultdict(list)
    async def record(self,user_id:UUID,event:str,value:float=1.0,success:bool=True,agent:str|None=None,metadata:dict[str,Any]|None=None,latency_ms:float=0):
        self.local[user_id].append({'event':event,'value':value,'success':success,'agent':agent,'metadata':metadata or {},'latency_ms':latency_ms})
        if getattr(self.analytics,'session_factory',None):
            from sqlalchemy import text
            from uuid import uuid4
            async with self.analytics.session_factory() as session:
                await session.execute(text('INSERT INTO agent_metrics(id,user_id,agent_id,event,value,success,metadata) VALUES (:id,:uid,:agent,:event,:value,:success,:metadata)'),{'id':uuid4(),'uid':user_id,'agent':agent,'event':event,'value':value,'success':success,'metadata':metadata or {}}); await session.commit()
        if self.analytics:
            from backend.app.evaluation.schemas import AnalyticsEvent
            await self.analytics.record(user_id,AnalyticsEvent(event=event,category='agent_workforce',value=value,success=success,latency_ms=latency_ms,agent=agent,metadata=metadata or {}))
