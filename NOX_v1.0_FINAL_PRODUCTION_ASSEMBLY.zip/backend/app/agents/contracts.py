from typing import Protocol
from uuid import UUID
from pydantic import BaseModel, Field
class ExecutionConstraints(BaseModel):
    timeout_seconds:float=60.0; max_steps:int=12; language:str='en'
class AgentRequest(BaseModel):
    task_id:UUID; user_id:UUID; conversation_id:UUID|None=None; input:dict=Field(default_factory=dict); context_refs:list[str]=Field(default_factory=list); constraints:ExecutionConstraints=Field(default_factory=ExecutionConstraints); trace_id:str
class AgentResponse(BaseModel):
    task_id:UUID; status:str; result:dict=Field(default_factory=dict); artifacts:list[dict]=Field(default_factory=list); citations:list[dict]=Field(default_factory=list); warnings:list[str]=Field(default_factory=list); metrics:dict=Field(default_factory=dict)
class AgentContract(Protocol):
    agent_type:str
    capabilities:set[str]
    async def execute(self, request:AgentRequest)->AgentResponse: ...
    async def validate(self, response:AgentResponse)->None: ...
