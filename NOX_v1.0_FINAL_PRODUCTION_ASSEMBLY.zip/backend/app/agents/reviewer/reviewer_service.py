from __future__ import annotations
import re
from uuid import UUID
from .reviewer_models import ReviewReport

class ReviewerService:
    def __init__(self, session_factory=None):
        self.session_factory = session_factory
        self._reports = {}

    async def ensure_schema(self):
        if self.session_factory is None: return
        from sqlalchemy import text
        async with self.session_factory() as session:
            await session.execute(text("""CREATE TABLE IF NOT EXISTS review_reports (review_id UUID PRIMARY KEY, user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE, plan_id UUID NULL, iteration INTEGER NOT NULL CHECK (iteration BETWEEN 1 AND 2), accuracy_score DOUBLE PRECISION NOT NULL CHECK (accuracy_score BETWEEN 0 AND 100), reasoning_score DOUBLE PRECISION NOT NULL CHECK (reasoning_score BETWEEN 0 AND 100), clarity_score DOUBLE PRECISION NOT NULL CHECK (clarity_score BETWEEN 0 AND 100), completeness_score DOUBLE PRECISION NOT NULL CHECK (completeness_score BETWEEN 0 AND 100), educational_quality_score DOUBLE PRECISION NOT NULL CHECK (educational_quality_score BETWEEN 0 AND 100), source_score DOUBLE PRECISION NOT NULL CHECK (source_score BETWEEN 0 AND 100), confidence_score DOUBLE PRECISION NOT NULL CHECK (confidence_score BETWEEN 0 AND 100), overall_score DOUBLE PRECISION NOT NULL CHECK (overall_score BETWEEN 0 AND 100), needs_revision BOOLEAN NOT NULL, feedback JSONB NOT NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW())""")); await session.execute(text("CREATE INDEX IF NOT EXISTS ix_review_reports_user_id ON review_reports(user_id)")); await session.execute(text("CREATE INDEX IF NOT EXISTS ix_review_reports_plan_id ON review_reports(plan_id)")); await session.commit()

    async def save(self, report):
        self._reports[report.review_id] = report
        if self.session_factory is not None:
            from sqlalchemy import text
            async with self.session_factory() as session:
                await session.execute(text("INSERT INTO review_reports(review_id,user_id,plan_id,iteration,accuracy_score,reasoning_score,clarity_score,completeness_score,educational_quality_score,source_score,confidence_score,overall_score,needs_revision,feedback) VALUES (:id,:uid,:pid,:it,:a,:r,:c,:co,:e,:s,:cf,:o,:n,:f) ON CONFLICT (review_id) DO UPDATE SET overall_score=EXCLUDED.overall_score,needs_revision=EXCLUDED.needs_revision,feedback=EXCLUDED.feedback"), {"id":report.review_id,"uid":report.user_id,"pid":report.plan_id,"it":report.iteration,"a":report.accuracy_score,"r":report.reasoning_score,"c":report.clarity_score,"co":report.completeness_score,"e":report.educational_quality_score,"s":report.source_score,"cf":report.confidence_score,"o":report.overall_score,"n":report.needs_revision,"f":report.feedback}); await session.commit()
        return report

    async def get(self, review_id, user_id=None):
        report=self._reports.get(review_id)
        if report is not None and (user_id is None or report.user_id == user_id): return report
        if self.session_factory is None: return None
        from sqlalchemy import text
        async with self.session_factory() as session: row=(await session.execute(text("SELECT * FROM review_reports WHERE review_id=:id"), {"id":review_id})).mappings().first()
        if not row or (user_id is not None and row["user_id"] != user_id): return None
        report=ReviewReport(review_id=row["review_id"],user_id=row["user_id"],plan_id=row["plan_id"],iteration=row["iteration"],accuracy_score=row["accuracy_score"],reasoning_score=row["reasoning_score"],clarity_score=row["clarity_score"],completeness_score=row["completeness_score"],educational_quality_score=row["educational_quality_score"],source_score=row["source_score"],confidence_score=row["confidence_score"],overall_score=row["overall_score"],needs_revision=row["needs_revision"],feedback=row["feedback"]); self._reports[report.review_id]=report; return report

    async def review(self, user_query: str, execution_plan: dict, draft_response: str, user_id: UUID | None = None, iteration: int = 1) -> ReviewReport:
        query=user_query.strip(); draft=draft_response.strip(); qwords=set(re.findall(r"[\w]+",query.lower())); dwords=set(re.findall(r"[\w]+",draft.lower())); overlap=len(qwords & dwords)/max(1,len(qwords))
        completeness=min(100.0,45+overlap*55) if draft else 0.0; clarity=min(100.0,45+(25 if len(draft.split())>=8 else 0)+(20 if not re.search(r"\s{2,}",draft) else 0)) if draft else 0.0
        reasoning=min(100.0,45+(20 if len(execution_plan.get("execution_steps",[]))>1 else 10)+(20 if any(x in draft.lower() for x in ("because","therefore","step","first","ثانياً","لأن")) else 0)) if draft else 0.0
        task_type=execution_plan.get("task_type"); source=100.0 if re.search(r"https?://|\[[0-9]+\]|source|مصدر|مراجع",draft,re.I) else (72.0 if task_type not in {"research","analysis","business"} else 45.0)
        educational=90.0 if task_type=="learning" and len(draft.split())>=30 else 78.0 if task_type=="learning" else 82.0; accuracy=min(100.0,55+overlap*45) if draft else 0.0; confidence=min(100.0,(accuracy+reasoning+clarity)/3)
        overall=round(.22*accuracy+.18*reasoning+.15*clarity+.18*completeness+.10*educational+.10*source+.07*confidence,2)
        feedback=[]
        if accuracy<85: feedback.append("Align the response more tightly with the user's stated goal.")
        if completeness<85: feedback.append("Cover the requested elements explicitly before concluding.")
        if clarity<85: feedback.append("Improve structure and remove ambiguity.")
        if source<85: feedback.append("Add or preserve evidence and source attribution when the task requires it.")
        report=ReviewReport(accuracy_score=round(accuracy,2),reasoning_score=round(reasoning,2),clarity_score=round(clarity,2),completeness_score=round(completeness,2),educational_quality_score=round(educational,2),source_score=round(source,2),confidence_score=round(confidence,2),overall_score=overall,needs_revision=overall<85,feedback=feedback,user_id=user_id,plan_id=execution_plan.get("plan_id"),iteration=min(2,max(1,iteration)))
        return await self.save(report)
