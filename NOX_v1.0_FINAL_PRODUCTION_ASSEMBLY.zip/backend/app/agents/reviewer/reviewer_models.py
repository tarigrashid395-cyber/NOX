from __future__ import annotations
from uuid import UUID, uuid4
from pydantic import BaseModel, ConfigDict, Field

class ReviewReport(BaseModel):
    model_config = ConfigDict(extra="forbid")
    review_id: UUID = Field(default_factory=uuid4)
    accuracy_score: float = Field(ge=0, le=100)
    reasoning_score: float = Field(ge=0, le=100)
    clarity_score: float = Field(ge=0, le=100)
    completeness_score: float = Field(ge=0, le=100)
    educational_quality_score: float = Field(ge=0, le=100)
    source_score: float = Field(ge=0, le=100)
    confidence_score: float = Field(ge=0, le=100)
    overall_score: float = Field(ge=0, le=100)
    needs_revision: bool
    feedback: list[str] = Field(default_factory=list)
    user_id: UUID | None = None
    plan_id: UUID | None = None
    iteration: int = Field(default=1, ge=1, le=2)
