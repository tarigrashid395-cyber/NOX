from __future__ import annotations
from backend.app.agents.contracts import AgentRequest, AgentResponse
from .reviewer_service import ReviewerService

class ReviewerAgent:
    agent_type = "reviewer"
    capabilities = {"review", "quality_control", "accuracy", "clarity", "completeness"}
    def __init__(self, service: ReviewerService | None = None): self.service = service or ReviewerService()
    async def execute(self, request: AgentRequest) -> AgentResponse:
        payload=request.input
        report=await self.service.review(payload.get("user_query", ""), payload.get("execution_plan", {}), payload.get("draft_response", ""), request.user_id, int(payload.get("iteration", 1)))
        return AgentResponse(task_id=request.task_id,status="completed",result={"review":report.model_dump(mode="json")})
    async def validate(self, response: AgentResponse): return None
