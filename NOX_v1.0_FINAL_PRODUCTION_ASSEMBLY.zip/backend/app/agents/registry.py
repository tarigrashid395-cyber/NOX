from backend.app.agents.base import BaseAgent
class AgentRegistry:
    def __init__(self): self._agents:dict[str,BaseAgent]={}
    def register(self, agent:BaseAgent):
        if agent.agent_type in self._agents: raise ValueError(f'Duplicate agent: {agent.agent_type}')
        self._agents[agent.agent_type]=agent
    def get(self, agent_type:str)->BaseAgent:
        try: return self._agents[agent_type]
        except KeyError: raise KeyError(f'Unknown agent type: {agent_type}') from None
    def names(self)->set[str]: return set(self._agents)
