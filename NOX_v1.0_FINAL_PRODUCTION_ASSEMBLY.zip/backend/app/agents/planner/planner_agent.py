from __future__ import annotations
from backend.app.agents.contracts import AgentRequest, AgentResponse
from .planner_service import PlannerService

class PlannerAgent:
    agent_type = "planner"
    capabilities = {"planning", "complexity_detection", "tool_selection", "task_decomposition"}
    def __init__(self, service: PlannerService | None = None): self.service = service or PlannerService()
    async def execute(self, request: AgentRequest) -> AgentResponse:
        plan = await self.service.plan(request.input.get("text", ""), request.user_id, request.conversation_id)
        return AgentResponse(task_id=request.task_id, status="completed", result={"plan": plan.model_dump(mode="json")})
    async def validate(self, response: AgentResponse): return None
