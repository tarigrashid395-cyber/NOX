from __future__ import annotations
from enum import StrEnum
from typing import Any
from uuid import UUID, uuid4
from pydantic import BaseModel, ConfigDict, Field

class ComplexityLevel(StrEnum):
    SIMPLE = "SIMPLE"
    MEDIUM = "MEDIUM"
    COMPLEX = "COMPLEX"
    EXPERT = "EXPERT"

class TaskType(StrEnum):
    CHAT = "chat"
    RESEARCH = "research"
    LEARNING = "learning"
    CODING = "coding"
    WRITING = "writing"
    VISUAL = "visual"
    MOTION = "motion"
    ANALYSIS = "analysis"
    BUSINESS = "business"
    PROJECT = "project"
    FILE_PROCESSING = "file_processing"

class ExecutionStep(BaseModel):
    model_config = ConfigDict(extra="forbid")
    step_id: int = Field(ge=1)
    objective: str = Field(min_length=1)
    tool: str | None = None
    agent: str | None = None
    expected_output: str = Field(min_length=1)

class ExecutionPlan(BaseModel):
    model_config = ConfigDict(extra="forbid")
    plan_id: UUID = Field(default_factory=uuid4)
    goal: str = Field(min_length=1, max_length=20000)
    task_type: TaskType
    complexity: ComplexityLevel
    complexity_score: float = Field(ge=0, le=100)
    difficulty_score: float = Field(ge=0, le=100)
    risk_score: float = Field(ge=0, le=100)
    required_agents: list[str] = Field(default_factory=list)
    required_tools: list[str] = Field(default_factory=list)
    execution_steps: list[ExecutionStep] = Field(min_length=1)
    estimated_context_size: int = Field(ge=0)
    estimated_cost: float = Field(ge=0)
    confidence: float = Field(ge=0, le=1)
    user_id: UUID | None = None
    conversation_id: UUID | None = None
