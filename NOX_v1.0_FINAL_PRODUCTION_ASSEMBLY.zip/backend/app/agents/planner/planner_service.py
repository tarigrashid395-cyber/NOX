from __future__ import annotations
import re
from time import perf_counter
from uuid import UUID
from .planner_models import ComplexityLevel, ExecutionPlan, ExecutionStep, TaskType

class PlannerService:
    def __init__(self, session_factory=None):
        self.session_factory = session_factory
        self._plans = {}

    async def ensure_schema(self):
        if self.session_factory is None: return
        from sqlalchemy import text
        async with self.session_factory() as session:
            await session.execute(text("""CREATE TABLE IF NOT EXISTS execution_plans (plan_id UUID PRIMARY KEY, user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE, conversation_id UUID NULL, goal TEXT NOT NULL, task_type VARCHAR(64) NOT NULL, complexity VARCHAR(16) NOT NULL, complexity_score DOUBLE PRECISION NOT NULL CHECK (complexity_score BETWEEN 0 AND 100), difficulty_score DOUBLE PRECISION NOT NULL CHECK (difficulty_score BETWEEN 0 AND 100), risk_score DOUBLE PRECISION NOT NULL CHECK (risk_score BETWEEN 0 AND 100), required_agents JSONB NOT NULL, required_tools JSONB NOT NULL, execution_steps JSONB NOT NULL, estimated_context_size INTEGER NOT NULL CHECK (estimated_context_size >= 0), estimated_cost DOUBLE PRECISION NOT NULL CHECK (estimated_cost >= 0), confidence DOUBLE PRECISION NOT NULL CHECK (confidence BETWEEN 0 AND 1), created_at TIMESTAMPTZ NOT NULL DEFAULT NOW())""")); await session.execute(text("CREATE INDEX IF NOT EXISTS ix_execution_plans_user_id ON execution_plans(user_id)")); await session.execute(text("CREATE INDEX IF NOT EXISTS ix_execution_plans_created_at ON execution_plans(created_at)")); await session.commit()

    async def save(self, plan):
        self._plans[plan.plan_id] = plan
        if self.session_factory is not None:
            from sqlalchemy import text
            async with self.session_factory() as session:
                await session.execute(text("INSERT INTO execution_plans(plan_id,user_id,conversation_id,goal,task_type,complexity,complexity_score,difficulty_score,risk_score,required_agents,required_tools,execution_steps,estimated_context_size,estimated_cost,confidence) VALUES (:id,:uid,:cid,:goal,:tt,:cx,:cs,:ds,:rs,:agents,:tools,:steps,:ctx,:cost,:conf) ON CONFLICT (plan_id) DO UPDATE SET goal=EXCLUDED.goal,required_agents=EXCLUDED.required_agents,required_tools=EXCLUDED.required_tools,execution_steps=EXCLUDED.execution_steps"), {"id":plan.plan_id,"uid":plan.user_id,"cid":plan.conversation_id,"goal":plan.goal,"tt":plan.task_type.value,"cx":plan.complexity.value,"cs":plan.complexity_score,"ds":plan.difficulty_score,"rs":plan.risk_score,"agents":plan.required_agents,"tools":plan.required_tools,"steps":[x.model_dump(mode="json") for x in plan.execution_steps],"ctx":plan.estimated_context_size,"cost":plan.estimated_cost,"conf":plan.confidence}); await session.commit()
        return plan

    async def get(self, plan_id, user_id=None):
        plan=self._plans.get(plan_id)
        if plan is not None and (user_id is None or plan.user_id == user_id): return plan
        if self.session_factory is None: return None
        from sqlalchemy import text
        from .planner_models import ExecutionPlan, ExecutionStep, ComplexityLevel, TaskType
        async with self.session_factory() as session:
            row=(await session.execute(text("SELECT * FROM execution_plans WHERE plan_id=:id"), {"id":plan_id})).mappings().first()
        if not row or (user_id is not None and row["user_id"] != user_id): return None
        plan=ExecutionPlan(plan_id=row["plan_id"],user_id=row["user_id"],conversation_id=row["conversation_id"],goal=row["goal"],task_type=TaskType(row["task_type"]),complexity=ComplexityLevel(row["complexity"]),complexity_score=row["complexity_score"],difficulty_score=row["difficulty_score"],risk_score=row["risk_score"],required_agents=row["required_agents"],required_tools=row["required_tools"],execution_steps=[ExecutionStep.model_validate(x) for x in row["execution_steps"]],estimated_context_size=row["estimated_context_size"],estimated_cost=row["estimated_cost"],confidence=row["confidence"]); self._plans[plan.plan_id]=plan; return plan
    _patterns = {
        TaskType.RESEARCH: r"research|source|sources|citation|evidence|بحث|مصادر|مراجع",
        TaskType.LEARNING: r"learn|study|explain|quiz|flashcard|دراسة|تعلم|اشرح|اختبار",
        TaskType.CODING: r"code|coding|debug|implement|api|python|typescript|javascript|برمج|كود|تنفيذ",
        TaskType.WRITING: r"write|rewrite|draft|email|article|essay|اكتب|صياغة|مقال|رسالة",
        TaskType.VISUAL: r"image|visual|diagram|mind map|flowchart|infographic|صورة|مخطط|خريطة",
        TaskType.MOTION: r"video|animation|motion|animate|فيديو|تحريك|رسوم متحركة",
        TaskType.ANALYSIS: r"analy[sz]e|analysis|compare|evaluate|audit|حلل|تحليل|قارن|تقييم|تدقيق",
        TaskType.BUSINESS: r"business|market|strategy|pricing|sales|أعمال|سوق|استراتيجية|تسعير",
        TaskType.PROJECT: r"project|roadmap|milestone|plan|خطة|مشروع|خارطة طريق|مراحل",
        TaskType.FILE_PROCESSING: r"file|document|pdf|docx|spreadsheet|csv|ملف|وثيقة|مستند|جدول",
    }
    _tool_map = {
        TaskType.RESEARCH: ("Research Engine", "Research Agent"), TaskType.LEARNING: ("Memory Engine", "Study Agent"),
        TaskType.CODING: ("Memory Engine", "Planning Agent"), TaskType.WRITING: ("Memory Engine", "Creation Agent"),
        TaskType.VISUAL: ("Visual Engine", "Visual Agent"), TaskType.MOTION: ("Motion Engine", "Motion Agent"),
        TaskType.ANALYSIS: ("Research Engine", "Planning Agent"), TaskType.BUSINESS: ("Research Engine", "Planning Agent"),
        TaskType.PROJECT: ("Memory Engine", "Planning Agent"), TaskType.FILE_PROCESSING: ("File Intelligence", "File Agent"),
    }
    def classify(self, goal: str) -> TaskType:
        matches = [t for t,p in self._patterns.items() if re.search(p, goal, re.I)]
        return matches[0] if matches else TaskType.CHAT

    def build(self, goal: str, user_id: UUID | None = None, conversation_id: UUID | None = None) -> ExecutionPlan:
        text = " ".join(goal.strip().split())
        task_type = self.classify(text)
        words, length = len(text.split()), len(text)
        compound = len(re.findall(r"\b(and|then|also|with|plus|و|ثم|أيضاً|مع)\b", text, re.I))
        complexity_score = min(100.0, 10 + length / 12 + compound * 8 + (25 if task_type != TaskType.CHAT else 0))
        if complexity_score < 30: complexity = ComplexityLevel.SIMPLE
        elif complexity_score < 55: complexity = ComplexityLevel.MEDIUM
        elif complexity_score < 78: complexity = ComplexityLevel.COMPLEX
        else: complexity = ComplexityLevel.EXPERT
        difficulty_score = min(100.0, complexity_score * 0.8 + (15 if task_type in {TaskType.CODING, TaskType.RESEARCH, TaskType.ANALYSIS} else 0))
        risk_score = min(100.0, (20 if task_type in {TaskType.BUSINESS, TaskType.CODING, TaskType.RESEARCH} else 5) + (20 if words > 120 else 0))
        tools, agents = [], ["Supervisor"]
        if task_type in self._tool_map:
            tool, agent = self._tool_map[task_type]; tools.append(tool); agents.append(agent)
        if task_type in {TaskType.RESEARCH, TaskType.ANALYSIS, TaskType.BUSINESS}: tools.append("Memory Engine")
        if re.search(r"remember|memory|recall|تذكر|ذاكرة", text, re.I): tools.append("Memory Engine")
        if re.search(r"analytics|metric|metrics|statistics|telemetry|تحليلات|مؤشرات|إحصاءات", text, re.I): tools.append("Analytics Engine")
        if re.search(r"export|download|pdf|docx|csv|تصدير|تحميل", text, re.I): tools.append("Export Engine")
        if task_type in {TaskType.WRITING, TaskType.CODING, TaskType.PROJECT}: tools.append("Memory Engine")
        if task_type == TaskType.MOTION: tools.append("Visual Engine")
        steps = [ExecutionStep(step_id=1, objective=f"Analyze and execute the {task_type.value} request", tool=tools[0] if tools else None, agent=agents[-1] if len(agents)>1 else None, expected_output="Evidence-backed intermediate result")]
        if task_type in {TaskType.RESEARCH, TaskType.ANALYSIS, TaskType.BUSINESS}:
            steps.append(ExecutionStep(step_id=2, objective="Cross-check relevant context and evidence", tool="Memory Engine", agent="Memory Agent", expected_output="Relevant context and verified evidence"))
        steps.append(ExecutionStep(step_id=len(steps)+1, objective="Synthesize the completed work into a response", tool="Export Engine" if task_type in {TaskType.WRITING, TaskType.FILE_PROCESSING} else None, agent="Supervisor", expected_output="Draft response"))
        return ExecutionPlan(goal=text, task_type=task_type, complexity=complexity, complexity_score=round(complexity_score,2), difficulty_score=round(difficulty_score,2), risk_score=round(risk_score,2), required_agents=list(dict.fromkeys(agents)), required_tools=list(dict.fromkeys(tools)), execution_steps=steps, estimated_context_size=min(20000, max(256, words*8)), estimated_cost=round(max(0.001, words*0.00002 + len(steps)*0.001),5), confidence=round(max(.55, 1-(risk_score/300)),3), user_id=user_id, conversation_id=conversation_id)

    async def plan(self, goal: str, user_id: UUID | None = None, conversation_id: UUID | None = None) -> ExecutionPlan:
        return self.build(goal, user_id, conversation_id)
