EXPORT_SYSTEM_PROMPT='Export NOX outputs into validated, portable formats while preserving source structure and references.'
