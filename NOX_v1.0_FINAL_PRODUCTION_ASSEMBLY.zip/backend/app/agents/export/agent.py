from backend.app.agents.base import BaseAgent
from backend.app.agents.contracts import AgentRequest,AgentResponse
from backend.app.export.schemas import ExportRequest
class ExportAgent(BaseAgent):
    agent_type='export'
    capabilities={'pdf','docx','markdown','html','json','csv','png','svg','pptx','zip'}
    def __init__(self,orchestrator=None): self.orchestrator=orchestrator
    async def execute(self,request:AgentRequest)->AgentResponse:
        if not self.orchestrator: raise RuntimeError('Export orchestrator is not configured')
        d=request.input; fmt=d.get('format') or self._infer(d.get('text',''))
        body=ExportRequest(format=fmt,source_type=d.get('source_type','generic'),source_id=d.get('source_id'),title=d.get('title',''),content=d.get('content'),source_refs=d.get('source_refs',[]),options=d.get('options',{}))
        result=await self.orchestrator.export(request.user_id,body)
        return AgentResponse(task_id=request.task_id,status='completed',result=result.model_dump(mode='json'),artifacts=[result.job.model_dump(mode='json')])
    def _infer(self,text):
        q=(text or '').lower()
        for fmt,terms in [('pdf',('pdf','بي دي اف')),('docx',('docx','word','وورد')),('pptx',('pptx','powerpoint','presentation','عرض')),('zip',('zip','package','حزمة')),('markdown',('markdown','md')),('html',('html','web')),('csv',('csv','spreadsheet')),('png',('png','image')),('svg',('svg',))]:
            if any(t in q for t in terms): return fmt
        return 'json'
