from backend.app.agents.base import BaseAgent
from backend.app.agents.contracts import AgentRequest, AgentResponse
class MemoryAgent(BaseAgent):
    agent_type='memory'; capabilities={'retrieve','update'}
    async def execute(self,request): return AgentResponse(task_id=request.task_id,status='completed',result={'content':'Memory workflow accepted.','input':request.input})
