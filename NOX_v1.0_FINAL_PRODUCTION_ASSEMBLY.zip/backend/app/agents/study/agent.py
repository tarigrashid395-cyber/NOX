from backend.app.agents.base import BaseAgent
from backend.app.agents.contracts import AgentRequest, AgentResponse
class StudyAgent(BaseAgent):
    agent_type='study'; capabilities={'explain','quiz','flashcards'}
    async def execute(self,request): return AgentResponse(task_id=request.task_id,status='completed',result={'content':'Study workflow accepted.','input':request.input})
