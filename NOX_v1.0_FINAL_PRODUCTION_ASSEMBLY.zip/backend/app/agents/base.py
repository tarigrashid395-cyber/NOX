from abc import ABC, abstractmethod
from backend.app.agents.contracts import AgentRequest, AgentResponse
class BaseAgent(ABC):
    agent_type='base'; capabilities:set[str]=set()
    @abstractmethod
    async def execute(self, request:AgentRequest)->AgentResponse: ...
    async def validate(self, response:AgentResponse)->None:
        if response.task_id is None: raise ValueError('Agent response missing task_id')
