from __future__ import annotations
from time import perf_counter
from uuid import UUID
from backend.app.agents.workforce.agent_models import AgentExecutionRequest
from backend.app.execution.execution_models import TaskStatus

class ExecutionEngine:
    def __init__(self, planner, workforce, reviewer, artifact_generator, service):
        self.planner,self.workforce,self.reviewer,self.artifact_generator,self.service=planner,workforce,reviewer,artifact_generator,service

    async def execute(self, task):
        await self.service.update_status(task,TaskStatus.PLANNING,progress=2)
        plan=await self.planner.plan(task.goal,task.user_id,task.conversation_id)
        await self.planner.save(plan)
        task.plan_id=plan.plan_id; task.task_type=plan.task_type.value; task.complexity=plan.complexity.value; task.total_steps=len(plan.execution_steps)
        await self.service.save_task(task)
        await self.service.emit_analytics(task,'task_started')
        outputs=[]; started=perf_counter()
        for index, step in enumerate(plan.execution_steps,1):
            current=await self.service.get_task(task.id,task.user_id)
            if not current or current.status == TaskStatus.CANCELLED: return current
            task.current_step=index; await self.service.update_status(task,TaskStatus.RUNNING,progress=5+((index-1)/max(1,task.total_steps))*80)
            agent=step.agent or self._agent_for(plan.task_type.value)
            request=AgentExecutionRequest(goal=step.objective+'\nOriginal goal: '+task.goal,conversation_id=task.conversation_id,complexity=plan.complexity.value,mode='single',preferred_agents=[agent] if agent else [],context={'task_type':plan.task_type.value,'task_id':str(task.id),'step':index,'prior_outputs':outputs[-3:]})
            result=await self.workforce.execute(task.user_id,request)
            content=result.merged_response
            outputs.append({'step':index,'objective':step.objective,'agent':agent,'content':content,'confidence':result.confidence})
            await self.service.save_step(task.id,index,step,{'response':content},result.confidence)
            await self.service.record_event(task.id,'step_completed',status=TaskStatus.RUNNING,progress=5+(index/task.total_steps)*80,payload={'step':index,'agent':agent,'confidence':result.confidence})
        draft='\n\n'.join(x['content'] for x in outputs if x['content'])
        review=await self.reviewer.review(task.goal,plan.model_dump(mode='json'),draft,task.user_id,1)
        review_score=review.overall_score
        if review.needs_revision:
            feedback=' '.join(review.feedback)
            revision=await self.workforce.execute(task.user_id,AgentExecutionRequest(goal=task.goal+'\nReviewer feedback: '+feedback,conversation_id=task.conversation_id,complexity=plan.complexity.value,mode='single',context={'task_type':plan.task_type.value,'task_id':str(task.id),'revision':True,'draft':draft}))
            if revision.merged_response: draft=revision.merged_response
            review_score=revision.confidence*100 if revision.confidence else review_score
        artifact_ids=[]
        artifact_type=task.metadata.get('artifact_type')
        if artifact_type:
            artifact=await self.artifact_generator.create(task.user_id,task.metadata.get('artifact_title') or 'NOX Task Deliverable',artifact_type,draft,task_id=task.id,workspace_id=task.workspace_id,metadata={'task_type':plan.task_type.value,'review_score':review_score})
            artifact_ids=[artifact.id]; await self.service.emit_analytics(task,'artifact_created',metadata={'artifact_id':str(artifact.id)})
        execution_confidence=sum(x['confidence'] for x in outputs)/max(1,len(outputs))
        task.status=TaskStatus.COMPLETED; task.progress=100; task.completed_at=__import__('datetime').datetime.now(__import__('datetime').timezone.utc); await self.service.save_task(task)
        await self.service.save_result(task,draft,review_score,artifact_ids,{'duration_ms':(perf_counter()-started)*1000,'steps':len(outputs),'confidence':execution_confidence})
        await self.service.emit_analytics(task,'task_completed',value=1,metadata={'duration_ms':(perf_counter()-started)*1000,'confidence':execution_confidence,'review_score':review_score})
        await self.service.emit_analytics(task,'execution_duration',value=(perf_counter()-started)*1000,metadata={'task_id':str(task.id)})
        await self.service.emit_analytics(task,'execution_cost',value=float(plan.estimated_cost),metadata={'task_id':str(task.id)})
        await self.service.emit_analytics(task,'execution_confidence',value=execution_confidence,metadata={'review_score':review_score})
        return task

    def _agent_for(self, task_type):
        return {'research':'research','learning':'study','coding':'coding','writing':'writing','analysis':'analysis','business':'business','project':'project','file_processing':'file','visual':'visual','motion':'visual'}.get(task_type,'analysis')
