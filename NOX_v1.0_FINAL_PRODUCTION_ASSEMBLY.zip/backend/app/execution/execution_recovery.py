from __future__ import annotations
from uuid import UUID

class ExecutionRecovery:
    def __init__(self, service): self.service=service
    async def recover(self, task, error: Exception) -> bool:
        if task.status.value == 'cancelled' or task.retry_count >= task.max_retries:
            return False
        task.retry_count += 1
        task.status='retrying'
        task.error=str(error)
        await self.service.save_task(task)
        await self.service.record_event(task.id,'task_retried',status='retrying',payload={'attempt':task.retry_count,'error':type(error).__name__})
        return True
