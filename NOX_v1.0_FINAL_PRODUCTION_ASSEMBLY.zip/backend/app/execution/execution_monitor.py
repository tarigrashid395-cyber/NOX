from __future__ import annotations
from uuid import UUID

class ExecutionMonitor:
    def __init__(self, service): self.service=service
    async def emit(self, task_id:UUID, event:str, status=None, progress=None, payload=None):
        return await self.service.record_event(task_id,event,status=status,progress=progress,payload=payload or {})
    async def progress(self, task_id:UUID):
        task=await self.service.get_task(task_id, None)
        return task.progress if task else None
