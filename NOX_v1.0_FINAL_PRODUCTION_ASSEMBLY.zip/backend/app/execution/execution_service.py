from __future__ import annotations
import asyncio
from datetime import datetime, timezone
from uuid import UUID, uuid4
from backend.app.evaluation.schemas import AnalyticsEvent
from .execution_models import Task, TaskCreate, TaskEvent, TaskResult, TaskStep, TaskStatus
from .execution_recovery import ExecutionRecovery

class ExecutionService:
    def __init__(self, session_factory=None, analytics=None):
        self.session_factory=session_factory; self.analytics=analytics; self.tasks={}; self.steps={}; self.events={}; self.results={}; self.engine=None; self.recovery=ExecutionRecovery(self)
    async def ensure_schema(self):
        if not self.session_factory:return
        from sqlalchemy import text
        async with self.session_factory() as s:
            statements=[
            '''CREATE TABLE IF NOT EXISTS tasks (id UUID PRIMARY KEY,user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,workspace_id UUID NULL,conversation_id UUID NULL,goal TEXT NOT NULL,status VARCHAR(20) NOT NULL,task_type VARCHAR(64) NOT NULL,complexity VARCHAR(16) NOT NULL,plan_id UUID NULL,progress DOUBLE PRECISION NOT NULL CHECK(progress BETWEEN 0 AND 100),current_step INTEGER NOT NULL,total_steps INTEGER NOT NULL,retry_count INTEGER NOT NULL,max_retries INTEGER NOT NULL,metadata JSONB NOT NULL DEFAULT '{}'::jsonb,error TEXT,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),started_at TIMESTAMPTZ,completed_at TIMESTAMPTZ)''',
            '''CREATE TABLE IF NOT EXISTS task_steps (id UUID PRIMARY KEY,task_id UUID NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,step_number INTEGER NOT NULL,objective TEXT NOT NULL,status VARCHAR(20) NOT NULL,agent VARCHAR(120),tool VARCHAR(120),input JSONB NOT NULL DEFAULT '{}'::jsonb,output JSONB NOT NULL DEFAULT '{}'::jsonb,confidence DOUBLE PRECISION NOT NULL DEFAULT 0,retry_count INTEGER NOT NULL DEFAULT 0,started_at TIMESTAMPTZ,completed_at TIMESTAMPTZ,error TEXT,UNIQUE(task_id,step_number))''',
            '''CREATE TABLE IF NOT EXISTS task_events (id UUID PRIMARY KEY,task_id UUID NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,event VARCHAR(100) NOT NULL,status VARCHAR(20),progress DOUBLE PRECISION,payload JSONB NOT NULL DEFAULT '{}'::jsonb,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW())''',
            '''CREATE TABLE IF NOT EXISTS task_results (id UUID PRIMARY KEY,task_id UUID NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,status VARCHAR(20) NOT NULL,content TEXT NOT NULL,confidence DOUBLE PRECISION NOT NULL,review_score DOUBLE PRECISION,artifact_ids JSONB NOT NULL DEFAULT '[]'::jsonb,metadata JSONB NOT NULL DEFAULT '{}'::jsonb,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW())''']
            for sql in statements: await s.execute(text(sql))
            await s.execute(text('CREATE INDEX IF NOT EXISTS ix_tasks_user_status ON tasks(user_id,status)')); await s.execute(text('CREATE INDEX IF NOT EXISTS ix_task_events_task ON task_events(task_id,created_at)')); await s.execute(text('CREATE INDEX IF NOT EXISTS ix_task_steps_task ON task_steps(task_id,step_number)')); await s.commit()

    async def create(self,user_id:UUID,body:TaskCreate):
        t=Task(user_id=user_id,goal=body.goal,workspace_id=body.workspace_id,conversation_id=body.conversation_id,metadata={**body.metadata,**({'artifact_type':body.artifact_type} if body.artifact_type else {}),**({'artifact_title':body.artifact_title} if body.artifact_title else {})})
        self.tasks[t.id]=t; await self.save_task(t); await self.record_event(t.id,'task_created',status=TaskStatus.QUEUED); await self.emit_analytics(t,'task_created'); return t
    async def save_task(self,t):
        self.tasks[t.id]=t
        if self.session_factory:
            from sqlalchemy import text
            async with self.session_factory() as s:
                await s.execute(text('INSERT INTO tasks(id,user_id,workspace_id,conversation_id,goal,status,task_type,complexity,plan_id,progress,current_step,total_steps,retry_count,max_retries,metadata,error,created_at,started_at,completed_at) VALUES (:id,:user_id,:workspace_id,:conversation_id,:goal,:status,:task_type,:complexity,:plan_id,:progress,:current_step,:total_steps,:retry_count,:max_retries,:metadata,:error,:created_at,:started_at,:completed_at) ON CONFLICT (id) DO UPDATE SET status=EXCLUDED.status,task_type=EXCLUDED.task_type,complexity=EXCLUDED.complexity,plan_id=EXCLUDED.plan_id,progress=EXCLUDED.progress,current_step=EXCLUDED.current_step,total_steps=EXCLUDED.total_steps,retry_count=EXCLUDED.retry_count,metadata=EXCLUDED.metadata,error=EXCLUDED.error,started_at=EXCLUDED.started_at,completed_at=EXCLUDED.completed_at'),t.model_dump()); await s.commit()
        return t
    async def get_task(self,task_id,user_id=None):
        t=self.tasks.get(task_id)
        if t and (user_id is None or t.user_id==user_id):return t
        if not self.session_factory:return None
        from sqlalchemy import text
        async with self.session_factory() as s: row=(await s.execute(text('SELECT * FROM tasks WHERE id=:id AND (:uid IS NULL OR user_id=:uid)'),{'id':task_id,'uid':user_id})).mappings().first()
        return Task.model_validate(row) if row else None
    async def list(self,user_id,workspace_id=None):
        local=[x for x in self.tasks.values() if x.user_id==user_id and (workspace_id is None or x.workspace_id==workspace_id)]
        if local or not self.session_factory: return local
        from sqlalchemy import text
        async with self.session_factory() as s:
            rows=(await s.execute(text('SELECT * FROM tasks WHERE user_id=:user AND (:workspace IS NULL OR workspace_id=:workspace) ORDER BY created_at DESC LIMIT 500'),{'user':user_id,'workspace':workspace_id})).mappings().all()
        return [Task.model_validate(row) for row in rows]
    async def update_status(self,t,status,progress=None):
        t.status=status; t.progress=progress if progress is not None else t.progress
        if status==TaskStatus.RUNNING and t.started_at is None:t.started_at=datetime.now(timezone.utc)
        await self.save_task(t); await self.record_event(t.id,f'task_{status.value}',status=status,progress=t.progress)
    async def record_event(self,task_id,event,status=None,progress=None,payload=None):
        item=TaskEvent(task_id=task_id,event=event,status=TaskStatus(status) if isinstance(status,str) else status,progress=progress,payload=payload or {}); self.events.setdefault(task_id,[]).append(item)
        if self.session_factory:
            from sqlalchemy import text
            async with self.session_factory() as s: await s.execute(text('INSERT INTO task_events(id,task_id,event,status,progress,payload,created_at) VALUES (:id,:task,:event,:status,:progress,:payload,:created)'),{'id':item.id,'task':task_id,'event':event,'status':item.status.value if item.status else None,'progress':progress,'payload':item.payload,'created':item.created_at}); await s.commit()
        return item
    async def save_step(self,task_id,index,step,output,confidence):
        item=TaskStep(task_id=task_id,step_number=index,objective=step.objective,status=TaskStatus.COMPLETED,agent=step.agent,tool=step.tool,input=step.input,output=output,confidence=confidence,started_at=datetime.now(timezone.utc),completed_at=datetime.now(timezone.utc)); self.steps[(task_id,index)]=item
        if self.session_factory:
            from sqlalchemy import text
            async with self.session_factory() as s: await s.execute(text('INSERT INTO task_steps(id,task_id,step_number,objective,status,agent,tool,input,output,confidence,retry_count,started_at,completed_at) VALUES (:id,:task,:num,:objective,:status,:agent,:tool,:input,:output,:confidence,0,:started,:completed) ON CONFLICT(task_id,step_number) DO UPDATE SET status=EXCLUDED.status,output=EXCLUDED.output,confidence=EXCLUDED.confidence,completed_at=EXCLUDED.completed_at'),{'id':item.id,'task':task_id,'num':index,'objective':item.objective,'status':item.status.value,'agent':item.agent,'tool':item.tool,'input':item.input,'output':item.output,'confidence':confidence,'started':item.started_at,'completed':item.completed_at}); await s.commit()
    async def save_result(self,t,content,review_score,artifact_ids,metadata):
        r=TaskResult(task_id=t.id,status=t.status,content=content,confidence=metadata.get('confidence',0),review_score=review_score,artifact_ids=artifact_ids,metadata=metadata); self.results[t.id]=r
        if self.session_factory:
            from sqlalchemy import text
            async with self.session_factory() as s: await s.execute(text('INSERT INTO task_results(id,task_id,status,content,confidence,review_score,artifact_ids,metadata,created_at) VALUES (:id,:task,:status,:content,:confidence,:review,:artifacts,:metadata,:created)'),{'id':r.id,'task':t.id,'status':t.status.value,'content':content,'confidence':r.confidence,'review':review_score,'artifacts':[str(x) for x in artifact_ids],'metadata':metadata,'created':r.created_at}); await s.commit()
        return r
    async def cancel(self,task_id):
        t=self.tasks.get(task_id)
        if not t:return None
        t.status=TaskStatus.CANCELLED; t.completed_at=datetime.now(timezone.utc); await self.save_task(t); await self.record_event(t.id,'task_cancelled',status=TaskStatus.CANCELLED); await self.emit_analytics(t,'task_failed',success=False,metadata={'cancelled':True}); return t
    async def run(self,task_id):
        t=self.tasks.get(task_id)
        if not t:return None
        try:
            return await self.engine.execute(t)
        except asyncio.CancelledError:
            await self.cancel(task_id); raise
        except Exception as exc:
            recovered=await self.recovery.recover(t,exc)
            if recovered:
                await __import__('asyncio').sleep(min(2**t.retry_count,.25))
                return await self.run(task_id)
            t.status=TaskStatus.FAILED; t.error=str(exc); await self.save_task(t); await self.record_event(t.id,'task_failed',status=TaskStatus.FAILED,payload={'error':type(exc).__name__}); await self.emit_analytics(t,'task_failed',success=False,metadata={'error':type(exc).__name__}); return t
    async def emit_analytics(self,t,event,value=1,success=True,metadata=None):
        if self.analytics: await self.analytics.record(t.user_id,AnalyticsEvent(event=event,category='execution',value=value,success=success,agent='execution',metadata=metadata or {}))
