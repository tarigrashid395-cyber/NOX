from __future__ import annotations
from datetime import datetime, timezone
from enum import StrEnum
from typing import Any
from uuid import UUID, uuid4
from pydantic import BaseModel, ConfigDict, Field

class TaskStatus(StrEnum):
    QUEUED='queued'; PLANNING='planning'; RUNNING='running'; WAITING='waiting'; RETRYING='retrying'; COMPLETED='completed'; FAILED='failed'; CANCELLED='cancelled'

class TaskCreate(BaseModel):
    model_config=ConfigDict(extra='forbid')
    goal: str = Field(min_length=1,max_length=50000)
    conversation_id: UUID | None = None
    workspace_id: UUID | None = None
    task_type: str | None = None
    complexity: str | None = None
    artifact_type: str | None = None
    artifact_title: str | None = None
    metadata: dict[str,Any] = Field(default_factory=dict)

class Task(BaseModel):
    model_config=ConfigDict(extra='forbid')
    id: UUID = Field(default_factory=uuid4)
    user_id: UUID
    goal: str
    status: TaskStatus = TaskStatus.QUEUED
    task_type: str = 'chat'
    complexity: str = 'MEDIUM'
    workspace_id: UUID | None = None
    conversation_id: UUID | None = None
    plan_id: UUID | None = None
    progress: float = Field(default=0,ge=0,le=100)
    current_step: int = 0
    total_steps: int = 0
    retry_count: int = 0
    max_retries: int = Field(default=3,ge=0,le=10)
    metadata: dict[str,Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    started_at: datetime | None = None
    completed_at: datetime | None = None
    error: str | None = None

class TaskStep(BaseModel):
    id: UUID = Field(default_factory=uuid4)
    task_id: UUID
    step_number: int = Field(ge=1)
    objective: str
    status: TaskStatus = TaskStatus.QUEUED
    agent: str | None = None
    tool: str | None = None
    input: dict[str,Any] = Field(default_factory=dict)
    output: dict[str,Any] = Field(default_factory=dict)
    confidence: float = 0
    retry_count: int = 0
    started_at: datetime | None = None
    completed_at: datetime | None = None
    error: str | None = None

class TaskEvent(BaseModel):
    id: UUID = Field(default_factory=uuid4)
    task_id: UUID
    event: str
    status: TaskStatus | None = None
    progress: float | None = None
    payload: dict[str,Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class TaskResult(BaseModel):
    id: UUID = Field(default_factory=uuid4)
    task_id: UUID
    status: TaskStatus
    content: str = ''
    confidence: float = 0
    review_score: float | None = None
    artifact_ids: list[UUID] = Field(default_factory=list)
    metadata: dict[str,Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
