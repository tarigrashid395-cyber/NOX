from __future__ import annotations
import asyncio
from uuid import UUID
from backend.app.workers.queue import RedisJobQueue

class ExecutionScheduler:
    def __init__(self, service, redis=None, queue_enabled=False, production=False):
        self.service=service; self.redis=redis; self.queue_enabled=queue_enabled; self.production=production; self.local_tasks:dict[UUID,asyncio.Task]={}; self.queue=None
        if redis is not None and queue_enabled: self.queue=RedisJobQueue(redis,stream='nox:execution',group='nox-execution-workers',consumer='api-scheduler',dlq='nox:execution:dlq',max_retries=3)
    async def schedule(self, task_id:UUID):
        if self.queue is not None:
            try:
                await self.queue.publish('task.execute',{'task_id':str(task_id)})
                return 'queued'
            except Exception:
                if self.production: raise
        job=asyncio.create_task(self.service.run(task_id))
        self.local_tasks[task_id]=job
        job.add_done_callback(lambda _: self.local_tasks.pop(task_id,None))
        return 'local'
    async def cancel(self, task_id:UUID):
        task=self.local_tasks.get(task_id)
        if task and not task.done(): task.cancel()
        return await self.service.cancel(task_id)
