from __future__ import annotations
from typing import Any
from backend.app.export.schemas import ExportRequest

class ExportPlanner:
    def plan(self, request: ExportRequest, context: dict[str, Any]) -> dict[str, Any]:
        content = request.content
        if content is None:
            content = context.get('content') or {'title': request.title or request.source_type, 'items': []}
        return {
            'format': request.format,
            'source_type': request.source_type,
            'source_id': request.source_id,
            'title': request.title or self._title(content, request.source_type),
            'content': content,
            'options': request.options,
            'references': context.get('references', []),
            'context_counts': {k: len(v) if isinstance(v, list) else 1 for k,v in context.items() if k != 'content'},
        }

    @staticmethod
    def _title(content: Any, fallback: str) -> str:
        if isinstance(content, dict) and content.get('title'): return str(content['title'])
        return fallback.replace('_',' ').title()
