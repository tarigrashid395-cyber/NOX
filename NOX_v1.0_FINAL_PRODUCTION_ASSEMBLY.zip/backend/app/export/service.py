from __future__ import annotations
import base64,re
from datetime import datetime,timezone
from uuid import UUID,uuid4
from backend.app.export.schemas import ExportRequest,ExportJob,ExportResult
from backend.app.export.planner import ExportPlanner
from backend.app.export.renderer import ExportRenderer,EXT
from backend.app.export.validator import ExportValidator
from backend.app.export.registry import ExportRegistry

class ExportOrchestrator:
    def __init__(self,planner,renderer,validator,repository,registry,memory=None,research=None,files=None,visual=None,motion=None,creation=None):
        self.planner=planner; self.renderer=renderer; self.validator=validator; self.repository=repository; self.registry=registry
        self.memory=memory; self.research=research; self.files=files; self.visual=visual; self.motion=motion; self.creation=creation
    async def _context(self,user_id,request):
        c={'memory':[],'research':[],'files':[],'visual':[],'motion':[],'creation':[],'references':[],'content':request.content}
        if self.memory:
            try: c['memory']=await self.memory.search(user_id,request.title or request.source_type,limit=6)
            except Exception: pass
        if self.research and request.source_type=='research':
            try: c['research']=await self.research.history(user_id,limit=6)
            except Exception: pass
        for name,obj,refs in [('files',self.files,request.source_refs),('visual',self.visual,request.source_refs),('motion',self.motion,request.source_refs),('creation',self.creation,request.source_refs)]:
            if obj and refs:
                for ref in refs:
                    try:
                        item=await obj.get(user_id,UUID(ref));
                        if item: c[name].append(item.model_dump(mode='json') if hasattr(item,'model_dump') else item)
                    except Exception: pass
        return c
    async def export(self,user_id:UUID,request:ExportRequest)->ExportResult:
        context=await self._context(user_id,request); payload=self.planner.plan(request,context); verdict=self.validator.validate(request,payload)
        if not verdict.valid: raise ValueError('; '.join(verdict.errors))
        data,mime=self.renderer.render(payload,request.format); jid=uuid4(); now=datetime.now(timezone.utc).isoformat(); safe=re.sub(r'[^A-Za-z0-9._-]+','_',payload['title']).strip('_') or 'nox_export'; filename=f'{safe}.{EXT[request.format]}'
        job=ExportJob(id=jid,user_id=user_id,format=request.format,source_type=request.source_type,source_id=request.source_id,title=payload['title'],mime_type=mime,filename=filename,size_bytes=len(data),content_base64=base64.b64encode(data).decode(),metadata={'context_counts':payload.get('context_counts',{}),'references':len(payload.get('references',[]))},created_at=now)
        if self.repository: await self.repository.save(job)
        if self.memory:
            try:
                from backend.app.domain.memories import MemoryType
                await self.memory.store(user_id,MemoryType.KNOWLEDGE,f'Export: {payload["title"]}',source='export',metadata={'export_id':str(jid),'format':request.format})
            except Exception: pass
        return ExportResult(job=job)
    async def get(self,user_id,job_id): return await self.repository.get(user_id,job_id) if self.repository else None
    async def history(self,user_id,limit=50): return await self.repository.history(user_id,limit) if self.repository else []
