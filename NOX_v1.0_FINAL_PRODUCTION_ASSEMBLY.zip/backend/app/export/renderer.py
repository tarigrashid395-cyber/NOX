from __future__ import annotations
import base64, csv, html, io, json, re, zipfile
from typing import Any
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.lib import colors
from docx import Document
from docx.shared import Inches, Pt
from pptx import Presentation
from pptx.util import Inches as PInches, Pt as PPt
from PIL import Image, ImageDraw, ImageFont

MIME={'pdf':'application/pdf','docx':'application/vnd.openxmlformats-officedocument.wordprocessingml.document','markdown':'text/markdown','html':'text/html','json':'application/json','csv':'text/csv','png':'image/png','svg':'image/svg+xml','pptx':'application/vnd.openxmlformats-officedocument.presentationml.presentation','zip':'application/zip'}
EXT={k:k for k in MIME}

class ExportRenderer:
    def render(self, payload: dict[str, Any], fmt: str) -> tuple[bytes,str]:
        content=payload['content']; title=payload.get('title') or 'NOX Export'; options=payload.get('options') or {}
        if fmt=='json': return json.dumps(payload,ensure_ascii=False,indent=2,default=str).encode(),MIME[fmt]
        if fmt=='markdown': return self._markdown(title,content,payload).encode('utf-8'),MIME[fmt]
        if fmt=='html': return self._html(title,content,payload).encode('utf-8'),MIME[fmt]
        if fmt=='csv': return self._csv(content).encode('utf-8-sig'),MIME[fmt]
        if fmt=='pdf': return self._pdf(title,content,payload),MIME[fmt]
        if fmt=='docx': return self._docx(title,content,payload),MIME[fmt]
        if fmt=='pptx': return self._pptx(title,content,payload),MIME[fmt]
        if fmt in ('png','svg'): return self._visual(title,content,fmt,options),MIME[fmt]
        if fmt=='zip': return self._zip(title,content,payload)
        raise ValueError(f'Unsupported export format: {fmt}')

    def _markdown(self,title,content,payload):
        lines=[f'# {title}','']
        self._md_value(content,lines,0)
        refs=payload.get('references') or []
        if refs:
            lines += ['', '## References'] + [f'- {x}' for x in refs]
        return '\n'.join(lines)+'\n'
    def _md_value(self,v,lines,level):
        if isinstance(v,dict):
            for k,val in v.items():
                if k in {'title'}: continue
                if isinstance(val,(dict,list)):
                    lines += [f"{'#'*(min(level+2,6))} {str(k).replace('_',' ').title()}",'']
                    self._md_value(val,lines,level+1)
                else: lines.append(f'**{str(k).replace("_"," ").title()}:** {val}')
        elif isinstance(v,list):
            for item in v:
                if isinstance(item,(dict,list)):
                    lines.append('-'); self._md_value(item,lines,level+1)
                else: lines.append(f'- {item}')
        else: lines.append(str(v))
    def _html(self,title,content,payload):
        body=self._html_value(content)
        refs=''.join(f'<li>{html.escape(str(x))}</li>' for x in payload.get('references',[]))
        if refs: body += f'<h2>References</h2><ul>{refs}</ul>'
        return f'<!doctype html><html><head><meta charset="utf-8"><title>{html.escape(title)}</title><style>body{{font-family:Arial,sans-serif;max-width:900px;margin:40px auto;line-height:1.55}}h1{{border-bottom:2px solid #333}}table{{border-collapse:collapse;width:100%}}td,th{{border:1px solid #bbb;padding:6px}}</style></head><body><h1>{html.escape(title)}</h1>{body}</body></html>'
    def _html_value(self,v):
        if isinstance(v,dict): return ''.join(f'<section><h2>{html.escape(str(k).replace("_"," ").title())}</h2>{self._html_value(val)}</section>' for k,val in v.items() if k!='title')
        if isinstance(v,list): return '<ul>'+''.join(f'<li>{self._html_value(x)}</li>' for x in v)+'</ul>'
        return f'<p>{html.escape(str(v))}</p>'
    def _csv(self,content):
        out=io.StringIO(); w=csv.writer(out)
        if isinstance(content,list) and all(isinstance(x,dict) for x in content):
            keys=sorted({k for x in content for k in x}); w.writerow(keys); [w.writerow([x.get(k,'') for k in keys]) for x in content]
        elif isinstance(content,dict):
            w.writerow(['field','value']); [w.writerow([k,json.dumps(v,ensure_ascii=False,default=str) if isinstance(v,(dict,list)) else v]) for k,v in content.items()]
        else: w.writerow(['value']); w.writerow([content])
        return out.getvalue()
    def _pdf(self,title,content,payload):
        out=io.BytesIO(); doc=SimpleDocTemplate(out,pagesize=A4,rightMargin=18*mm,leftMargin=18*mm,topMargin=20*mm,bottomMargin=20*mm)
        styles=getSampleStyleSheet(); story=[Paragraph(html.escape(title),styles['Title']),Spacer(1,10)]
        self._pdf_value(content,story,styles,0)
        refs=payload.get('references') or []
        if refs:
            story += [Spacer(1,10),Paragraph('References',styles['Heading2'])]+[Paragraph(f'- {html.escape(str(x))}',styles['BodyText']) for x in refs]
        def footer(canvas,doc):
            canvas.saveState(); canvas.setFont('Helvetica',8); canvas.drawString(18*mm,10*mm,str(title)[:90]); canvas.drawRightString(192*mm,10*mm,f'Page {doc.page}'); canvas.restoreState()
        doc.build(story,onFirstPage=footer,onLaterPages=footer); return out.getvalue()
    def _pdf_value(self,v,story,styles,level):
        if isinstance(v,dict):
            for k,val in v.items():
                if k=='title': continue
                story.append(Paragraph(html.escape(str(k).replace('_',' ').title()),styles['Heading2' if level<2 else 'Heading3'])); self._pdf_value(val,story,styles,level+1)
        elif isinstance(v,list):
            if v and all(isinstance(x,dict) for x in v):
                keys=list(dict.fromkeys(k for x in v for k in x)); data=[[str(k) for k in keys]]+[[str(x.get(k,''))[:120] for k in keys] for x in v[:100]]
                t=Table(data,repeatRows=1); t.setStyle(TableStyle([('GRID',(0,0),(-1,-1),0.4,colors.grey),('BACKGROUND',(0,0),(-1,0),colors.lightgrey),('FONTSIZE',(0,0),(-1,-1),7)])); story.append(t); story.append(Spacer(1,6))
            else:
                for x in v: story.append(Paragraph('• '+html.escape(str(x)),styles['BodyText']))
        else: story.append(Paragraph(html.escape(str(v)),styles['BodyText']))
    def _docx(self,title,content,payload):
        d=Document(); d.core_properties.title=title; d.add_heading(title,0); self._docx_value(d,content,0)
        if payload.get('references'): d.add_heading('References',1); [d.add_paragraph(str(x),style='List Bullet') for x in payload['references']]
        out=io.BytesIO(); d.save(out); return out.getvalue()
    def _docx_value(self,d,v,level):
        if isinstance(v,dict):
            for k,val in v.items():
                if k=='title': continue
                d.add_heading(str(k).replace('_',' ').title(),min(level+1,9)); self._docx_value(d,val,level+1)
        elif isinstance(v,list):
            for x in v: d.add_paragraph(str(x) if not isinstance(x,(dict,list)) else json.dumps(x,ensure_ascii=False,default=str),style='List Bullet')
        else: d.add_paragraph(str(v))
    def _pptx(self,title,content,payload):
        prs=Presentation(); prs.slide_width=PInches(13.333); prs.slide_height=PInches(7.5)
        first=prs.slides.add_slide(prs.slide_layouts[0]); first.shapes.title.text=title; first.placeholders[1].text='Generated by NOX Export Intelligence'
        slides=content.get('slides') if isinstance(content,dict) else None
        if not isinstance(slides,list): slides=[{'title':k,'bullets':v if isinstance(v,list) else [v]} for k,v in (content.items() if isinstance(content,dict) else [('Content',content)]) if k!='title']
        for i,s in enumerate(slides[:100],1):
            sl=prs.slides.add_slide(prs.slide_layouts[1]); sl.shapes.title.text=str(s.get('title',f'Slide {i}')); tf=sl.placeholders[1].text_frame; tf.clear()
            vals=s.get('bullets',s.get('content',[])); vals=vals if isinstance(vals,list) else [vals]
            for j,x in enumerate(vals):
                p=tf.paragraphs[0] if j==0 else tf.add_paragraph(); p.text=str(x); p.level=0
            notes=s.get('speaker_notes')
            if notes:
                try: sl.notes_slide.notes_text_frame.text=str(notes)
                except Exception: pass
        out=io.BytesIO(); prs.save(out); return out.getvalue()
    def _visual(self,title,content,fmt,options):
        w,h=options.get('width',1600),options.get('height',900)
        if fmt=='svg':
            txt=html.escape(self._plain(content)[:4000]); return f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}"><rect width="100%" height="100%" fill="white"/><text x="50" y="70" font-family="Arial" font-size="36">{html.escape(title)}</text><foreignObject x="50" y="100" width="{w-100}" height="{h-150}"><div xmlns="http://www.w3.org/1999/xhtml" style="font:22px Arial;white-space:pre-wrap">{txt}</div></foreignObject></svg>'.encode(),MIME['svg']
        im=Image.new('RGB',(w,h),'white'); draw=ImageDraw.Draw(im); draw.text((50,40),title,fill='black'); y=100
        for line in self._plain(content)[:6000].splitlines(): draw.text((50,y),line[:130],fill='black'); y+=28; 
        out=io.BytesIO(); im.save(out,'PNG'); return out.getvalue(),MIME['png']
    def _plain(self,v):
        if isinstance(v,dict): return '\n'.join(f'{k}: {self._plain(x)}' for k,x in v.items())
        if isinstance(v,list): return '\n'.join(f'- {self._plain(x)}' for x in v)
        return str(v)
    def _zip(self,title,content,payload):
        out=io.BytesIO()
        with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
            z.writestr('manifest.json',json.dumps({'title':title,'source_type':payload.get('source_type'),'source_id':payload.get('source_id')},ensure_ascii=False,indent=2))
            z.writestr('content.json',json.dumps(content,ensure_ascii=False,indent=2,default=str))
            z.writestr('README.md',self._markdown(title,content,payload))
            refs=payload.get('references') or []
            if refs: z.writestr('references.txt','\n'.join(map(str,refs)))
        return out.getvalue(),MIME['zip']
