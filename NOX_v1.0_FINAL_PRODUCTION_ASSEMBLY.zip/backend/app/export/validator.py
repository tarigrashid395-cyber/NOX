from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any
from backend.app.export.schemas import ExportRequest

@dataclass(slots=True)
class ValidationResult:
    valid: bool
    errors: list[str] = field(default_factory=list)

class ExportValidator:
    FORMATS={'pdf','docx','markdown','html','json','csv','png','svg','pptx','zip'}
    def validate(self, request: ExportRequest, payload: dict[str, Any]) -> ValidationResult:
        errors=[]
        if request.format not in self.FORMATS: errors.append(f'Unsupported export format: {request.format}')
        if payload.get('content') is None: errors.append('Export content is required')
        if not request.title and not payload.get('title'): errors.append('Export title is required')
        return ValidationResult(not errors, errors)
