from __future__ import annotations
import json
from backend.app.export.schemas import ExportJob
class InMemoryExportRepository:
    def __init__(self): self.jobs={}; self.templates={}
    async def ensure_schema(self): return None
    async def save(self,job): self.jobs[job.id]=job; return job
    async def get(self,user_id,job_id):
        j=self.jobs.get(job_id); return j if j and j.user_id==user_id else None
    async def history(self,user_id,limit=50): return sorted([j for j in self.jobs.values() if j.user_id==user_id],key=lambda x:x.created_at,reverse=True)[:limit]
class PostgresExportRepository:
    def __init__(self,session_factory): self.session_factory=session_factory
    async def ensure_schema(self):
        if self.session_factory is None:return
        from sqlalchemy import text
        async with self.session_factory() as s:
            await s.execute(text('CREATE TABLE IF NOT EXISTS exports (id UUID PRIMARY KEY,user_id UUID NOT NULL,format TEXT NOT NULL,source_type TEXT NOT NULL,source_id TEXT,title TEXT NOT NULL,status TEXT NOT NULL,mime_type TEXT NOT NULL,filename TEXT NOT NULL,size_bytes BIGINT NOT NULL,content_base64 TEXT NOT NULL,metadata JSONB NOT NULL DEFAULT \'{}\'::jsonb,created_at TIMESTAMPTZ NOT NULL)'))
            await s.execute(text('CREATE TABLE IF NOT EXISTS export_jobs (id UUID PRIMARY KEY,export_id UUID NOT NULL REFERENCES exports(id) ON DELETE CASCADE,status TEXT NOT NULL,created_at TIMESTAMPTZ NOT NULL)'))
            await s.execute(text('CREATE TABLE IF NOT EXISTS export_templates (id UUID PRIMARY KEY,name TEXT NOT NULL,format TEXT NOT NULL,options JSONB NOT NULL DEFAULT \'{}\'::jsonb)'))
            await s.commit()
    async def save(self,job):
        from sqlalchemy import text
        async with self.session_factory() as s:
            await s.execute(text('INSERT INTO exports (id,user_id,format,source_type,source_id,title,status,mime_type,filename,size_bytes,content_base64,metadata,created_at) VALUES (:id,:uid,:fmt,:st,:sid,:title,:status,:mime,:fn,:size,:content,:metadata,:created)'),{'id':job.id,'uid':job.user_id,'fmt':job.format,'st':job.source_type,'sid':job.source_id,'title':job.title,'status':job.status,'mime':job.mime_type,'fn':job.filename,'size':job.size_bytes,'content':job.content_base64,'metadata':json.dumps(job.metadata),'created':job.created_at}); await s.commit(); return job
    def _row(self,r): return ExportJob(id=r['id'],user_id=r['user_id'],format=r['format'],source_type=r['source_type'],source_id=r['source_id'],title=r['title'],status=r['status'],mime_type=r['mime_type'],filename=r['filename'],size_bytes=r['size_bytes'],content_base64=r['content_base64'],metadata=r['metadata'] or {},created_at=r['created_at'].isoformat())
    async def get(self,user_id,job_id):
        from sqlalchemy import text
        async with self.session_factory() as s:
            r=(await s.execute(text('SELECT * FROM exports WHERE id=:id AND user_id=:uid'),{'id':job_id,'uid':user_id})).mappings().first(); return self._row(r) if r else None
    async def history(self,user_id,limit=50):
        from sqlalchemy import text
        async with self.session_factory() as s:
            rows=(await s.execute(text('SELECT * FROM exports WHERE user_id=:uid ORDER BY created_at DESC LIMIT :limit'),{'uid':user_id,'limit':limit})).mappings().all(); return [self._row(r) for r in rows]
