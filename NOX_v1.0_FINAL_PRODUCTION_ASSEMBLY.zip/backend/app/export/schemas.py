from __future__ import annotations
from typing import Any, Literal
from uuid import UUID, uuid4
from pydantic import BaseModel, ConfigDict, Field

ExportFormat = Literal['pdf','docx','markdown','html','json','csv','png','svg','pptx','zip']
ExportSource = Literal['research','research_report','file','file_summary','study_notes','course','presentation','infographic','mind_map','timeline','flowchart','knowledge_graph','storyboard','motion','motion_project','project','project_plan','documentation','creation','visual','generic']

class ExportRequest(BaseModel):
    model_config = ConfigDict(extra='forbid')
    format: ExportFormat
    source_type: ExportSource = 'generic'
    source_id: str | None = None
    title: str = ''
    content: Any = None
    source_refs: list[str] = Field(default_factory=list)
    options: dict[str, Any] = Field(default_factory=dict)

class ExportJob(BaseModel):
    id: UUID = Field(default_factory=uuid4)
    user_id: UUID
    format: ExportFormat
    source_type: ExportSource
    source_id: str | None = None
    title: str
    status: Literal['completed','failed'] = 'completed'
    mime_type: str
    filename: str
    size_bytes: int
    content_base64: str
    metadata: dict[str, Any] = Field(default_factory=dict)
    created_at: str

class ExportResult(BaseModel):
    job: ExportJob

class ExportTemplate(BaseModel):
    id: UUID = Field(default_factory=uuid4)
    name: str
    format: ExportFormat
    options: dict[str, Any] = Field(default_factory=dict)
