from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any
from backend.app.export.schemas import ExportFormat

@dataclass(slots=True)
class ExportTemplateDefinition:
    name: str
    format: ExportFormat
    options: dict[str, Any] = field(default_factory=dict)

class ExportRegistry:
    def __init__(self): self._templates: dict[str, ExportTemplateDefinition] = {}
    def register(self, template: ExportTemplateDefinition) -> None: self._templates[template.name] = template
    def get(self, name: str) -> ExportTemplateDefinition | None: return self._templates.get(name)
    def names(self) -> list[str]: return sorted(self._templates)
    def formats(self) -> set[str]: return {x.format for x in self._templates.values()}

def register_builtin_export_templates(registry: ExportRegistry) -> None:
    for fmt in ('pdf','docx','markdown','html','json','csv','png','svg','pptx','zip'):
        registry.register(ExportTemplateDefinition(f'default_{fmt}', fmt))
