from __future__ import annotations
import re,time
from collections import defaultdict
from uuid import UUID
from backend.app.evaluation.schemas import *

_STOP={'the','and','for','with','that','this','from','into','are','was','were','have','has','not','you','your','about','what','how','why'}
def _terms(text): return {x for x in re.findall(r'[a-zA-Z0-9_]{2,}',text.lower()) if x not in _STOP}
def _overlap(a,b):
    x,y=_terms(a),_terms(b); return len(x&y)/max(1,len(y)) if y else 0.0

class ConfidenceEngine:
    def score(self,case:EvaluationCase,scores:DimensionScores)->ConfidenceScore:
        source= scores.sources if case.expected_sources else .75
        knowledge=scores.accuracy
        reasoning=scores.reasoning
        overall=max(0,min(1,.45*knowledge+.3*reasoning+.25*source))
        uncertainty=[]
        if not case.reference: uncertainty.append('no_reference_answer')
        if scores.accuracy<.6: uncertainty.append('low_accuracy_signal')
        if case.expected_sources and scores.sources<.6: uncertainty.append('weak_source_support')
        return ConfidenceScore(overall=overall,source_confidence=source,reasoning_confidence=reasoning,knowledge_confidence=knowledge,uncertainty=uncertainty)

class QualityEngine:
    def evaluate(self,case:EvaluationCase)->DimensionScores:
        response=case.response.strip(); ref=case.reference.strip()
        accuracy=_overlap(response,ref) if ref else min(1,len(_terms(response))/80)
        expected=case.expected_facts
        fact_hits=sum(1 for f in expected if f.lower() in response.lower())/max(1,len(expected)) if expected else accuracy
        accuracy=.65*accuracy+.35*fact_hits if expected else accuracy
        completeness=(min(1,len(_terms(response))/max(12,len(_terms(case.prompt))*2)) if response else 0)
        if expected: completeness=.5*completeness+.5*fact_hits
        clarity=1.0 if response and len(response)<8000 else .7 if response else 0
        reasoning=.7 if any(k in response.lower() for k in ('because','therefore','however','first','then','thus')) else .45
        sources=1.0 if case.expected_sources and all(s.lower() in response.lower() for s in case.expected_sources) else (.6 if case.expected_sources else .75)
        educational=.8 if any(k in response.lower() for k in ('example','step','practice','summary')) else .6
        return DimensionScores(accuracy=min(1,accuracy),reasoning=reasoning,sources=sources,completeness=min(1,completeness),clarity=clarity,educational_quality=educational)

class BenchmarkRunner:
    def __init__(self,repository=None): self.quality=QualityEngine(); self.confidence=ConfidenceEngine(); self.runs=defaultdict(list); self.repository=repository

    async def run(self,user_id:UUID,request:EvaluationRequest)->EvaluationResult:
        started=time.perf_counter(); results=[]; dims=[]
        for case in request.suite.cases:
            scores=self.quality.evaluate(case); conf=self.confidence.score(case,scores); dims.append(scores)
            results.append({'case_id':case.case_id,'domain':case.domain,'difficulty':case.difficulty,'scores':scores.model_dump(),'confidence':conf.model_dump()})
        if dims:
            fields=DimensionScores.model_fields
            avg={f:sum(getattr(x,f) for x in dims)/len(dims) for f in fields}
        else: avg={f:0 for f in DimensionScores.model_fields}
        dimensions=DimensionScores(**avg); confidence=self.confidence.score(EvaluationCase(case_id='aggregate',prompt='aggregate',response='x'),dimensions)
        score=sum(avg.values())/len(avg); baseline=request.regression_baseline
        passed=baseline is None or score>=baseline
        result=EvaluationResult(user_id=user_id,suite=request.suite.name,suite_version=request.suite.version,case_results=results,dimensions=dimensions,confidence=confidence,benchmark_score=score,regression_passed=passed,duration_ms=(time.perf_counter()-started)*1000)
        self.runs[user_id].append(result)
        if self.repository: await self.repository.save(result)
        return result
    async def report(self,user_id):
        runs=await self.repository.list_user(user_id) if self.repository else self.runs.get(user_id,[]); latest=runs[-1] if runs else None
        return EvaluationReport(user_id=user_id,latest=latest,runs=runs,aggregate_score=sum(x.benchmark_score for x in runs)/max(1,len(runs)),regression_rate=sum(x.regression_passed for x in runs)/max(1,len(runs)))
