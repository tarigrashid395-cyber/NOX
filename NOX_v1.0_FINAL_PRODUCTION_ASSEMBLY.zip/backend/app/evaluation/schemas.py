from __future__ import annotations
from datetime import datetime, timezone
from enum import StrEnum
from typing import Any
from uuid import UUID, uuid4
from pydantic import BaseModel, Field, ConfigDict

class EvaluationCase(BaseModel):
    model_config=ConfigDict(extra='forbid')
    case_id: str = Field(min_length=1, max_length=200)
    prompt: str = Field(min_length=1)
    response: str = ''
    reference: str = ''
    expected_sources: list[str] = Field(default_factory=list)
    expected_facts: list[str] = Field(default_factory=list)
    domain: str = 'general'
    difficulty: str = 'standard'
    metadata: dict[str, Any] = Field(default_factory=dict)

class BenchmarkSuite(BaseModel):
    name: str
    version: str = '1.0'
    cases: list[EvaluationCase] = Field(default_factory=list)

class DimensionScores(BaseModel):
    accuracy: float = Field(ge=0, le=1)
    reasoning: float = Field(ge=0, le=1)
    sources: float = Field(ge=0, le=1)
    completeness: float = Field(ge=0, le=1)
    clarity: float = Field(ge=0, le=1)
    educational_quality: float = Field(ge=0, le=1)

class ConfidenceScore(BaseModel):
    overall: float = Field(ge=0, le=1)
    source_confidence: float = Field(ge=0, le=1)
    reasoning_confidence: float = Field(ge=0, le=1)
    knowledge_confidence: float = Field(ge=0, le=1)
    uncertainty: list[str] = Field(default_factory=list)

class EvaluationResult(BaseModel):
    id: UUID = Field(default_factory=uuid4)
    user_id: UUID
    suite: str
    suite_version: str = '1.0'
    case_results: list[dict[str, Any]] = Field(default_factory=list)
    dimensions: DimensionScores
    confidence: ConfidenceScore
    regression_passed: bool = True
    benchmark_score: float = Field(ge=0, le=1)
    duration_ms: float = 0
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class EvaluationRequest(BaseModel):
    model_config=ConfigDict(extra='forbid')
    suite: BenchmarkSuite
    regression_baseline: float | None = Field(default=None, ge=0, le=1)

class EvaluationReport(BaseModel):
    user_id: UUID
    latest: EvaluationResult | None = None
    runs: list[EvaluationResult] = Field(default_factory=list)
    aggregate_score: float = Field(ge=0, le=1)
    regression_rate: float = Field(ge=0, le=1)

class AnalyticsEvent(BaseModel):
    event: str = Field(min_length=1, max_length=100)
    category: str = 'usage'
    value: float = 1.0
    success: bool = True
    latency_ms: float = 0
    agent: str | None = None
    tool: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class AnalyticsDashboard(BaseModel):
    user_id: UUID
    usage: dict[str, float]
    agents: dict[str, dict[str, float]]
    memory: dict[str, float]
    research: dict[str, float]
    learning: dict[str, float]
    evaluation: dict[str, float]
    tools: dict[str, dict[str, float]]
    audit_events: int = 0

class AdaptiveProfile(BaseModel):
    explanation_level: str = 'balanced'
    visual_density: str = 'balanced'
    motion_intensity: str = 'minimal'
    research_depth: str = 'standard'
    learning_mode: str = 'adaptive'
    rationale: list[str] = Field(default_factory=list)
