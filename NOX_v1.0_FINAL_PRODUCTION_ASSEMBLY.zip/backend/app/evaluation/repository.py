from __future__ import annotations
from collections import defaultdict
from typing import Protocol
from uuid import UUID
from backend.app.evaluation.schemas import EvaluationResult
class EvaluationRepository(Protocol):
    async def save(self,result:EvaluationResult)->None: ...
    async def list_user(self,user_id:UUID)->list[EvaluationResult]: ...
class InMemoryEvaluationRepository:
    def __init__(self): self.data=defaultdict(list)
    async def save(self,result): self.data[result.user_id].append(result)
    async def list_user(self,user_id): return list(self.data.get(user_id,[]))
class PostgresEvaluationRepository:
    def __init__(self,session_factory): self.session_factory=session_factory; self.ready=False
    async def ensure_schema(self):
        from sqlalchemy import text
        async with self.session_factory() as s:
            await s.execute(text('CREATE TABLE IF NOT EXISTS evaluation_runs (id UUID PRIMARY KEY,user_id UUID NOT NULL,suite TEXT NOT NULL,suite_version TEXT NOT NULL,case_results JSONB NOT NULL,dimensions JSONB NOT NULL,confidence JSONB NOT NULL,regression_passed BOOLEAN NOT NULL,benchmark_score DOUBLE PRECISION NOT NULL,duration_ms DOUBLE PRECISION NOT NULL,created_at TIMESTAMPTZ NOT NULL)')); await s.commit(); self.ready=True
    async def save(self,result):
        from sqlalchemy import text
        async with self.session_factory() as s:
            await s.execute(text('INSERT INTO evaluation_runs(id,user_id,suite,suite_version,case_results,dimensions,confidence,regression_passed,benchmark_score,duration_ms,created_at) VALUES (:id,:uid,:suite,:version,:cases,:dims,:conf,:passed,:score,:duration,:created)'),{'id':result.id,'uid':result.user_id,'suite':result.suite,'version':result.suite_version,'cases':result.case_results,'dims':result.dimensions.model_dump(),'conf':result.confidence.model_dump(),'passed':result.regression_passed,'score':result.benchmark_score,'duration':result.duration_ms,'created':result.created_at}); await s.commit()
    async def list_user(self,user_id):
        from sqlalchemy import text
        async with self.session_factory() as s:
            rows=(await s.execute(text('SELECT * FROM evaluation_runs WHERE user_id=:uid ORDER BY created_at'),{'uid':user_id})).mappings().all()
        return [EvaluationResult(id=r['id'],user_id=r['user_id'],suite=r['suite'],suite_version=r['suite_version'],case_results=r['case_results'],dimensions=r['dimensions'],confidence=r['confidence'],regression_passed=r['regression_passed'],benchmark_score=r['benchmark_score'],duration_ms=r['duration_ms'],created_at=r['created_at']) for r in rows]
