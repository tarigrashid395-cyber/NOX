from __future__ import annotations
from collections import defaultdict
from backend.app.evaluation.schemas import EvaluationResult

class ModelBenchmarkingSystem:
    def compare(self,results:list[EvaluationResult])->dict:
        by_suite=defaultdict(list)
        for result in results: by_suite[result.suite].append(result.benchmark_score)
        return {suite:{'runs':len(scores),'mean_score':sum(scores)/len(scores),'best_score':max(scores),'worst_score':min(scores)} for suite,scores in by_suite.items()}

class RegressionDataset:
    def check(self,result:EvaluationResult,minimum:float)->bool:
        return result.benchmark_score >= minimum
