from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Protocol

@dataclass
class ParsedDocument:
    text: str
    pages: list[str] = field(default_factory=list)
    sections: list[dict[str, Any]] = field(default_factory=list)
    tables: list[list[list[str]]] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

class DocumentParser(Protocol):
    extensions: tuple[str, ...]
    async def parse(self, data: bytes, filename: str) -> ParsedDocument: ...
