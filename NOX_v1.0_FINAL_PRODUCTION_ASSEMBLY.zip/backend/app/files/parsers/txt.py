from .base import ParsedDocument
class TxtParser:
    extensions=(".txt",)
    async def parse(self,data:bytes,filename:str)->ParsedDocument:
        text=data.decode("utf-8-sig",errors="replace")
        return ParsedDocument(text=text,pages=[text],metadata={"parser":"txt","encoding":"utf-8"})
