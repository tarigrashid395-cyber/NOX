from .base import ParsedDocument
class ImageParser:
    extensions=(".png",".jpg",".jpeg",".webp")
    async def parse(self,data:bytes,filename:str)->ParsedDocument:
        try:
            from PIL import Image
        except ImportError as exc:
            raise RuntimeError("Image parser dependency Pillow is unavailable") from exc
        import io
        image=Image.open(io.BytesIO(data))
        text=""
        try:
            import pytesseract
            text=pytesseract.image_to_string(image).strip()
        except Exception:
            text=""
        return ParsedDocument(text=text,pages=[text],metadata={"parser":"image","width":image.width,"height":image.height,"format":image.format,"ocr_available":bool(text)})
