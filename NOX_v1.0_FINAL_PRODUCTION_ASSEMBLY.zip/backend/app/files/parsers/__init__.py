from .base import ParsedDocument, DocumentParser
from .txt import TxtParser
from .csv import CsvParser
from .pdf import PdfParser
from .docx import DocxParser
from .pptx import PptxParser
from .image import ImageParser

PARSERS=(PdfParser(),DocxParser(),PptxParser(),TxtParser(),CsvParser(),ImageParser())
