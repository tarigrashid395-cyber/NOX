import csv, io
from .base import ParsedDocument
class CsvParser:
    extensions=(".csv",)
    async def parse(self,data:bytes,filename:str)->ParsedDocument:
        text=data.decode("utf-8-sig",errors="replace")
        rows=list(csv.reader(io.StringIO(text)))
        table=[[str(c) for c in row] for row in rows]
        flat="\n".join(" | ".join(row) for row in table)
        return ParsedDocument(text=flat,pages=[flat],tables=[table] if table else [],metadata={"parser":"csv","rows":len(table),"columns":max((len(r) for r in table),default=0)})
