from .base import ParsedDocument
class PdfParser:
    extensions=(".pdf",)
    async def parse(self,data:bytes,filename:str)->ParsedDocument:
        try:
            from pypdf import PdfReader
        except ImportError as exc:
            raise RuntimeError("PDF parser dependency pypdf is unavailable") from exc
        import io
        reader=PdfReader(io.BytesIO(data))
        pages=[(page.extract_text() or "").strip() for page in reader.pages]
        return ParsedDocument(text="\n\n".join(pages),pages=pages,metadata={"parser":"pdf","page_count":len(pages),"title":reader.metadata.title if reader.metadata else None})
