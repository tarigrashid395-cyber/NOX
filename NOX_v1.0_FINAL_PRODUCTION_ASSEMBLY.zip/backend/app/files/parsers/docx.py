from .base import ParsedDocument
class DocxParser:
    extensions=(".docx",)
    async def parse(self,data:bytes,filename:str)->ParsedDocument:
        try:
            from docx import Document
        except ImportError as exc:
            raise RuntimeError("DOCX parser dependency python-docx is unavailable") from exc
        import io
        doc=Document(io.BytesIO(data)); sections=[]; parts=[]; current=[]
        for p in doc.paragraphs:
            text=p.text.strip()
            if not text: continue
            style=(p.style.name or "").lower() if p.style else ""
            if "heading" in style:
                if current: sections.append({"heading":sections[-1].get("heading") if sections else "","text":"\n".join(current)}); current=[]
                sections.append({"heading":text,"text":""})
            else: current.append(text)
        if current: sections.append({"heading":"","text":"\n".join(current)})
        tables=[]
        for table in doc.tables:
            rows=[[cell.text.strip() for cell in row.cells] for row in table.rows]; tables.append(rows)
        text="\n\n".join(((s["heading"] + "\n") if s["heading"] else "") + s["text"] for s in sections)
        return ParsedDocument(text=text,pages=[text],sections=sections,tables=tables,metadata={"parser":"docx","paragraphs":len(doc.paragraphs),"tables":len(tables)})
