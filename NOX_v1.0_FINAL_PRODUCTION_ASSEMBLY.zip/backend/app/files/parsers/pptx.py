from .base import ParsedDocument
class PptxParser:
    extensions=(".pptx",)
    async def parse(self,data:bytes,filename:str)->ParsedDocument:
        try:
            from pptx import Presentation
        except ImportError as exc:
            raise RuntimeError("PPTX parser dependency python-pptx is unavailable") from exc
        import io
        prs=Presentation(io.BytesIO(data)); pages=[]; sections=[]
        for idx,slide in enumerate(prs.slides,1):
            texts=[shape.text.strip() for shape in slide.shapes if hasattr(shape,"text") and shape.text.strip()]
            content="\n".join(texts); pages.append(content); sections.append({"heading":texts[0] if texts else f"Slide {idx}","text":content,"slide":idx})
        return ParsedDocument(text="\n\n".join(pages),pages=pages,sections=sections,metadata={"parser":"pptx","slide_count":len(pages)})
