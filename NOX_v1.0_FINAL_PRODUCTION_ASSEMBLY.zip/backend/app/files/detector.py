from pathlib import Path
MIME_BY_EXT={".pdf":"application/pdf",".docx":"application/vnd.openxmlformats-officedocument.wordprocessingml.document",".pptx":"application/vnd.openxmlformats-officedocument.presentationml.presentation",".txt":"text/plain",".csv":"text/csv",".png":"image/png",".jpg":"image/jpeg",".jpeg":"image/jpeg",".webp":"image/webp"}
SUPPORTED=set(MIME_BY_EXT)
def detect_type(filename:str,content_type:str|None=None)->tuple[str,str]:
    ext=Path(filename).suffix.lower()
    if ext not in SUPPORTED: raise ValueError(f"Unsupported file type: {ext or 'unknown'}")
    return ext,MIME_BY_EXT[ext]
