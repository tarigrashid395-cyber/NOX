from .service import FileService
class FileOrchestrator:
    def __init__(self,service:FileService): self.service=service
    @property
    def repository(self): return self.service.repository
    @property
    def storage(self): return self.service.storage
    async def upload(self,*args,**kwargs): return await self.service.upload(*args,**kwargs)
    async def analyze(self,*args,**kwargs): return await self.service.analyze(*args,**kwargs)
    async def ask(self,*args,**kwargs): return await self.service.ask(*args,**kwargs)
    async def visual_summary(self,*args,**kwargs): return await self.service.visual_summary(*args,**kwargs)
