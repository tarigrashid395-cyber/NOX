from __future__ import annotations
from dataclasses import dataclass
from typing import Any
import re
@dataclass(frozen=True)
class Chunk:
    ordinal:int
    content:str
    heading_path:tuple[str,...]
    metadata:dict[str,Any]

def _sentences(text:str)->list[str]:
    return [x.strip() for x in re.split(r"(?<=[.!?。！？])\s+|\n{2,}",text) if x.strip()]

def semantic_chunk(text:str,target_size:int=1200,max_size:int=1800)->list[str]:
    units=_sentences(text); chunks=[]; buf=""
    for unit in units:
        if buf and len(buf)+1+len(unit)>max_size:
            chunks.append(buf.strip()); buf=""
        buf=(buf+" "+unit).strip()
        if len(buf)>=target_size:
            chunks.append(buf.strip()); buf=""
    if buf: chunks.append(buf.strip())
    return chunks

def hierarchical_chunk(sections:list[dict[str,Any]],target_size:int=1200,max_size:int=1800)->list[Chunk]:
    out=[]; ordinal=0
    for section in sections:
        heading=str(section.get("heading") or "").strip(); content=str(section.get("text") or "").strip()
        for piece in semantic_chunk(content,target_size,max_size):
            out.append(Chunk(ordinal,piece,(heading,) if heading else (),{"heading":heading,"slide":section.get("slide")})); ordinal+=1
    return out

def adaptive_chunk(text:str,complexity:float=0.5)->list[str]:
    complexity=max(0,min(1,complexity)); target=int(900+(1-complexity)*900); return semantic_chunk(text,target,int(target*1.5))

def chunk_document(parsed, target_size:int=1200, max_size:int=1800)->list[Chunk]:
    if parsed.sections: return hierarchical_chunk(parsed.sections,target_size,max_size)
    return [Chunk(i,x,(),{}) for i,x in enumerate(semantic_chunk(parsed.text,target_size,max_size))]
