from __future__ import annotations
from abc import ABC, abstractmethod
from datetime import datetime, timezone
from uuid import UUID
from sqlalchemy import DateTime, JSON, Integer, String, Text, ForeignKey, select, delete, update
from sqlalchemy.orm import Mapped, mapped_column
from backend.app.db.base import Base

class DocumentRecord(Base):
    __tablename__="documents"
    id:Mapped[UUID]=mapped_column(primary_key=True); user_id:Mapped[UUID]=mapped_column(index=True); filename:Mapped[str]=mapped_column(String(512)); extension:Mapped[str]=mapped_column(String(16)); media_type:Mapped[str]=mapped_column(String(160)); size_bytes:Mapped[int]=mapped_column(Integer); storage_key:Mapped[str]=mapped_column(String(1024),unique=True); status:Mapped[str]=mapped_column(String(32),index=True); metadata_json:Mapped[dict]=mapped_column(JSON,default=dict); created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=lambda:datetime.now(timezone.utc),index=True); updated_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=lambda:datetime.now(timezone.utc))
class DocumentChunkRecord(Base):
    __tablename__="document_chunks"
    id:Mapped[UUID]=mapped_column(primary_key=True); document_id:Mapped[UUID]=mapped_column(ForeignKey("documents.id",ondelete="CASCADE"),index=True); ordinal:Mapped[int]=mapped_column(Integer); content:Mapped[str]=mapped_column(Text); heading_path:Mapped[list]=mapped_column(JSON,default=list); metadata_json:Mapped[dict]=mapped_column(JSON,default=dict)
class DocumentEmbeddingRecord(Base):
    __tablename__="document_embeddings"
    id:Mapped[UUID]=mapped_column(primary_key=True); document_id:Mapped[UUID]=mapped_column(ForeignKey("documents.id",ondelete="CASCADE"),index=True); chunk_id:Mapped[UUID]=mapped_column(ForeignKey("document_chunks.id",ondelete="CASCADE"),index=True); embedding:Mapped[list]=mapped_column(JSON)
class DocumentSummaryRecord(Base):
    __tablename__="document_summaries"
    document_id:Mapped[UUID]=mapped_column(ForeignKey("documents.id",ondelete="CASCADE"),primary_key=True); payload:Mapped[dict]=mapped_column(JSON,default=dict); created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=lambda:datetime.now(timezone.utc))
class FileRepository(ABC):
    @abstractmethod
    async def create_document(self,*args,**kwargs): ...
    @abstractmethod
    async def get_document(self,user_id,document_id): ...
    @abstractmethod
    async def get_document_bundle(self,user_id,document_id): ...
    @abstractmethod
    async def history(self,user_id,limit=50): ...
    @abstractmethod
    async def replace_chunks(self,document_id,chunks): ...
    @abstractmethod
    async def save_summary(self,document_id,payload): ...
    @abstractmethod
    async def replace_embeddings(self,document_id,embeddings): ...
    @abstractmethod
    async def update_document(self,user_id,document_id,data): ...
    @abstractmethod
    async def delete_document(self,user_id,document_id): ...

class PostgresFileRepository(FileRepository):
    def __init__(self,session_factory): self.session_factory=session_factory
    async def ensure_schema(self):
        if self.session_factory is None:return
        async with self.session_factory().bind.begin() as conn:
            for table in (DocumentRecord.__table__,DocumentChunkRecord.__table__,DocumentEmbeddingRecord.__table__,DocumentSummaryRecord.__table__): await conn.run_sync(table.create,checkfirst=True)
    def _sessions(self):
        if self.session_factory is None: raise RuntimeError("PostgreSQL file storage unavailable")
        return self.session_factory()
    @staticmethod
    def _doc(r): return {"id":r.id,"user_id":r.user_id,"filename":r.filename,"extension":r.extension,"media_type":r.media_type,"size_bytes":r.size_bytes,"storage_key":r.storage_key,"status":r.status,"metadata":r.metadata_json or {},"created_at":r.created_at,"updated_at":r.updated_at}
    async def create_document(self,id,user_id,filename,media_type,size,storage_key,metadata):
        from pathlib import Path
        ext=Path(filename).suffix.lower(); now=datetime.now(timezone.utc)
        async with self._sessions() as s:
            r=DocumentRecord(id=id,user_id=user_id,filename=filename,extension=ext,media_type=media_type,size_bytes=size,storage_key=storage_key,status="uploaded",metadata_json=metadata,created_at=now,updated_at=now); s.add(r); await s.commit(); return self._doc(r)
    async def get_document(self,user_id,document_id):
        async with self._sessions() as s:
            r=(await s.execute(select(DocumentRecord).where(DocumentRecord.id==document_id,DocumentRecord.user_id==user_id))).scalar_one_or_none(); return self._doc(r) if r else None
    async def get_document_bundle(self,user_id,document_id):
        doc=await self.get_document(user_id,document_id)
        if not doc:return None
        async with self._sessions() as s:
            chunks=(await s.execute(select(DocumentChunkRecord).where(DocumentChunkRecord.document_id==document_id).order_by(DocumentChunkRecord.ordinal))).scalars()
            summary=(await s.execute(select(DocumentSummaryRecord).where(DocumentSummaryRecord.document_id==document_id))).scalar_one_or_none()
            return doc|{"chunks":[{"id":c.id,"ordinal":c.ordinal,"content":c.content,"heading_path":c.heading_path or [],"metadata":c.metadata_json or {}} for c in chunks],"summary":summary.payload if summary else None}
    async def history(self,user_id,limit=50):
        async with self._sessions() as s:
            rows=(await s.execute(select(DocumentRecord).where(DocumentRecord.user_id==user_id).order_by(DocumentRecord.created_at.desc()).limit(limit))).scalars(); return [self._doc(r) for r in rows]
    async def replace_chunks(self,document_id,chunks):
        from uuid import uuid4
        async with self._sessions() as s:
            await s.execute(delete(DocumentChunkRecord).where(DocumentChunkRecord.document_id==document_id))
            for c in chunks: s.add(DocumentChunkRecord(id=uuid4(),document_id=document_id,ordinal=c["ordinal"],content=c["content"],heading_path=c.get("heading_path",[]),metadata_json=c.get("metadata",{})))
            await s.commit()
    async def replace_embeddings(self,document_id,embeddings):
        from uuid import uuid4
        async with self._sessions() as s:
            await s.execute(delete(DocumentEmbeddingRecord).where(DocumentEmbeddingRecord.document_id==document_id))
            for e in embeddings: s.add(DocumentEmbeddingRecord(id=uuid4(),document_id=document_id,chunk_id=e["chunk_id"],embedding=e["embedding"]))
            await s.commit()
    async def save_summary(self,document_id,payload):
        async with self._sessions() as s:
            r=(await s.execute(select(DocumentSummaryRecord).where(DocumentSummaryRecord.document_id==document_id))).scalar_one_or_none()
            if r:r.payload=payload
            else:s.add(DocumentSummaryRecord(document_id=document_id,payload=payload))
            await s.commit()
    async def update_document(self,user_id,document_id,data):
        data=dict(data); data["updated_at"]=datetime.now(timezone.utc)
        if "metadata" in data:data["metadata_json"]=data.pop("metadata")
        async with self._sessions() as s: await s.execute(update(DocumentRecord).where(DocumentRecord.id==document_id,DocumentRecord.user_id==user_id).values(**data)); await s.commit()
    async def delete_document(self,user_id,document_id):
        async with self._sessions() as s:
            r=await s.execute(delete(DocumentRecord).where(DocumentRecord.id==document_id,DocumentRecord.user_id==user_id)); await s.commit(); return r.rowcount>0

class InMemoryFileRepository(FileRepository):
    def __init__(self): self.documents={}; self.chunks={}; self.summaries={}; self.embeddings={}
    async def create_document(self,id,user_id,filename,media_type,size,storage_key,metadata):
        from pathlib import Path
        now=datetime.now(timezone.utc); d={"id":id,"user_id":user_id,"filename":filename,"extension":Path(filename).suffix.lower(),"media_type":media_type,"size_bytes":size,"storage_key":storage_key,"status":"uploaded","metadata":metadata,"created_at":now,"updated_at":now}; self.documents[id]=d; return d
    async def get_document(self,user_id,document_id):
        d=self.documents.get(document_id); return dict(d) if d and d["user_id"]==user_id else None
    async def get_document_bundle(self,user_id,document_id):
        d=await self.get_document(user_id,document_id)
        if not d:return None
        return d|{"chunks":[dict(x) for x in self.chunks.get(document_id,[])],"summary":self.summaries.get(document_id)}
    async def history(self,user_id,limit=50): return sorted([dict(d) for d in self.documents.values() if d["user_id"]==user_id],key=lambda x:x["created_at"],reverse=True)[:limit]
    async def replace_chunks(self,document_id,chunks):
        from uuid import uuid4
        self.chunks[document_id]=[{"id":uuid4(),**c} for c in chunks]
    async def replace_embeddings(self,document_id,embeddings): self.embeddings={**getattr(self,"embeddings",{}),document_id:list(embeddings)}
    async def save_summary(self,document_id,payload): self.summaries[document_id]=payload
    async def update_document(self,user_id,document_id,data):
        d=await self.get_document(user_id,document_id)
        if not d:return None
        d.update(data); d["updated_at"]=datetime.now(timezone.utc); self.documents[document_id]=d; return d
    async def delete_document(self,user_id,document_id):
        if not await self.get_document(user_id,document_id):return False
        del self.documents[document_id]; self.chunks.pop(document_id,None); self.summaries.pop(document_id,None); return True
