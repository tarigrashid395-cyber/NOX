class FileJobHandler:
    def __init__(self,orchestrator): self.orchestrator=orchestrator
    async def analyze(self,user_id,document_id): return await self.orchestrator.analyze(user_id,document_id)
