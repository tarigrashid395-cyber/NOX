from pathlib import Path

from .detector import detect_type


def validate_upload(filename: str, data: bytes, max_bytes: int) -> tuple[str, str]:
    if not data:
        raise ValueError("Uploaded file is empty")
    if len(data) > max_bytes:
        raise ValueError(f"File exceeds maximum size of {max_bytes} bytes")
    safe_name = Path(filename or "upload").name
    ext, media = detect_type(safe_name)
    signatures = {
        ".pdf": data.startswith(b"%PDF-"),
        ".png": data.startswith(b"\x89PNG\r\n\x1a\n"),
        ".jpg": data.startswith(b"\xff\xd8\xff"),
        ".jpeg": data.startswith(b"\xff\xd8\xff"),
        ".webp": len(data) >= 12 and data[:4] == b"RIFF" and data[8:12] == b"WEBP",
        ".docx": data.startswith(b"PK\x03\x04"),
        ".pptx": data.startswith(b"PK\x03\x04"),
    }
    if ext in signatures and not signatures[ext]:
        raise ValueError(f"File content does not match declared type: {ext}")
    if ext in {".txt", ".csv"}:
        try:
            data.decode("utf-8")
        except UnicodeDecodeError as exc:
            raise ValueError("Text and CSV uploads must be valid UTF-8") from exc
    return ext, media
