from __future__ import annotations
from typing import Protocol
class FileStorage(Protocol):
    async def put(self,key:str,data:bytes,content_type:str)->str: ...
    async def get(self,key:str)->bytes: ...
    async def delete(self,key:str)->None: ...
class InMemoryFileStorage:
    def __init__(self): self.items={}
    async def put(self,key,data,content_type): self.items[key]=(data,content_type); return key
    async def get(self,key):
        if key not in self.items: raise FileNotFoundError(key)
        return self.items[key][0]
    async def delete(self,key): self.items.pop(key,None)
