SYSTEM_PROMPT="Analyze uploaded files using extracted evidence only; never invent document content."
