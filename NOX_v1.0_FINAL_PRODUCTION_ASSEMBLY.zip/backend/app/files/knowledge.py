from __future__ import annotations
import re
from collections import Counter
from dataclasses import dataclass
from typing import Any
@dataclass
class ExtractedKnowledge:
    entities:list[str]; concepts:list[str]; definitions:list[dict[str,str]]; facts:list[str]; relationships:list[dict[str,str]]; topics:list[str]; keywords:list[str]

def extract_knowledge(text:str)->ExtractedKnowledge:
    clean=" ".join(text.split()); sentences=[s.strip() for s in re.split(r"(?<=[.!?])\s+",clean) if s.strip()]
    definitions=[]; facts=[]; relationships=[]
    for s in sentences:
        m=re.match(r"(.{2,100}?)\s+(?:is|are|means|refers to)\s+(.{2,300})[.]?$",s,re.I)
        if m: definitions.append({"term":m.group(1).strip(),"definition":m.group(2).strip()})
        if any(k in s.lower() for k in ("because","therefore","causes","leads to","depends on")): facts.append(s)
        m2=re.search(r"\b(.{1,80}?)\s+(causes|leads to|depends on|uses|contains)\s+(.{1,120})",s,re.I)
        if m2: relationships.append({"subject":m2.group(1).strip(),"predicate":m2.group(2).lower(),"object":m2.group(3).strip()})
    words=re.findall(r"[A-Za-z][A-Za-z0-9_-]{3,}",clean.lower()); counts=Counter(words); keywords=[w for w,c in counts.most_common(30) if c>=2][:15] or [w for w,c in counts.most_common(15) if w not in {"this","that","with","from","were","have","which","what"}][:10]
    entities=sorted(set(re.findall(r"\b[A-Z][A-Za-z0-9-]{2,}(?:\s+[A-Z][A-Za-z0-9-]{2,})*",clean)))[:30]
    concepts=[d["term"] for d in definitions][:20]
    topics=keywords[:8]
    if not facts: facts=sentences[:10]
    return ExtractedKnowledge(entities,concepts,definitions,facts,relationships,topics,keywords)
