from __future__ import annotations
from uuid import UUID, uuid4
from .validation import validate_upload
from .detector import detect_type
from .metadata import extract_metadata
from .parsers import PARSERS
from .chunking import chunk_document
from .knowledge import extract_knowledge
from .summarizer import FileSummarizer
from .study_notes import StudyNotesGenerator
from .qa import answer_question
from .visual_summary import VisualSummaryGenerator
from .storage import FileStorage

class FileService:
    def __init__(self,repository,storage,vector=None,embedder=None,memory=None,research=None,max_upload_bytes=50_000_000):
        self.repository=repository; self.storage=storage; self.vector=vector; self.embedder=embedder; self.memory=memory; self.research=research; self.max_upload_bytes=max_upload_bytes
        self.parsers={ext:parser for parser in PARSERS for ext in parser.extensions}; self.summarizer=FileSummarizer(); self.notes=StudyNotesGenerator(); self.visual=VisualSummaryGenerator()
    async def upload(self,user_id:UUID,filename:str,data:bytes,content_type:str|None=None):
        ext,media=validate_upload(filename,data,self.max_upload_bytes); doc_id=uuid4(); from pathlib import Path
        safe_filename=Path(filename or "upload").name
        key=f"users/{user_id}/documents/{doc_id}/{safe_filename}"; await self.storage.put(key,data,media)
        record=await self.repository.create_document(doc_id,user_id,safe_filename,media,len(data),key,extract_metadata(safe_filename,data,media))
        return record
    async def analyze(self,user_id:UUID,document_id:UUID):
        doc=await self.repository.get_document(user_id,document_id)
        if not doc: raise FileNotFoundError("Document not found")
        data=await self.storage.get(doc["storage_key"]); parser=self.parsers[doc["extension"]]; parsed=await parser.parse(data,doc["filename"])
        chunks=chunk_document(parsed); await self.repository.replace_chunks(document_id,[{"ordinal":c.ordinal,"content":c.content,"heading_path":list(c.heading_path),"metadata":c.metadata} for c in chunks])
        if self.embedder:
            embeddings=[]
            for idx,c in enumerate(chunks):
                embeddings.append({"chunk_id":(await self.repository.get_document_bundle(user_id,document_id))["chunks"][idx]["id"],"embedding":await self.embedder.embed(c.content)})
            await self.repository.replace_embeddings(document_id,embeddings)
        knowledge=extract_knowledge(parsed.text); summary=self.summarizer.summarize(parsed.text,knowledge); notes=self.notes.generate(knowledge)
        await self.repository.save_summary(document_id,summary|{"study_notes":notes,"knowledge":knowledge.__dict__})
        await self.repository.update_document(user_id,document_id,{"status":"analyzed","metadata":doc["metadata"]|parsed.metadata})
        if self.memory:
            content=summary["executive_summary"]
            try:
                from backend.app.domain.memories import MemoryType
                await self.memory.store(user_id,MemoryType.KNOWLEDGE,content,source="file",metadata={"document_id":str(document_id),"filename":doc["filename"]})
            except Exception: pass
        return await self.repository.get_document_bundle(user_id,document_id)
    async def ask(self,user_id:UUID,document_id:UUID,question:str):
        doc=await self.repository.get_document_bundle(user_id,document_id)
        if not doc: raise FileNotFoundError("Document not found")
        memory=[]
        if self.memory:
            try: memory=await self.memory.search(user_id,question,limit=3)
            except Exception: pass
        research=[]
        if self.research and question.lower().startswith(("research ","verify ")):
            from backend.app.schemas.research import ResearchRequest
            try: research=[(await self.research.run(user_id,ResearchRequest(query=question,providers=["web"],max_sources=3))).model_dump(mode="json")]
            except Exception: pass
        return answer_question(question,doc["chunks"],memory,research)|{"document_id":str(document_id)}
    async def visual_summary(self,user_id,document_id,kind):
        doc=await self.repository.get_document_bundle(user_id,document_id)
        if not doc: raise FileNotFoundError("Document not found")
        knowledge=(doc.get("summary") or {}).get("knowledge",{})
        return self.visual.generate(kind,doc.get("summary") or {},knowledge)
