from .knowledge import extract_knowledge
from .summarizer import FileSummarizer
class FileAnalyzer:
    def __init__(self): self.summarizer=FileSummarizer()
    def analyze(self,text):
        knowledge=extract_knowledge(text); return {"knowledge":knowledge.__dict__,"summary":self.summarizer.summarize(text,knowledge)}
