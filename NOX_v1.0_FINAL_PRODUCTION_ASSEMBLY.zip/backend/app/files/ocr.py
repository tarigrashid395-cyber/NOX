from __future__ import annotations
class OCRPipeline:
    async def extract(self,data:bytes)->str:
        try:
            from PIL import Image
            import io, pytesseract
            return pytesseract.image_to_string(Image.open(io.BytesIO(data))).strip()
        except Exception as exc:
            raise RuntimeError(f"OCR unavailable: {exc}") from exc
