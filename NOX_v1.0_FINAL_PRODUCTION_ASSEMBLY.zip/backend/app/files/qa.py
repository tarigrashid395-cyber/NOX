from __future__ import annotations
import re

def answer_question(question:str,chunks:list[dict],memory:list[dict]|None=None,research=None)->dict:
    terms={t.lower() for t in re.findall(r"\w{3,}",question)}; scored=[]
    for c in chunks:
        text=c.get("content",""); tokens=set(re.findall(r"\w{3,}",text.lower())); score=len(terms&tokens)/max(1,len(terms));
        if score: scored.append((score,c))
    scored.sort(key=lambda x:x[0],reverse=True); top=[c for _,c in scored[:5]]
    if top:
        answer=" ".join(c["content"] for c in top)[:4000]; confidence=min(1.0, sum(s for s,_ in scored[:5])/max(1,len(scored[:5])))
    else:
        answer="No supporting passage was found in the document."; confidence=0.0
    return {"answer":answer,"confidence":confidence,"sources":[{"chunk_id":str(c["id"]),"excerpt":c["content"][:500]} for c in top],"memory":(memory or [])[:3],"research":research or []}
