from __future__ import annotations
from typing import Any
from .knowledge import extract_knowledge

def _sentences(text): return [s.strip() for s in text.replace("? ","?| ").replace("! ","!| ").replace(". ",".| ").split("|") if s.strip()]
class FileSummarizer:
    def summarize(self,text:str,knowledge=None)->dict[str,Any]:
        k=knowledge or extract_knowledge(text); sentences=_sentences(text); executive=" ".join(sentences[:5])[:1200]
        return {"executive_summary":executive or "No textual content was extracted.","detailed_summary":" ".join(sentences[:20])[:5000],"key_concepts":k.concepts[:15],"important_facts":k.facts[:15],"keywords":k.keywords}
