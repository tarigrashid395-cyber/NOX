from .knowledge import ExtractedKnowledge
class StudyNotesGenerator:
    def generate(self,k:ExtractedKnowledge)->dict:
        return {"objectives":[f"Understand {x}" for x in k.concepts[:5]],"definitions":k.definitions[:15],"key_facts":k.facts[:15],"review_topics":k.topics[:10],"relationships":k.relationships[:10]}
