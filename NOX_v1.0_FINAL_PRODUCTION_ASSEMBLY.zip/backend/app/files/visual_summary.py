class VisualSummaryGenerator:
    def generate(self,kind:str,summary:dict,knowledge:dict)->dict:
        kind=kind.lower();
        if kind=="timeline": return {"type":"timeline","nodes":[{"label":x,"order":i} for i,x in enumerate(knowledge.get("facts",[])[:12])]}
        if kind=="mind_map": return {"type":"mind_map","root":"Document","branches":[{"label":x,"children":[]} for x in knowledge.get("topics",[])[:10]]}
        if kind=="study_cards": return {"type":"study_cards","cards":[{"front":d.get("term",""),"back":d.get("definition","")} for d in knowledge.get("definitions",[])[:20]]}
        if kind=="comparison_table": return {"type":"comparison_table","columns":["Concept","Definition"],"rows":[[d.get("term",""),d.get("definition","")] for d in knowledge.get("definitions",[])[:20]]}
        if kind=="flowchart": return {"type":"flowchart","nodes":[{"id":str(i),"label":x} for i,x in enumerate(knowledge.get("topics",[])[:10])],"edges":[[str(i),str(i+1)] for i in range(max(0,min(9,len(knowledge.get("topics",[]))-1)))]}
        raise ValueError("Unsupported visual summary type")
