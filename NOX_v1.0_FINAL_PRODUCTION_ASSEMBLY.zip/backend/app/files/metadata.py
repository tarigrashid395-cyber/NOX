from pathlib import Path
import hashlib
from typing import Any

def extract_metadata(filename:str,data:bytes,media_type:str,parsed:dict[str,Any]|None=None)->dict[str,Any]:
    return {"filename":filename,"extension":Path(filename).suffix.lower(),"media_type":media_type,"size_bytes":len(data),"sha256":hashlib.sha256(data).hexdigest(),**(parsed or {})}
