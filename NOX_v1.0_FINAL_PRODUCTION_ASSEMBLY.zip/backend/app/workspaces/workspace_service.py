from __future__ import annotations
from datetime import datetime, timezone
from uuid import UUID
from .workspace_models import Workspace, WorkspaceCreate, WorkspaceUpdate, WorkspaceAssets

class WorkspaceService:
    def __init__(self, repository, task_service=None, artifact_generator=None, research=None, files=None, projects=None):
        self.repository=repository; self.task_service=task_service; self.artifact_generator=artifact_generator; self.research=research; self.files=files; self.projects=projects
    async def create(self,user_id:UUID,body:WorkspaceCreate): return await self.repository.save(Workspace(owner_id=user_id,name=body.name,description=body.description))
    async def get(self,user_id,wid): return await self.repository.get(user_id,wid)
    async def update(self,user_id,wid,body:WorkspaceUpdate):
        w=await self.get(user_id,wid)
        if not w:return None
        data=body.model_dump(exclude_none=True); w=w.model_copy(update=data|{'updated_at':datetime.now(timezone.utc)}); return await self.repository.save(w)
    async def assets(self,user_id,wid):
        w=await self.get(user_id,wid)
        if not w:return None
        result=WorkspaceAssets(workspace=w)
        if self.task_service: result.tasks=[x.model_dump(mode='json') for x in await self.task_service.list(user_id,workspace_id=wid)]
        if self.artifact_generator and self.artifact_generator.session_factory:
            from sqlalchemy import text
            async with self.artifact_generator.session_factory() as s:
                rows=(await s.execute(text('SELECT * FROM task_artifacts WHERE owner_id=:owner AND workspace_id=:workspace ORDER BY created_at DESC'),{'owner':user_id,'workspace':wid})).mappings().all(); result.artifacts=[dict(r) for r in rows]
        if self.research:
            try: result.research=[x.model_dump(mode='json') for x in await self.research.history(user_id,limit=50) if x.model_dump(mode='json').get('metadata',{}).get('workspace_id')==str(wid)]
            except Exception:
                result.research = []
        if self.files:
            try:
                rows=await self.files.repository.list_documents(user_id)
                result.files=[x.model_dump(mode='json') if hasattr(x,'model_dump') else x for x in rows]
            except Exception:
                result.files = []
        if self.projects:
            try: result.projects=[x.model_dump(mode='json') for x in await self.projects.history(user_id,limit=50) if getattr(x,'metadata',{}).get('workspace_id')==str(wid)]
            except Exception:
                result.projects = []
        return result
