from __future__ import annotations
from uuid import UUID
from .workspace_models import Workspace

class WorkspaceRepository:
    def __init__(self, session_factory=None): self.session_factory=session_factory; self.items={}
    async def ensure_schema(self):
        if not self.session_factory:return
        from sqlalchemy import text
        async with self.session_factory() as s:
            await s.execute(text('CREATE TABLE IF NOT EXISTS workspaces (id UUID PRIMARY KEY,owner_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,name TEXT NOT NULL,description TEXT NOT NULL DEFAULT \'\',archived BOOLEAN NOT NULL DEFAULT FALSE,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW())')); await s.execute(text('CREATE INDEX IF NOT EXISTS ix_workspaces_owner ON workspaces(owner_id)')); await s.commit()
    async def save(self,w):
        self.items[w.id]=w
        if self.session_factory:
            from sqlalchemy import text
            async with self.session_factory() as s:
                await s.execute(text('INSERT INTO workspaces(id,owner_id,name,description,archived,created_at,updated_at) VALUES (:id,:owner,:name,:description,:archived,:created,:updated) ON CONFLICT (id) DO UPDATE SET name=EXCLUDED.name,description=EXCLUDED.description,archived=EXCLUDED.archived,updated_at=EXCLUDED.updated_at'),w.model_dump()); await s.commit()
        return w
    async def get(self,owner_id,wid):
        w=self.items.get(wid)
        if w and w.owner_id==owner_id:return w
        if not self.session_factory:return None
        from sqlalchemy import text
        async with self.session_factory() as s: row=(await s.execute(text('SELECT * FROM workspaces WHERE id=:id AND owner_id=:owner'),{'id':wid,'owner':owner_id})).mappings().first()
        return Workspace.model_validate(row) if row else None
