from __future__ import annotations
from datetime import datetime, timezone
from uuid import UUID, uuid4
from pydantic import BaseModel, Field, ConfigDict

class WorkspaceCreate(BaseModel):
    model_config=ConfigDict(extra='forbid')
    name: str = Field(min_length=1,max_length=200)
    description: str = Field(default='',max_length=5000)

class WorkspaceUpdate(BaseModel):
    name: str | None = Field(default=None,min_length=1,max_length=200)
    description: str | None = Field(default=None,max_length=5000)
    archived: bool | None = None

class Workspace(BaseModel):
    id: UUID = Field(default_factory=uuid4)
    owner_id: UUID
    name: str
    description: str = ''
    archived: bool = False
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class WorkspaceAssets(BaseModel):
    workspace: Workspace
    projects: list[dict] = Field(default_factory=list)
    tasks: list[dict] = Field(default_factory=list)
    artifacts: list[dict] = Field(default_factory=list)
    research: list[dict] = Field(default_factory=list)
    files: list[dict] = Field(default_factory=list)
