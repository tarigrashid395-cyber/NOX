from backend.app.schemas.agents import TaskPlan, AgentContext, ExecutionResult, TaskResult, AgentTask
from backend.app.agents.registry import AgentRegistry
from backend.app.agents.contracts import AgentRequest
class ExecutionManager:
    def __init__(self,registry:AgentRegistry): self.registry=registry
    async def execute(self,plan:TaskPlan,context:AgentContext)->ExecutionResult:
        results=[]; errors=[]
        for task in plan.tasks:
            try:
                agent=self.registry.get(task.agent_type)
                response=await agent.execute(AgentRequest(task_id=task.task_id,user_id=context.user_id,conversation_id=context.conversation_id,input=task.input,trace_id=''))
                await agent.validate(response)
                results.append(TaskResult(task_id=task.task_id,agent_type=task.agent_type,status=response.status,result=response.result,warnings=response.warnings,citations=response.citations))
            except Exception as exc:
                errors.append(f'{task.agent_type}: {exc}')
                results.append(TaskResult(task_id=task.task_id,agent_type=task.agent_type,status='failed',warnings=[str(exc)]))
        return ExecutionResult(results=results,errors=errors)
