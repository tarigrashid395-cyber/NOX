from backend.app.schemas.agents import ExecutionResult, AgentContext, FinalResponse
class ResponseSynthesizer:
    async def synthesize(self,result:ExecutionResult,context:AgentContext)->FinalResponse:
        successful=[r for r in result.results if r.status in {'completed','partial'}]
        if not successful:
            return FinalResponse(content='The requested operation could not be completed.',warnings=result.errors)
        parts=[]; citations=[]; artifacts=[]; warnings=list(result.errors)
        for r in successful:
            value=r.result
            content=value.get('content') or value.get('answer') or value.get('message')
            if content: parts.append(str(content))
            elif value: parts.append(str(value))
            citations.extend(r.citations); warnings.extend(r.warnings)
        return FinalResponse(content='\n\n'.join(parts),citations=citations,artifacts=artifacts,warnings=warnings)
