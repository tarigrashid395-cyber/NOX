from uuid import UUID
from time import perf_counter
import logging
from backend.app.schemas.agents import FinalResponse
from backend.app.orchestration.router import IntentRouter
from backend.app.orchestration.context_builder import ContextBuilder
from backend.app.orchestration.planner import TaskPlanner
from backend.app.orchestration.execution_manager import ExecutionManager
from backend.app.orchestration.validation import ValidationLayer
from backend.app.orchestration.response_synthesizer import ResponseSynthesizer

logger=logging.getLogger(__name__)

class Supervisor:
    def __init__(self,router,context_builder,planner,execution,validation,synthesizer,memory=None):
        self.router=router; self.context_builder=context_builder; self.planner=planner; self.execution=execution; self.validation=validation; self.synthesizer=synthesizer; self.memory=memory; self.intelligence=None
        self.planner14=None; self.reviewer14=None; self.analytics=None

    async def coordinate(self,user_id:UUID,user_input:str,conversation_id:UUID|None=None):
        if self.intelligence is None: raise RuntimeError("Advanced intelligence coordinator is not configured")
        from backend.app.intelligence.schemas import PlanRequest
        context={}
        if getattr(self, "graph", None) is not None:
            try:
                graph=await self.graph.graph(user_id); context["knowledge_graph"]={"node_count":len(graph.nodes),"edge_count":len(graph.edges)}
            except Exception as exc: logger.debug("graph context unavailable", exc_info=exc)
        return await self.intelligence.execute(user_id,PlanRequest(request=user_input,conversation_id=conversation_id,context=context))

    async def _record(self,user_id,event,value,latency_ms=0,success=True,metadata=None):
        if self.analytics is None: return
        try: await self.analytics.record(user_id,self.analytics_event(event,value,latency_ms,success,metadata or {}))
        except Exception: logger.debug("cognitive analytics write failed",exc_info=True)

    def analytics_event(self,event,value,latency_ms,success,metadata):
        from backend.app.evaluation.schemas import AnalyticsEvent
        return AnalyticsEvent(event=event,category="cognitive",value=float(value),success=success,latency_ms=latency_ms,agent=event.split('.')[0],metadata=metadata)

    async def handle(self,user_id:UUID,user_input:str,conversation_id:UUID|None=None,event_sink=None)->FinalResponse:
        plan14=None
        if event_sink: await event_sink({"type":"status","label":"Thinking","phase":"thinking"})
        if self.planner14 is not None:
            started=perf_counter();
            if event_sink: await event_sink({"type":"status","label":"Planning","phase":"planning"})
            plan14=await self.planner14.plan(user_input,user_id,conversation_id); await self.planner14.save(plan14)
            planner_elapsed=(perf_counter()-started)*1000
            await self._record(user_id,"planner_latency",planner_elapsed, planner_elapsed, True, {"complexity":plan14.complexity.value,"complexity_score":plan14.complexity_score})
            await self._record(user_id,"planning_confidence",plan14.confidence,0,True,{"plan_id":str(plan14.plan_id)})
            if event_sink: await event_sink({"type":"plan","label":"Build Plan","phase":"planning","plan_id":str(plan14.plan_id),"steps":len(plan14.execution_steps)})
        if event_sink: await event_sink({"type":"status","label":"Researching","phase":"researching"})
        context=await self.context_builder.build(user_id,user_input,conversation_id)
        route=await self.router.route(user_input)
        plan=await self.planner.plan(route,context)
        if event_sink: await event_sink({"type":"status","label":"Executing Agents","phase":"execution"})
        response=None
        workforce=getattr(self,'workforce',None)
        workforce_types={'research','learning','coding','writing','analysis','business','project','file_processing','visual','motion'}
        if workforce is not None and plan14 is not None and plan14.task_type.value in workforce_types and workforce.ready_for(plan14.task_type.value):
            from backend.app.agents.workforce.agent_models import AgentExecutionRequest
            wf_request=AgentExecutionRequest(goal=user_input,conversation_id=conversation_id,complexity=plan14.complexity.value,mode='auto',max_agents=4,context={'task_type':plan14.task_type.value,'plan_id':str(plan14.plan_id),'planner_confidence':plan14.confidence})
            wf_result=await workforce.execute(user_id,wf_request)
            if not wf_result.executions or not any(x.status=='completed' for x in wf_result.executions):
                raise RuntimeError('Agent workforce execution failed')
            from backend.app.schemas.agents import FinalResponse
            response=FinalResponse(content=wf_result.merged_response,citations=[c for x in wf_result.executions for c in x.citations],artifacts=[a for x in wf_result.executions for a in x.artifacts],warnings=[x.error for x in wf_result.executions if x.error])
        else:
            result=await self.execution.execute(plan,context)
            verdict=await self.validation.validate(result)
            if not verdict.valid: raise RuntimeError('; '.join(verdict.errors))
            response=await self.synthesizer.synthesize(result,context)
        if event_sink: await event_sink({"type":"status","label":"Reviewing","phase":"reviewing"})
        review_count=0
        if self.reviewer14 is not None and plan14 is not None:
            for iteration in (1,2):
                review_started=perf_counter()
                if event_sink: await event_sink({"type":"review","label":"Review Response","phase":"reviewing","iteration":iteration})
                report=await self.reviewer14.review(user_input,plan14.model_dump(mode="json"),response.content,user_id,iteration)
                review_elapsed=(perf_counter()-review_started)*1000
                await self._record(user_id,"reviewer_latency",review_elapsed,review_elapsed,True,{"overall_score":report.overall_score,"iteration":iteration})
                await self._record(user_id,"review_score",report.overall_score,review_elapsed,True,{"iteration":iteration,"needs_revision":report.needs_revision})
                review_count=iteration
                if report.overall_score >= 85 and not report.needs_revision: break
                if iteration == 2: break
                feedback=" ".join(report.feedback)
                revised_context=context.model_copy(deep=True)
                revised_context.metadata=dict(revised_context.metadata)
                revised_context.metadata["review_feedback"]=feedback
                revised_plan=plan.model_copy(deep=True)
                for task in revised_plan.tasks:
                    task.input=dict(task.input); task.input["review_feedback"]=feedback; task.input["revision_iteration"]=2
                revised_result=await self.execution.execute(revised_plan,revised_context)
                revised_verdict=await self.validation.validate(revised_result)
                if revised_verdict.valid: response=await self.synthesizer.synthesize(revised_result,revised_context)
            await self._record(user_id,"revision_count",review_count,0,True,{"plan_id":str(plan14.plan_id)})
        if event_sink: await event_sink({"type":"status","label":"Writing","phase":"writing"})
        if self.memory and response.content:
            try:
                from backend.app.domain.memories import MemoryType
                await self.memory.store(context.user_id,MemoryType.CONVERSATION,response.content,conversation_id=context.conversation_id,source="supervisor")
            except Exception as exc: logger.warning("supervisor memory write failed", exc_info=exc)
        return response
