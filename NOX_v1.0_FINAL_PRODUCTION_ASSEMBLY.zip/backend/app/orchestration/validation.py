from backend.app.schemas.agents import ExecutionResult, ValidationResult
class ValidationLayer:
    async def validate(self,result:ExecutionResult)->ValidationResult:
        errors=list(result.errors); warnings=[]
        for item in result.results:
            if item.status not in {'completed','partial','failed'}: errors.append(f'Invalid status for {item.task_id}')
        return ValidationResult(valid=not errors,errors=errors,warnings=warnings)
