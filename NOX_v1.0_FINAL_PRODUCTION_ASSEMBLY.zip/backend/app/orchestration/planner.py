from uuid import uuid4
from backend.app.schemas.agents import RouteDecision, AgentContext, TaskPlan, AgentTask
from backend.app.agents.registry import AgentRegistry
class TaskPlanner:
    def __init__(self,registry:AgentRegistry): self.registry=registry
    async def plan(self,route:RouteDecision,context:AgentContext)->TaskPlan:
        if route.agent_type not in self.registry.names(): raise ValueError(f'No registered agent for {route.agent_type}')
        return TaskPlan(tasks=[AgentTask(task_id=uuid4(),agent_type=route.agent_type,input={'text':context.user_input,'memories':context.memories,**route.parameters})],rationale=f'Routed to {route.agent_type}')
