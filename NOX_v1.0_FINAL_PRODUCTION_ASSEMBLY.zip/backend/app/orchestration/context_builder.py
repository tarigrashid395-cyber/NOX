from uuid import UUID
from backend.app.schemas.agents import AgentContext

class ContextBuilder:
    def __init__(self,memory=None): self.memory=memory
    async def build(self,user_id:UUID,user_input:str,conversation_id:UUID|None=None)->AgentContext:
        memories=[]
        if self.memory:
            try:
                results=await self.memory.search(user_id,user_input,limit=8)
                memories=[r.model_dump(mode="json") if hasattr(r,"model_dump") else r for r in results]
            except Exception:
                memories=[]
        return AgentContext(user_id=user_id,conversation_id=conversation_id,user_input=user_input,memories=memories)
