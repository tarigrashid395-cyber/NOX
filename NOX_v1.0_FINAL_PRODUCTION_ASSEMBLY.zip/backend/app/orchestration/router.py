import re
from uuid import UUID
from backend.app.schemas.agents import RouteDecision
from backend.app.agents.registry import AgentRegistry
class IntentRouter:
    def __init__(self, registry:AgentRegistry): self.registry=registry
    async def route(self, text:str)->RouteDecision:
        q=text.lower()
        rules=[('research',r'\b(research|sources|cite|citation|بحث|مصادر|مراجع)\b'),('study',r'\b(study|quiz|flashcard|learn|شرح|اختبار|بطاقات)\b'),('planning',r'\b(plan|schedule|task|goal|خطة|مهام|هدف)\b'),('memory',r'\b(remember|memory|تذكر|ذاكرة)\b'),('export',r'\b(export|pdf|docx|pptx|markdown|html|json|csv|png|svg|zip|تصدير|ملف pdf|وورد|بوربوينت|حزمة)\b'),('file',r'\b(file|pdf|document|ملف|وثيقة)\b'),('visual',r'\b(mind map|mindmap|flowchart|timeline|roadmap|comparison|infographic|hierarchy|process|knowledge graph|study cards|خريطة|مخطط|مقارنة|انفوجرافيك)\b'),('motion',r'\b(animation|motion|فيديو تعليمي|تحريك)\b'),('creation',r'\b(create|creation|design|generate|course|presentation|infographic|storyboard|study material|brand|marketing|product|roadmap|documentation|أنشئ|إنشاء|صمم|دورة|عرض|انفوجرافيك|قصة|مادة دراسية|علامة تجارية|خطة طريق)\b')]
        for agent,pat in rules:
            if agent in self.registry.names() and re.search(pat,q):
                params={}
                if agent=='file':
                    match=re.search(r'[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-5][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}', text)
                    if match: params['document_id']=str(UUID(match.group(0)))
                    if re.search(r'\b(ask|question|answer|سؤال|اسأل)\b',q): params['action']='qa'; params['question']=text
                    else: params['action']='analyze'
                return RouteDecision(agent_type=agent,confidence=.92,intent=agent,parameters=params)
        return RouteDecision(agent_type='planning' if 'planning' in self.registry.names() else next(iter(self.registry.names()), 'unknown'),confidence=.25,intent='general',parameters={})
