from __future__ import annotations
import asyncio
from time import perf_counter
from uuid import UUID
from .tool_models import ToolRequest, ToolResult
from .tool_permissions import ToolPermissionService
from .tool_registry import ToolRegistry
from .tool_validator import ToolValidator
from .tool_analytics import ToolAnalytics

class ToolExecutor:
    def __init__(self, registry: ToolRegistry, validator: ToolValidator, permissions: ToolPermissionService, analytics: ToolAnalytics):
        self.registry, self.validator, self.permissions, self.analytics = registry, validator, permissions, analytics

    async def execute(self, user_id: UUID, request: ToolRequest, context: dict | None = None, role: str = 'user') -> ToolResult:
        definition, implementation = self.registry.get(request.tool_id)
        context = context or {}
        await self.permissions.authorize(user_id, role, definition.permissions)
        await self.validator.validate_request(definition, implementation, request, context)
        timeout = request.timeout_seconds or definition.timeout_seconds
        started = perf_counter()
        try:
            result = await asyncio.wait_for(implementation.execute(user_id, request, context), timeout=timeout)
            latency=(perf_counter()-started)*1000
            await self.analytics.record(user_id, 'tool_used', definition.id, True, latency_ms=latency)
            return result
        except Exception as exc:
            await self.analytics.record(user_id, 'tool_failure', definition.id, False, latency_ms=(perf_counter()-started)*1000, metadata={'error': type(exc).__name__})
            raise

    async def health(self) -> list[dict]:
        results = []
        for definition in self.registry.list():
            _, implementation = self.registry.get(definition.id)
            try:
                health = await implementation.health()
                results.append({'tool_id': definition.id, 'status': definition.status.value, **health})
            except Exception as exc:
                results.append({'tool_id': definition.id, 'status': 'unhealthy', 'error': type(exc).__name__})
        return results
