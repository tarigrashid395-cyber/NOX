"""Execution timing utilities exposed through the Phase 18 analytics layer."""
from time import perf_counter
__all__=['perf_counter']
