"""Research search tool backed by the existing Research Engine."""
from .native import ResearchTool
__all__=['ResearchTool']
