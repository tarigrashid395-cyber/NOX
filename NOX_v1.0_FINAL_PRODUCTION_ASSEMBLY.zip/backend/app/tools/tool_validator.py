from __future__ import annotations
from .tool_models import ToolRequest, ToolDefinition

class ToolValidator:
    def validate_definition(self, definition: ToolDefinition) -> None:
        if not definition.capabilities:
            raise ValueError(f'Tool {definition.id} must expose at least one capability')
        if definition.timeout_seconds <= 0:
            raise ValueError(f'Tool {definition.id} timeout must be positive')

    async def validate_request(self, definition: ToolDefinition, implementation, request: ToolRequest, context: dict) -> None:
        self.validate_definition(definition)
        if request.operation != 'execute':
            raise ValueError(f'Unsupported tool operation: {request.operation}')
        errors = await implementation.validate(request, context)
        if errors:
            raise ValueError('; '.join(errors))
