from __future__ import annotations
from uuid import UUID

class ToolPermissionService:
    ROLE_PERMISSIONS = {
        'user': {'read', 'write', 'execute'},
        'admin': {'read', 'write', 'execute', 'admin'},
    }

    def allowed(self, role: str, required: list[str]) -> bool:
        granted = self.ROLE_PERMISSIONS.get(role, self.ROLE_PERMISSIONS['user'])
        return set(required).issubset(granted)

    async def authorize(self, user_id: UUID, role: str, required: list[str]) -> None:
        if not self.allowed(role, required):
            raise PermissionError(f'Tool permission denied for {user_id}: {required}')
