from __future__ import annotations
from .tool_models import ToolDefinition

class ToolRegistry:
    def __init__(self):
        self._definitions: dict[str, ToolDefinition] = {}
        self._implementations: dict[str, object] = {}

    def register(self, definition: ToolDefinition, implementation: object) -> None:
        key = definition.id.lower()
        if key in self._definitions:
            raise ValueError(f'Duplicate tool: {definition.id}')
        self._definitions[key] = definition
        self._implementations[key] = implementation

    def get(self, tool_id: str) -> tuple[ToolDefinition, object]:
        key = tool_id.lower()
        if key not in self._definitions:
            raise KeyError(f'Unknown tool: {tool_id}')
        return self._definitions[key], self._implementations[key]

    def list(self) -> list[ToolDefinition]:
        return list(self._definitions.values())

    def names(self) -> set[str]:
        return set(self._definitions)
