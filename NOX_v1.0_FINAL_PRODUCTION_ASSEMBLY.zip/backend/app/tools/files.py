from backend.app.files.service import FileService
class FileTools:
    def __init__(self,service:FileService): self.service=service
    async def analyze(self,user_id,document_id): return await self.service.analyze(user_id,document_id)
    async def ask(self,user_id,document_id,question): return await self.service.ask(user_id,document_id,question)
