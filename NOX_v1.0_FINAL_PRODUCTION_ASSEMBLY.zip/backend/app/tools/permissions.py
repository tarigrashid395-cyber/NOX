"""Compatibility export for the Phase 18 permission service."""
from .tool_permissions import ToolPermissionService
__all__=['ToolPermissionService']
