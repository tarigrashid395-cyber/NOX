from __future__ import annotations
from enum import StrEnum
from typing import Any, Protocol
from uuid import UUID, uuid4
from pydantic import BaseModel, ConfigDict, Field

class ToolStatus(StrEnum):
    ACTIVE = 'active'
    DEGRADED = 'degraded'
    DISABLED = 'disabled'

class ToolDefinition(BaseModel):
    model_config = ConfigDict(extra='forbid')
    id: str = Field(min_length=1, max_length=120)
    name: str = Field(min_length=1, max_length=160)
    description: str = Field(min_length=1, max_length=2000)
    capabilities: list[str] = Field(default_factory=list)
    permissions: list[str] = Field(default_factory=lambda: ['read'])
    status: ToolStatus = ToolStatus.ACTIVE
    cost: float = Field(default=0.0, ge=0)
    timeout_seconds: float = Field(default=60, gt=0, le=3600)

class ToolRequest(BaseModel):
    model_config = ConfigDict(extra='forbid')
    tool_id: str
    operation: str = 'execute'
    input: dict[str, Any] = Field(default_factory=dict)
    timeout_seconds: float | None = Field(default=None, gt=0, le=3600)

class ToolResult(BaseModel):
    execution_id: UUID = Field(default_factory=uuid4)
    tool_id: str
    status: str
    output: dict[str, Any] = Field(default_factory=dict)
    confidence: float = Field(default=1.0, ge=0, le=1)
    duration_ms: float = Field(default=0, ge=0)
    error: str | None = None

class ToolImplementation(Protocol):
    async def execute(self, user_id: UUID, request: ToolRequest, context: dict[str, Any]) -> ToolResult: ...
    async def validate(self, request: ToolRequest, context: dict[str, Any]) -> list[str]: ...
    async def health(self) -> dict[str, Any]: ...
