from __future__ import annotations
from .tool_models import ToolDefinition, ToolRequest
from .tool_registry import ToolRegistry

class ToolRouter:
    CAPABILITY_MAP = {
        'memory': 'memory', 'research': 'research', 'file': 'file', 'document': 'document',
        'study': 'study', 'coding': 'code', 'code': 'code', 'export': 'export', 'visual': 'visual',
        'analytics': 'analytics', 'knowledge': 'knowledge',
    }
    def __init__(self, registry: ToolRegistry): self.registry = registry
    def discover(self, capability: str | None = None) -> list[ToolDefinition]:
        if not capability: return self.registry.list()
        key = self.CAPABILITY_MAP.get(capability.lower(), capability.lower())
        return [x for x in self.registry.list() if key in x.capabilities or key == x.id]
    def route(self, request: ToolRequest) -> ToolDefinition:
        definition, _ = self.registry.get(request.tool_id)
        return definition
