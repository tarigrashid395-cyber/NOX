"""Knowledge retrieval tool backed by the existing Knowledge Graph Engine."""
from .native import KnowledgeTool
__all__=['KnowledgeTool']
