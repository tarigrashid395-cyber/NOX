from __future__ import annotations
import json
from time import perf_counter
from uuid import UUID
from .tool_models import ToolDefinition, ToolRequest, ToolResult

class NativeTool:
    def __init__(self, tool_id: str, name: str, description: str, capabilities: list[str], permissions=None):
        self.definition = ToolDefinition(id=tool_id, name=name, description=description, capabilities=capabilities, permissions=permissions or ['read','execute'])
        self.container = None
    def bind(self, container): self.container = container; return self
    async def validate(self, request, context):
        if self.container is None: return ['Tool container is not initialized']
        return []
    async def health(self): return {'healthy': self.container is not None}

class MemoryTool(NativeTool):
    async def execute(self, user_id, request, context):
        started=perf_counter(); query=request.input.get('query') or request.input.get('goal') or ''
        rows=await self.container.memory.search(user_id, query, limit=int(request.input.get('limit',12)))
        return ToolResult(tool_id=self.definition.id,status='completed',output={'items':[x.model_dump(mode='json') if hasattr(x,'model_dump') else x for x in rows]},confidence=.9 if rows else .55,duration_ms=(perf_counter()-started)*1000)

class ResearchTool(NativeTool):
    async def execute(self, user_id, request, context):
        from backend.app.schemas.research import ResearchRequest
        started=perf_counter(); query=request.input.get('query') or request.input.get('goal') or request.input.get('text')
        if not query: raise ValueError('Research tool requires query')
        req=ResearchRequest(query=query, max_sources=int(request.input.get('max_sources',8)), include_report=True, reuse_memory=True)
        result=await self.container.research.run(user_id,req)
        return ToolResult(tool_id=self.definition.id,status='completed',output=result.model_dump(mode='json'),confidence=.85 if result.evidence else .55,duration_ms=(perf_counter()-started)*1000)

class FileTool(NativeTool):
    async def execute(self, user_id, request, context):
        started=perf_counter(); document_id=request.input.get('document_id'); goal=request.input.get('goal') or request.input.get('query')
        if not document_id or not goal: raise ValueError('File tool requires document_id and goal')
        from uuid import UUID
        result=await self.container.files.analyze(user_id,UUID(str(document_id)),goal)
        output=result.model_dump(mode='json') if hasattr(result,'model_dump') else result
        return ToolResult(tool_id=self.definition.id,status='completed',output=output,confidence=.86,duration_ms=(perf_counter()-started)*1000)

class DocumentTool(NativeTool):
    async def execute(self,user_id,request,context):
        started=perf_counter(); content=request.input.get('content',''); title=request.input.get('title') or 'NOX Document'
        if not content: raise ValueError('Document tool requires content')
        fmt=request.input.get('format','markdown')
        if fmt not in {'markdown','html','json','csv'}: raise ValueError('Document tool supports markdown, html, json and csv')
        from backend.app.export.schemas import ExportRequest
        result=await self.container.export.export(user_id,ExportRequest(format=fmt,source_type='documentation',title=title,content=content))
        return ToolResult(tool_id=self.definition.id,status='completed',output=result.model_dump(mode='json'),confidence=1,duration_ms=(perf_counter()-started)*1000)

class StudyTool(NativeTool):
    async def execute(self,user_id,request,context):
        started=perf_counter(); goal=request.input.get('goal') or request.input.get('query')
        if not goal: raise ValueError('Study tool requires goal')
        result=await self.container.workforce.execute(user_id, __import__('backend.app.agents.workforce.agent_models',fromlist=['AgentExecutionRequest']).AgentExecutionRequest(goal=goal,mode='single',preferred_agents=['study'],context={'task_type':'learning'}))
        return ToolResult(tool_id=self.definition.id,status='completed',output={'response':result.merged_response,'confidence':result.confidence},confidence=result.confidence,duration_ms=(perf_counter()-started)*1000)

class CodeTool(NativeTool):
    async def execute(self,user_id,request,context):
        started=perf_counter(); goal=request.input.get('goal') or request.input.get('query')
        if not goal: raise ValueError('Code tool requires goal')
        from backend.app.agents.workforce.agent_models import AgentExecutionRequest
        result=await self.container.workforce.execute(user_id,AgentExecutionRequest(goal=goal,mode='single',preferred_agents=['coding'],context={'task_type':'coding','code':request.input.get('code','')}))
        return ToolResult(tool_id=self.definition.id,status='completed',output={'response':result.merged_response,'confidence':result.confidence},confidence=result.confidence,duration_ms=(perf_counter()-started)*1000)

class ExportTool(NativeTool):
    async def execute(self,user_id,request,context):
        from backend.app.export.schemas import ExportRequest
        started=perf_counter(); content=request.input.get('content') or request.input.get('text','')
        title=request.input.get('title') or 'NOX Export'; fmt=request.input.get('format','markdown')
        result=await self.container.export.export(user_id,ExportRequest(format=fmt,source_type=request.input.get('source_type','task'),source_id=request.input.get('source_id'),title=title,content=content))
        return ToolResult(tool_id=self.definition.id,status='completed',output=result.model_dump(mode='json'),confidence=1,duration_ms=(perf_counter()-started)*1000)

class VisualTool(NativeTool):
    async def execute(self,user_id,request,context):
        from backend.app.visual.schemas import VisualRequest
        started=perf_counter(); visual_type=request.input.get('visual_type','flowchart'); title=request.input.get('title') or 'NOX Visual'; data=request.input.get('content') or request.input.get('data') or {}
        req=VisualRequest(visual_type=visual_type,title=title,content=data,source_refs=request.input.get('source_refs',[]))
        result=await self.container.visual.create(user_id,req,request.input.get('format','json'))
        return ToolResult(tool_id=self.definition.id,status='completed',output=result,confidence=.9,duration_ms=(perf_counter()-started)*1000)

class AnalyticsTool(NativeTool):
    async def execute(self,user_id,request,context):
        dashboard=await self.container.analytics.dashboard(user_id,graph=self.container.graph)
        return ToolResult(tool_id=self.definition.id,status='completed',output=dashboard.model_dump(mode='json'),confidence=1)

class KnowledgeTool(NativeTool):
    async def execute(self,user_id,request,context):
        from backend.app.graph.schemas import GraphQuery
        query=request.input.get('query') or request.input.get('goal') or ''
        result=await self.container.graph.search_query(user_id,GraphQuery(query=query,limit=int(request.input.get('limit',12))))
        return ToolResult(tool_id=self.definition.id,status='completed',output=result.model_dump(mode='json'),confidence=.85 if result.nodes else .5)

def register_native_tools(registry, container):
    tools=[MemoryTool('memory','Memory Tool','Search and persist durable NOX memory',['memory']),ResearchTool('research','Research Tool','Execute the existing Research Engine',['research']),FileTool('file','File Tool','Analyze existing user documents',['file']),DocumentTool('document','Document Tool','Create validated textual document content',['document'],['write','execute']),StudyTool('study','Study Tool','Execute Study specialist workflows',['study']),CodeTool('code','Code Tool','Execute Coding specialist workflows',['code']),ExportTool('export','Export Tool','Render using existing Export Engine',['export'],['write','execute']),VisualTool('visual','Visual Tool','Create structured visual artifacts',['visual'],['write','execute']),AnalyticsTool('analytics','Analytics Tool','Read NOX analytics',['analytics']),KnowledgeTool('knowledge','Knowledge Tool','Retrieve user knowledge context',['knowledge'])]
    for tool in tools: registry.register(tool.definition,tool.bind(container))
    return registry
