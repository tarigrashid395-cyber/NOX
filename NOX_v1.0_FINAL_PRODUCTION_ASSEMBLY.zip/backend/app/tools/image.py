"""Visual tool compatibility module backed by the existing Visual Engine."""
from .native import VisualTool
__all__=['VisualTool']
