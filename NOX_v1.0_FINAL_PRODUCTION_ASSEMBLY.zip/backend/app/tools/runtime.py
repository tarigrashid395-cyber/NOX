"""Compatibility export for the Phase 18 execution runtime."""
from .tool_executor import ToolExecutor
__all__=['ToolExecutor']
