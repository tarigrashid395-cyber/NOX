"""Compatibility export for the Phase 18 registry."""
from .tool_registry import ToolRegistry
__all__=['ToolRegistry']
