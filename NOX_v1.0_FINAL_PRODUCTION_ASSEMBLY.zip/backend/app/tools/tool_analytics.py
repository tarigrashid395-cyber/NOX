from __future__ import annotations
from time import perf_counter
from uuid import UUID
from backend.app.evaluation.schemas import AnalyticsEvent

class ToolAnalytics:
    def __init__(self, analytics=None):
        self.analytics = analytics

    async def record(self, user_id: UUID, event: str, tool: str, success: bool, value: float = 1.0, latency_ms: float = 0, metadata: dict | None = None) -> None:
        if self.analytics is None:
            return
        await self.analytics.record(user_id, AnalyticsEvent(event=event, category='tools', value=value, success=success, latency_ms=latency_ms, tool=tool, metadata=metadata or {}))

    async def timed(self, user_id: UUID, tool: str):
        started = perf_counter()
        class Timer:
            async def finish(inner, success: bool, metadata: dict | None = None):
                latency = (perf_counter() - started) * 1000
                await self.record(user_id, 'tool_execution', tool, success, latency_ms=latency, metadata=metadata)
                return latency
        return Timer()
