from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from backend.app.config import get_settings
from backend.app.logging import configure_logging
from backend.app.lifespan import lifespan
from backend.app.api.router import router
from backend.app.api.middleware import TraceMiddleware, SecurityHeadersMiddleware

def create_app()->FastAPI:
    settings=get_settings(); configure_logging(settings.log_level)
    app=FastAPI(title=settings.app_name,version='1.0.0-rc1',lifespan=lifespan)
    app.add_middleware(CORSMiddleware,allow_origins=settings.cors_origins,allow_credentials=True,allow_methods=['*'],allow_headers=['*'])
    app.add_middleware(SecurityHeadersMiddleware, production=settings.app_env.lower() in {'production','prod'}); app.add_middleware(TraceMiddleware); app.include_router(router)
    return app
app=create_app()
