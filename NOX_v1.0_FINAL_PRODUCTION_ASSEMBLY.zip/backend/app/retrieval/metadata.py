def build_retrieval_metadata(**values): return dict(values)
