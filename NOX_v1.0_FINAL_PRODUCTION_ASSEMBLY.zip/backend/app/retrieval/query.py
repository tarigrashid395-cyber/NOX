from __future__ import annotations
from pydantic import BaseModel, Field
class RetrievalQuery(BaseModel):
    text: str = Field(min_length=1)
    limit: int = Field(default=10,ge=1,le=100)
