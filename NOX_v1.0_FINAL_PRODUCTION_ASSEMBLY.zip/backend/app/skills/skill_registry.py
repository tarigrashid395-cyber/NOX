from __future__ import annotations
from .skill_models import SkillDefinition
class SkillRegistry:
    def __init__(self): self._skills={}
    def register(self,skill:SkillDefinition):
        key=skill.name.lower()
        if key in self._skills: raise ValueError(f'Duplicate skill: {skill.name}')
        self._skills[key]=skill
    def get(self,name):
        try:return self._skills[name.lower()]
        except KeyError:raise KeyError(f'Unknown skill: {name}') from None
    def list(self):return list(self._skills.values())
