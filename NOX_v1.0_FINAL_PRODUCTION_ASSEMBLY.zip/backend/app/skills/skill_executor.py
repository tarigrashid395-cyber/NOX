from __future__ import annotations
from .skill_models import SkillExecutionRequest, SkillExecutionResult
from .skill_validator import SkillValidator
import asyncio
class SkillExecutor:
    def __init__(self,registry,agent_router,metrics=None,planner=None): self.registry=registry; self.agent_router=agent_router; self.metrics=metrics; self.validator=SkillValidator(); self.planner=planner
    async def execute(self,user_id,request:SkillExecutionRequest,context=None):
        skill=self.registry.get(request.skill); self.validator.validate_definition(skill); self.validator.validate_request(skill,request)
        if self.metrics: await self.metrics.record(user_id,'skill_used',1,True,skill.agent_id,{'skill':skill.name})
        ctx=dict(context or {}); ctx['skill']=skill.name; ctx['task_type']=skill.agent_id; ctx['skill_inputs']=request.inputs
        try:
            from backend.app.agents.workforce.agent_models import AgentExecutionRequest
            result=await self.agent_router.execute(AgentExecutionRequest(goal=request.goal,conversation_id=None,complexity='COMPLEX',mode='single',max_agents=1,context=ctx),user_id)
            if not result.executions or result.executions[0].status!='completed': raise RuntimeError(result.executions[0].error if result.executions else 'Skill agent execution failed')
            output={'content':result.merged_response,'agents':result.selected_agents,'confidence':result.confidence}
            if result.confidence<skill.confidence_requirements: raise RuntimeError(f'Skill confidence below required threshold: {result.confidence:.3f}')
            chained=[]
            if request.parallel:
                parallel_results=await asyncio.gather(*(self.execute(user_id,SkillExecutionRequest(skill=name,goal=result.merged_response,inputs={'previous_output':result.merged_response}),ctx) for name in request.parallel))
                for name,parallel_result in zip(request.parallel,parallel_results):
                    chained.append(name); output[name]=parallel_result.output
            for next_skill in request.chain:
                chained.append(next_skill)
                next_req=SkillExecutionRequest(skill=next_skill,goal=result.merged_response,inputs={'previous_output':result.merged_response})
                chained_result=await self.execute(user_id,next_req,ctx); output[next_skill]=chained_result.output
            final=SkillExecutionResult(skill=skill.name,status='completed',output=output,confidence=result.confidence,chained=chained)
            if self.metrics and getattr(self.metrics,'analytics',None) and getattr(self.metrics.analytics,'session_factory',None):
                from sqlalchemy import text
                from uuid import uuid4
                async with self.metrics.analytics.session_factory() as session:
                    await session.execute(text('INSERT INTO skill_executions(id,user_id,skill,status,output,confidence,chained,error) VALUES (:id,:uid,:skill,:status,:output,:confidence,:chained,:error)'),{'id':uuid4(),'uid':user_id,'skill':skill.name,'status':final.status,'output':final.output,'confidence':final.confidence,'chained':final.chained,'error':None}); await session.commit()
            if self.metrics: await self.metrics.record(user_id,'skill_success',1,True,skill.agent_id,{'skill':skill.name,'confidence':result.confidence})
            return final
        except Exception as exc:
            if self.metrics: await self.metrics.record(user_id,'skill_failure',1,False,skill.agent_id,{'skill':skill.name,'error':type(exc).__name__})
            return SkillExecutionResult(skill=skill.name,status='failed',error=str(exc))
