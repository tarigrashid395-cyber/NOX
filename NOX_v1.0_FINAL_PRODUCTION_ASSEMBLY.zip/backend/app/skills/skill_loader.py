from __future__ import annotations
from .skill_models import SkillDefinition

DEFAULT_SKILLS=(
SkillDefinition(name='Research Skill',description='Evidence-backed research using the existing Research Engine.',inputs=['goal'],outputs=['report','sources','evidence'],tool_requirements=['Research Engine'],memory_requirements=['research history','personal memory'],quality_requirements=['source attribution','conflict awareness'],confidence_requirements=.75,agent_id='research'),
SkillDefinition(name='Study Skill',description='Adaptive teaching and learning support.',inputs=['goal','level'],outputs=['explanation','practice'],tool_requirements=['Memory Engine'],memory_requirements=['learning history'],quality_requirements=['clarity','pedagogical structure'],confidence_requirements=.7,agent_id='study'),
SkillDefinition(name='Coding Skill',description='Production-oriented software reasoning, implementation and testing.',inputs=['goal','code'],outputs=['solution','tests','risks'],tool_requirements=['File Intelligence','Memory Engine'],memory_requirements=['project context'],quality_requirements=['correctness','testability','security'],confidence_requirements=.8,agent_id='coding'),
SkillDefinition(name='Writing Skill',description='Professional drafting and revision.',inputs=['goal','style'],outputs=['draft'],tool_requirements=['Memory Engine'],memory_requirements=['preferences'],quality_requirements=['clarity','tone','completeness'],confidence_requirements=.75,agent_id='writing'),
SkillDefinition(name='Analysis Skill',description='Structured comparison, reasoning and synthesis.',inputs=['goal','evidence'],outputs=['analysis','conclusion'],tool_requirements=['Research Engine','Memory Engine'],memory_requirements=['prior analyses'],quality_requirements=['traceability','balanced reasoning'],confidence_requirements=.78,agent_id='analysis'),
SkillDefinition(name='Business Skill',description='Evidence-based commercial and strategic analysis.',inputs=['goal'],outputs=['strategy','risks','recommendations'],tool_requirements=['Research Engine'],memory_requirements=['business context'],quality_requirements=['evidence','risk disclosure'],confidence_requirements=.8,agent_id='business'),
SkillDefinition(name='Project Management Skill',description='Project decomposition, dependencies, milestones and risks.',inputs=['goal','constraints'],outputs=['plan','milestones','risks'],tool_requirements=['Analytics Engine','Memory Engine'],memory_requirements=['project history'],quality_requirements=['feasibility','dependency coverage'],confidence_requirements=.78,agent_id='project'),
SkillDefinition(name='File Intelligence Skill',description='Grounded document inspection and analysis.',inputs=['document_id','goal'],outputs=['findings','summary'],tool_requirements=['File Intelligence'],memory_requirements=['file history'],quality_requirements=['document grounding','citation'],confidence_requirements=.82,agent_id='file'),
SkillDefinition(name='Presentation Skill',description='Structured presentation content and narrative.',inputs=['goal','audience'],outputs=['slides'],tool_requirements=['Creation Engine','Export Engine'],memory_requirements=['preferences'],quality_requirements=['narrative','structure'],confidence_requirements=.76,agent_id='creative'),
SkillDefinition(name='Planning Skill',description='Task decomposition and execution sequencing using the existing Planner.',inputs=['goal'],outputs=['execution_plan'],tool_requirements=['Planner'],memory_requirements=['context'],quality_requirements=['coverage','feasibility'],confidence_requirements=.8,agent_id='project'),
)

def load_default_skills(registry):
    for skill in DEFAULT_SKILLS: registry.register(skill)
    return registry
