from __future__ import annotations
from typing import Any
from pydantic import BaseModel, Field, ConfigDict

class SkillDefinition(BaseModel):
    model_config=ConfigDict(extra='forbid')
    name: str = Field(min_length=1,max_length=120)
    description: str = Field(min_length=1,max_length=2000)
    inputs: list[str] = Field(default_factory=list)
    outputs: list[str] = Field(default_factory=list)
    tool_requirements: list[str] = Field(default_factory=list)
    memory_requirements: list[str] = Field(default_factory=list)
    quality_requirements: list[str] = Field(default_factory=list)
    confidence_requirements: float = Field(default=.65,ge=0,le=1)
    agent_id: str
    template: str = ''

class SkillExecutionRequest(BaseModel):
    skill: str
    goal: str = Field(min_length=1,max_length=50000)
    inputs: dict[str,Any] = Field(default_factory=dict)
    conversation_id: str | None = None
    chain: list[str] = Field(default_factory=list)
    parallel: list[str] = Field(default_factory=list)

class SkillExecutionResult(BaseModel):
    skill: str
    status: str
    output: dict[str,Any] = Field(default_factory=dict)
    confidence: float = Field(default=0,ge=0,le=1)
    chained: list[str] = Field(default_factory=list)
    error: str | None = None
