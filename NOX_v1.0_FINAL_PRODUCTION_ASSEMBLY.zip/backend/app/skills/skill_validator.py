from __future__ import annotations
from .skill_models import SkillDefinition, SkillExecutionRequest
class SkillValidator:
    def validate_definition(self,skill:SkillDefinition):
        if not skill.tool_requirements: raise ValueError(f'Skill {skill.name} must declare tool requirements')
        if not skill.outputs: raise ValueError(f'Skill {skill.name} must declare outputs')
        if skill.confidence_requirements<0 or skill.confidence_requirements>1: raise ValueError('Invalid confidence requirement')
        return True
    def validate_request(self,skill:SkillDefinition,request:SkillExecutionRequest):
        missing=[x for x in skill.inputs if x!='goal' and x not in request.inputs]
        if missing: raise ValueError(f'Missing skill inputs: {missing}')
        return True
