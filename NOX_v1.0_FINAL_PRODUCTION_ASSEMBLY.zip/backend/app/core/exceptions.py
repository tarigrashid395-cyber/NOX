class NoxError(Exception):
    code = "nox_error"
    status_code = 500
class ConfigurationError(NoxError): code="configuration_error"
class AuthorizationError(NoxError): code="authorization_error"; status_code=403
class ValidationError(NoxError): code="validation_error"; status_code=422
class AgentExecutionError(NoxError): code="agent_execution_error"
