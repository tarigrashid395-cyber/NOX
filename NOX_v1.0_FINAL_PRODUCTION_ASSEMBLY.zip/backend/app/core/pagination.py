from pydantic import BaseModel, Field
class Pagination(BaseModel):
    limit:int=Field(default=50, ge=1, le=100)
    cursor:str|None=None
