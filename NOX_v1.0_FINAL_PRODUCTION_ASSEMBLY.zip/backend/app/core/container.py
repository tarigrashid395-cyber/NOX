from dataclasses import dataclass
from backend.app.config import Settings
from backend.app.db.session import Database
from backend.app.orchestration.router import IntentRouter
from backend.app.orchestration.context_builder import ContextBuilder
from backend.app.orchestration.planner import TaskPlanner
from backend.app.orchestration.execution_manager import ExecutionManager
from backend.app.orchestration.response_synthesizer import ResponseSynthesizer
from backend.app.orchestration.validation import ValidationLayer
from backend.app.orchestration.supervisor import Supervisor
from backend.app.agents.registry import AgentRegistry
from backend.app.memory.store import PostgresMemoryRepository
from backend.app.memory.retriever import MemoryRetriever
from backend.app.memory.updater import MemoryLifecycle
from backend.app.memory.workflows import MemoryWorkflow
from backend.app.providers.embeddings.default import DeterministicEmbeddingProvider
from backend.app.providers.vector.qdrant import QdrantVectorStore
from backend.app.providers.vector.factory import build_vector_provider
from backend.app.providers.search.web import WebSearchProvider
from backend.app.providers.search.local import MemorySearchProvider,KnowledgeSearchProvider
from backend.app.research.search import SearchEngine
from backend.app.research.service import ResearchOrchestrator
from backend.app.research.evidence import EvidenceEngine
from backend.app.research.citations import CitationEngine
from backend.app.research.conflicts import ConflictDetectionEngine
from backend.app.research.report import ReportBuilder
from backend.app.research.store import PostgresResearchRepository,InMemoryResearchRepository
from backend.app.research.autonomous.research_orchestrator import AutonomousResearchOrchestrator
from backend.app.files.repository import PostgresFileRepository,InMemoryFileRepository
from backend.app.files.service import FileService
from backend.app.files.pipeline import FileOrchestrator
from backend.app.files.storage import InMemoryFileStorage
from backend.app.providers.storage.s3 import S3StorageProvider
from backend.app.providers.storage.supabase import SupabaseStorageProvider
from backend.app.visual.orchestrator import VisualOrchestrator
from backend.app.visual.repository import PostgresVisualRepository, InMemoryVisualRepository
from backend.app.motion.orchestrator import MotionOrchestrator
from backend.app.motion.repository import PostgresMotionRepository, InMemoryMotionRepository
from backend.app.creation.service import CreationOrchestrator
from backend.app.creation.planner import CreationPlanner
from backend.app.creation.validator import CreationValidator
from backend.app.creation.templates import TemplateRegistry
from backend.app.creation.templates_builtin import register_builtin_templates
from backend.app.creation.assets import AssetRegistry
from backend.app.creation.repository import PostgresCreationRepository, InMemoryCreationRepository
from backend.app.export.service import ExportOrchestrator
from backend.app.export.planner import ExportPlanner
from backend.app.export.renderer import ExportRenderer
from backend.app.export.validator import ExportValidator
from backend.app.export.registry import ExportRegistry, register_builtin_export_templates
from backend.app.export.repository import PostgresExportRepository, InMemoryExportRepository
from backend.app.intelligence.coordinator import IntelligenceCoordinator
from backend.app.graph.engine import KnowledgeGraphEngine
from backend.app.graph.repository import PostgresGraphRepository, InMemoryGraphRepository
from backend.app.evaluation.engine import BenchmarkRunner
from backend.app.evaluation.repository import InMemoryEvaluationRepository, PostgresEvaluationRepository
from backend.app.analytics.engine import AnalyticsEngine
from backend.app.adaptive.engine import AdaptiveIntelligence
from backend.app.evaluation.schemas import AnalyticsEvent
from backend.app.providers.llm.production import OpenAIHTTPProvider, AnthropicHTTPProvider, LLMRouter
from backend.app.agents.planner.planner_service import PlannerService
from backend.app.agents.reviewer.reviewer_service import ReviewerService
from backend.app.agents.workforce.workforce import AgentWorkforce
from backend.app.skills.skill_registry import SkillRegistry
from backend.app.skills.skill_loader import load_default_skills
from backend.app.skills.skill_executor import SkillExecutor
from backend.app.tools.tool_registry import ToolRegistry
from backend.app.tools.tool_router import ToolRouter
from backend.app.tools.tool_validator import ToolValidator
from backend.app.tools.tool_permissions import ToolPermissionService
from backend.app.tools.tool_executor import ToolExecutor
from backend.app.tools.tool_analytics import ToolAnalytics
from backend.app.tools.native import register_native_tools
from backend.app.execution.execution_service import ExecutionService
from backend.app.execution.execution_engine import ExecutionEngine
from backend.app.execution.execution_scheduler import ExecutionScheduler
from backend.app.artifacts.artifact_generator import ArtifactGenerator
from backend.app.artifacts.artifact_exporter import ArtifactExporter
from backend.app.artifacts.artifact_storage import ProviderArtifactStorage, InMemoryArtifactStorage
from backend.app.workspaces.workspace_repository import WorkspaceRepository
from backend.app.workspaces.workspace_service import WorkspaceService
from backend.app.missions.mission_manager import MissionManager
from backend.app.missions.mission_executor import MissionExecutor

@dataclass(slots=True)
class Container:
    settings: Settings
    database: Database
    redis: object
    storage: object
    registry: AgentRegistry
    supervisor: Supervisor
    memory: MemoryWorkflow
    research: ResearchOrchestrator
    deep_research: AutonomousResearchOrchestrator
    files: FileOrchestrator
    visual: VisualOrchestrator
    motion: MotionOrchestrator
    creation: CreationOrchestrator
    export: ExportOrchestrator
    intelligence: IntelligenceCoordinator
    graph: KnowledgeGraphEngine
    evaluation: BenchmarkRunner
    analytics: AnalyticsEngine
    adaptive: AdaptiveIntelligence
    planner_service: PlannerService
    reviewer_service: ReviewerService
    workforce: AgentWorkforce
    skills: SkillExecutor
    tool_registry: ToolRegistry
    tools: ToolExecutor
    tool_router: ToolRouter
    execution: ExecutionService
    execution_scheduler: ExecutionScheduler
    artifacts: ArtifactGenerator
    workspaces: WorkspaceService
    missions: MissionManager
    llm: LLMRouter | None
    def analytics_event(self,event,category="usage",value=1.0,success=True,latency_ms=0,agent=None,tool=None):
        return AnalyticsEvent(event=event,category=category,value=value,success=success,latency_ms=latency_ms,agent=agent,tool=tool)

def build_container(settings,database,redis,storage)->Container:
    registry=AgentRegistry(); router=IntentRouter(registry); context=ContextBuilder(); planner=TaskPlanner(registry); execution=ExecutionManager(registry); validation=ValidationLayer(); synthesizer=ResponseSynthesizer(); supervisor=Supervisor(router,context,planner,execution,validation,synthesizer)
    database.connect(); repository=PostgresMemoryRepository(database.session_factory); embedder=DeterministicEmbeddingProvider(settings.embedding_dimension); vector=QdrantVectorStore(build_vector_provider(settings)); lifecycle=MemoryLifecycle(repository,vector,embedder); memory=MemoryWorkflow(lifecycle,MemoryRetriever(repository,vector,embedder)); context.memory=memory; supervisor.memory=memory
    providers={"web":WebSearchProvider(timeout=15.0),"memory":MemorySearchProvider(memory),"knowledge":KnowledgeSearchProvider(memory)}; research_repo=PostgresResearchRepository(database.session_factory) if database.session_factory is not None else InMemoryResearchRepository(); research=ResearchOrchestrator(SearchEngine(providers),EvidenceEngine(),CitationEngine(),ConflictDetectionEngine(),ReportBuilder(),research_repo,memory); deep_research=AutonomousResearchOrchestrator(SearchEngine(providers),EvidenceEngine(),CitationEngine(),ConflictDetectionEngine(),ReportBuilder(),research_repo,memory)
    file_repo=PostgresFileRepository(database.session_factory) if database.session_factory is not None else InMemoryFileRepository()
    if settings.storage_provider.lower() == "supabase":
        file_storage=SupabaseStorageProvider(settings.supabase_url,settings.supabase_service_role_key,settings.supabase_storage_bucket)
    else:
        file_storage=S3StorageProvider(settings.s3_endpoint,settings.s3_access_key,settings.s3_secret_key,settings.s3_bucket)
    files=FileOrchestrator(FileService(file_repo,file_storage,vector,embedder,memory,research,settings.max_upload_bytes))
    visual_repo=PostgresVisualRepository(database.session_factory) if database.session_factory is not None else InMemoryVisualRepository()
    visual=VisualOrchestrator(repository=visual_repo)
    motion_repo=PostgresMotionRepository(database.session_factory) if database.session_factory is not None else InMemoryMotionRepository()
    motion=MotionOrchestrator(repository=motion_repo,visual_repository=visual_repo)
    creation_repo=PostgresCreationRepository(database.session_factory) if database.session_factory is not None else InMemoryCreationRepository()
    templates=TemplateRegistry(); register_builtin_templates(templates)
    creation=CreationOrchestrator(CreationPlanner(templates),CreationValidator(),creation_repo,memory=memory,research=research,files=files,visual=visual,motion=motion,asset_registry=AssetRegistry())
    export_repo=PostgresExportRepository(database.session_factory) if database.session_factory is not None else InMemoryExportRepository()
    export_registry=ExportRegistry(); register_builtin_export_templates(export_registry)
    export=ExportOrchestrator(ExportPlanner(),ExportRenderer(),ExportValidator(),export_repo,export_registry,memory=memory,research=research,files=files,visual=visual,motion=motion,creation=creation)
    intelligence=IntelligenceCoordinator(registry)
    planner_service=PlannerService(database.session_factory)
    reviewer_service=ReviewerService(database.session_factory)
    supervisor.planner14=planner_service
    supervisor.reviewer14=reviewer_service
    supervisor.analytics=None
    supervisor.intelligence=intelligence
    graph_repo=PostgresGraphRepository(database.session_factory) if database.session_factory is not None else InMemoryGraphRepository()
    graph=KnowledgeGraphEngine(graph_repo,{'memory':memory,'research':research,'files':files,'visual':visual,'agents':[]})
    supervisor.graph=graph
    eval_repo=PostgresEvaluationRepository(database.session_factory) if database.session_factory is not None else InMemoryEvaluationRepository()
    evaluation=BenchmarkRunner(eval_repo)
    analytics=AnalyticsEngine(database.session_factory,redis=redis)
    deep_research.analytics=analytics
    supervisor.analytics=analytics
    adaptive=AdaptiveIntelligence()
    tool_registry=ToolRegistry()
    tool_storage=ProviderArtifactStorage(files.storage) if hasattr(files.storage, 'put') else InMemoryArtifactStorage()
    artifacts=ArtifactGenerator(tool_storage,ArtifactExporter(),database.session_factory)
    tools=ToolExecutor(tool_registry,ToolValidator(),ToolPermissionService(),ToolAnalytics(analytics))
    tool_router=ToolRouter(tool_registry)
    execution=ExecutionService(database.session_factory,analytics)
    execution_scheduler=ExecutionScheduler(execution,redis=redis,queue_enabled=settings.queue_enabled,production=settings.app_env.lower() in {'production','prod'})
    workspaces=WorkspaceService(WorkspaceRepository(database.session_factory),task_service=execution,artifact_generator=artifacts,research=research,files=files)
    missions=MissionManager(database.session_factory,analytics)
    providers=[]
    if settings.openai_api_key: providers.append(OpenAIHTTPProvider(settings.openai_api_key,settings.openai_model,settings.llm_timeout_seconds,settings.openai_base_url))
    if settings.anthropic_api_key: providers.append(AnthropicHTTPProvider(settings.anthropic_api_key,settings.anthropic_model,settings.llm_timeout_seconds,settings.anthropic_base_url))
    llm=LLMRouter(providers) if providers else None
    workforce=AgentWorkforce(registry,database.session_factory,memory,llm,analytics)
    skill_registry=load_default_skills(SkillRegistry())
    skills=SkillExecutor(skill_registry,workforce.router,workforce.metrics,planner_service)
    supervisor.workforce=workforce
    execution.engine=ExecutionEngine(planner_service,workforce,reviewer_service,artifacts,execution)
    execution_scheduler.service=execution
    missions.executor=MissionExecutor(missions,workforce,reviewer_service,planner_service,artifacts)
    register_native_tools(tool_registry, type('ToolContainer', (), {'memory':memory,'research':research,'files':files,'workforce':workforce,'export':export,'visual':visual,'analytics':analytics,'graph':graph})())
    return Container(settings=settings,database=database,redis=redis,storage=storage,registry=registry,supervisor=supervisor,memory=memory,research=research,deep_research=deep_research,files=files,visual=visual,motion=motion,creation=creation,export=export,intelligence=intelligence,graph=graph,evaluation=evaluation,analytics=analytics,adaptive=adaptive,planner_service=planner_service,reviewer_service=reviewer_service,workforce=workforce,skills=skills,tool_registry=tool_registry,tools=tools,tool_router=tool_router,execution=execution,execution_scheduler=execution_scheduler,artifacts=artifacts,workspaces=workspaces,missions=missions,llm=llm)
