from datetime import datetime
from uuid import UUID
from pydantic import BaseModel, Field
class EventEnvelope(BaseModel):
    id: str
    type: str
    trace_id: str
    conversation_id: UUID | None = None
    message_id: UUID | None = None
    payload: dict = Field(default_factory=dict)
    created_at: datetime
