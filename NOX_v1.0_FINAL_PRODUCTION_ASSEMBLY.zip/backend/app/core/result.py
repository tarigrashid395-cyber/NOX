from dataclasses import dataclass, field
from typing import Generic, TypeVar
T=TypeVar('T')
@dataclass(slots=True)
class Result(Generic[T]):
    value: T | None = None
    error: Exception | None = None
    warnings: list[str] = field(default_factory=list)
    @property
    def ok(self): return self.error is None
