from enum import StrEnum
class AgentType(StrEnum):
    STUDY='study'; RESEARCH='research'; MEMORY='memory'; FILE='file'; VISUAL='visual'; MOTION='motion'; CREATION='creation'; PLANNING='planning'
class TaskStatus(StrEnum): QUEUED='queued'; RUNNING='running'; COMPLETED='completed'; PARTIAL='partial'; FAILED='failed'
