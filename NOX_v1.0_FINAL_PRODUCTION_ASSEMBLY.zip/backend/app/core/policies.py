from dataclasses import dataclass
@dataclass(frozen=True)
class ExecutionPolicy:
    max_steps:int=12
    max_parallel:int=4
    timeout_seconds:float=60.0
    allow_external_tools:bool=True
