"""Deterministic prompt-injection screening for untrusted text boundaries."""
from __future__ import annotations
import re
from dataclasses import dataclass

_PATTERNS = (
    re.compile(r"\b(ignore|disregard|forget)\b.{0,80}\b(previous|prior|system|developer|instructions?)\b", re.I | re.S),
    re.compile(r"\b(system|developer)\s*(prompt|message|instruction)\b", re.I),
    re.compile(r"\b(reveal|print|show|expose)\b.{0,60}\b(secret|token|password|api[_ -]?key)\b", re.I | re.S),
    re.compile(r"\b(override|bypass)\b.{0,60}\b(safety|policy|security|permission)\b", re.I | re.S),
)

@dataclass(frozen=True, slots=True)
class InjectionAssessment:
    suspicious: bool
    score: float
    matches: tuple[str, ...]

class PromptInjectionDetector:
    def assess(self, text: str) -> InjectionAssessment:
        matches = tuple(pattern.pattern for pattern in _PATTERNS if pattern.search(text or ""))
        score = min(1.0, 0.35 * len(matches))
        return InjectionAssessment(bool(matches), score, matches)

    def is_suspicious(self, text: str) -> bool:
        return self.assess(text).suspicious

def screen_untrusted_text(text: str) -> InjectionAssessment:
    return PromptInjectionDetector().assess(text)
