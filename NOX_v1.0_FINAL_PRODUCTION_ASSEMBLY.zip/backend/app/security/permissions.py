from backend.app.security.auth import CurrentUser

def require_roles(user:CurrentUser,*roles:str)->CurrentUser:
    if user.role not in roles: raise PermissionError('Insufficient permissions')
    return user
