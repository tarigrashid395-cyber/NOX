from backend.app.security.auth import PasswordHasher
password_hasher=PasswordHasher()
def hash_password(password:str)->str:return password_hasher.hash(password)
def verify_password(password:str,encoded:str)->bool:return password_hasher.verify(password,encoded)
