from backend.app.security.auth import AuthService
class AuthRateLimiter:
    def __init__(self,service:AuthService): self.service=service
    def check(self,key:str,limit:int=10,window:int=60)->None:self.service._rate_check(key,limit,window)
