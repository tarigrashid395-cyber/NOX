from __future__ import annotations
import base64, hashlib, hmac, json, secrets, time
from dataclasses import dataclass
from datetime import datetime, timezone
from uuid import UUID, uuid4
from typing import Any

@dataclass(frozen=True, slots=True)
class CurrentUser:
    user_id: UUID
    email: str = ""
    role: str = "user"

class PasswordHasher:
    def hash(self, password: str) -> str:
        if len(password) < 8: raise ValueError("Password must contain at least 8 characters")
        salt=secrets.token_bytes(16)
        digest=hashlib.scrypt(password.encode(),salt=salt,n=2**14,r=8,p=1)
        return f"scrypt$16384$8$1${base64.urlsafe_b64encode(salt).decode()}${base64.urlsafe_b64encode(digest).decode()}"
    def verify(self,password:str,encoded:str)->bool:
        try:
            _,n,r,p,salt,digest=encoded.split("$")
            actual=hashlib.scrypt(password.encode(),salt=base64.urlsafe_b64decode(salt),n=int(n),r=int(r),p=int(p))
            return hmac.compare_digest(actual,base64.urlsafe_b64decode(digest))
        except (ValueError,TypeError): return False

class JWTManager:
    def __init__(self,secret:str,access_ttl:int=900,refresh_ttl:int=2_592_000): self.secret=secret.encode(); self.access_ttl=access_ttl; self.refresh_ttl=refresh_ttl
    @staticmethod
    def _b64(data:bytes)->str: return base64.urlsafe_b64encode(data).rstrip(b"=").decode()
    @staticmethod
    def _unb64(value:str)->bytes: return base64.urlsafe_b64decode(value+"="*(-len(value)%4))
    def issue(self,user_id:UUID,role:str,kind:str="access",ttl:int|None=None)->str:
        now=int(time.time()); ttl=ttl or (self.access_ttl if kind=="access" else self.refresh_ttl)
        head=self._b64(json.dumps({"alg":"HS256","typ":"JWT"},separators=(",",":"),sort_keys=True).encode())
        body=self._b64(json.dumps({"sub":str(user_id),"role":role,"typ":kind,"iat":now,"exp":now+ttl},separators=(",",":"),sort_keys=True).encode())
        sig=self._b64(hmac.new(self.secret,f"{head}.{body}".encode(),hashlib.sha256).digest())
        return f"{head}.{body}.{sig}"
    def decode(self,token:str,expected_kind:str|None=None)->dict[str,Any]:
        try: head,body,sig=token.split("."); expected=hmac.new(self.secret,f"{head}.{body}".encode(),hashlib.sha256).digest()
        except ValueError: raise ValueError("Invalid token")
        if not hmac.compare_digest(self._unb64(sig),expected): raise ValueError("Invalid token")
        payload=json.loads(self._unb64(body));
        if int(payload.get("exp",0))<int(time.time()): raise ValueError("Token expired")
        if expected_kind and payload.get("typ")!=expected_kind: raise ValueError("Invalid token type")
        return payload

class AuthRepository:
    def __init__(self,session_factory=None):
        self.session_factory=session_factory; self.users={}; self.sessions={}; self.refresh_tokens={}; self.preferences={}; self.usage={}; self.audit=[]
        self._db_ready=False
    async def ensure_schema(self):
        if not self.session_factory: return
        from sqlalchemy import text
        try:
            async with self.session_factory() as s:
                for sql in [
                    "CREATE TABLE IF NOT EXISTS users (id UUID PRIMARY KEY,email TEXT UNIQUE NOT NULL,password_hash TEXT NOT NULL,role TEXT NOT NULL DEFAULT 'user',is_active BOOLEAN NOT NULL DEFAULT TRUE,created_at TIMESTAMPTZ NOT NULL,updated_at TIMESTAMPTZ NOT NULL)",
                    "CREATE TABLE IF NOT EXISTS profiles (user_id UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,display_name TEXT NOT NULL DEFAULT '',avatar_url TEXT,locale TEXT NOT NULL DEFAULT 'en',bio TEXT NOT NULL DEFAULT '')",
                    "CREATE TABLE IF NOT EXISTS sessions (id UUID PRIMARY KEY,user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,device_name TEXT NOT NULL DEFAULT '',user_agent TEXT NOT NULL DEFAULT '',ip_address TEXT NOT NULL DEFAULT '',created_at TIMESTAMPTZ NOT NULL,last_seen_at TIMESTAMPTZ NOT NULL,revoked_at TIMESTAMPTZ)",
                    "CREATE TABLE IF NOT EXISTS refresh_tokens (id UUID PRIMARY KEY,user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,token_hash TEXT UNIQUE NOT NULL,expires_at TIMESTAMPTZ NOT NULL,created_at TIMESTAMPTZ NOT NULL,revoked_at TIMESTAMPTZ)",
                    "CREATE TABLE IF NOT EXISTS user_preferences (user_id UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,data JSONB NOT NULL DEFAULT '{}'::jsonb)",
                    "CREATE TABLE IF NOT EXISTS user_usage (user_id UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,total_requests BIGINT NOT NULL DEFAULT 0,total_tokens BIGINT NOT NULL DEFAULT 0,updated_at TIMESTAMPTZ NOT NULL)",
                    "CREATE TABLE IF NOT EXISTS subscriptions (user_id UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,plan TEXT NOT NULL DEFAULT 'free',status TEXT NOT NULL DEFAULT 'active',updated_at TIMESTAMPTZ NOT NULL)",
                    "CREATE TABLE IF NOT EXISTS audit_logs (id UUID PRIMARY KEY,user_id UUID,action TEXT NOT NULL,metadata JSONB NOT NULL DEFAULT '{}'::jsonb,created_at TIMESTAMPTZ NOT NULL)"]:
                    await s.execute(text(sql))
                await s.commit(); self._db_ready=True
        except Exception: self._db_ready=False
    async def create_user(self,email,password_hash,display_name="",role="user"):
        email=email.lower().strip(); now=datetime.now(timezone.utc); uid=uuid4()
        if self._db_ready:
            from sqlalchemy import text
            try:
                async with self.session_factory() as s:
                    row=await s.execute(text("INSERT INTO users(id,email,password_hash,role,created_at,updated_at) VALUES (:id,:email,:ph,:role,:now,:now) RETURNING id,email,password_hash,role,is_active,created_at,updated_at"),{"id":uid,"email":email,"ph":password_hash,"role":role,"now":now})
                    u=dict(row.mappings().one()); await s.execute(text("INSERT INTO profiles(user_id,display_name) VALUES (:id,:name)"),{"id":uid,"name":display_name}); await s.execute(text("INSERT INTO user_preferences(user_id) VALUES (:id)"),{"id":uid}); await s.execute(text("INSERT INTO subscriptions(user_id) VALUES (:id)"),{"id":uid}); await s.execute(text("INSERT INTO user_usage(user_id,updated_at) VALUES (:id,:now)"),{"id":uid,"now":now}); await s.commit(); return u
            except Exception: self._db_ready=False
        if any(u["email"]==email for u in self.users.values()): raise ValueError("Email already registered")
        u={"id":uid,"email":email,"password_hash":password_hash,"role":role,"is_active":True,"created_at":now,"updated_at":now}; self.users[uid]=u; self.preferences[uid]={}; self.usage[uid]={"total_requests":0,"total_tokens":0}; return u
    async def find_user(self,email):
        email=email.lower().strip()
        if self._db_ready:
            from sqlalchemy import text
            try:
                async with self.session_factory() as s:
                    r=await s.execute(text("SELECT id,email,password_hash,role,is_active,created_at,updated_at FROM users WHERE email=:email"),{"email":email}); return dict(r.mappings().one_or_none()) if r else None
            except Exception: self._db_ready=False
        return next((dict(u) for u in self.users.values() if u["email"]==email),None)
    async def get_user(self,user_id):
        if self._db_ready:
            from sqlalchemy import text
            try:
                async with self.session_factory() as s:
                    r=await s.execute(text("SELECT id,email,password_hash,role,is_active,created_at,updated_at FROM users WHERE id=:id"),{"id":user_id}); return dict(r.mappings().one_or_none()) if r else None
            except Exception: self._db_ready=False
        return dict(self.users[user_id]) if user_id in self.users else None
    async def set_password(self,user_id,password_hash):
        if self._db_ready:
            from sqlalchemy import text
            try:
                async with self.session_factory() as s: await s.execute(text("UPDATE users SET password_hash=:p,updated_at=:n WHERE id=:id"),{"p":password_hash,"n":datetime.now(timezone.utc),"id":user_id}); await s.commit(); return
            except Exception:self._db_ready=False
        if user_id in self.users:self.users[user_id]["password_hash"]=password_hash
    async def save_refresh(self,user_id,raw,expires):
        item={"id":uuid4(),"user_id":user_id,"token_hash":hashlib.sha256(raw.encode()).hexdigest(),"expires_at":expires,"created_at":datetime.now(timezone.utc),"revoked_at":None}; self.refresh_tokens[item["token_hash"]]=item
        if self._db_ready:
            from sqlalchemy import text
            try:
                async with self.session_factory() as s: await s.execute(text("INSERT INTO refresh_tokens(id,user_id,token_hash,expires_at,created_at) VALUES (:id,:uid,:h,:exp,:now)"),item|{"uid":user_id,"h":item["token_hash"],"exp":expires,"now":item["created_at"]}); await s.commit()
            except Exception:self._db_ready=False
    async def revoke_refresh(self,raw):
        h=hashlib.sha256(raw.encode()).hexdigest(); item=self.refresh_tokens.get(h)
        if item:item["revoked_at"]=datetime.now(timezone.utc)
        if self._db_ready:
            from sqlalchemy import text
            try:
                async with self.session_factory() as s: await s.execute(text("UPDATE refresh_tokens SET revoked_at=:n WHERE token_hash=:h"),{"n":datetime.now(timezone.utc),"h":h}); await s.commit()
            except Exception:self._db_ready=False
    async def refresh_valid(self,raw):
        h=hashlib.sha256(raw.encode()).hexdigest(); item=self.refresh_tokens.get(h)
        if item:return item if not item["revoked_at"] and item["expires_at"]>datetime.now(timezone.utc) else None
        if self._db_ready:
            from sqlalchemy import text
            try:
                async with self.session_factory() as s:
                    r=await s.execute(text("SELECT id,user_id,token_hash,expires_at,created_at,revoked_at FROM refresh_tokens WHERE token_hash=:h"),{"h":h}); x=r.mappings().one_or_none(); return dict(x) if x and not x["revoked_at"] and x["expires_at"]>datetime.now(timezone.utc) else None
            except Exception:self._db_ready=False
        return None
    async def profile(self,user_id):
        if self._db_ready:
            from sqlalchemy import text
            try:
                async with self.session_factory() as s:
                    r=await s.execute(text("SELECT display_name,avatar_url,locale,bio FROM profiles WHERE user_id=:id"),{"id":user_id}); p=r.mappings().one_or_none(); return dict(p) if p else {"display_name":"","avatar_url":None,"locale":"en","bio":""}
            except Exception:self._db_ready=False
        u=self.users.get(user_id,{}); return {"display_name":u.get("display_name",u.get("email","")),"avatar_url":None,"locale":"en","bio":""}
    async def update_profile(self,user_id,data):
        p=await self.profile(user_id); p.update(data)
        if self._db_ready:
            from sqlalchemy import text
            try:
                async with self.session_factory() as s: await s.execute(text("UPDATE profiles SET display_name=:n,avatar_url=:a,locale=:l,bio=:b WHERE user_id=:id"),{"n":p.get("display_name",""),"a":p.get("avatar_url"),"l":p.get("locale","en"),"b":p.get("bio",""),"id":user_id}); await s.commit(); return p
            except Exception:self._db_ready=False
        if user_id in self.users:self.users[user_id]["display_name"]=p.get("display_name","")
        return p
    async def preferences(self,user_id): return dict(self.preferences.get(user_id,{}))
    async def save_preferences(self,user_id,data): self.preferences[user_id]=dict(data); return self.preferences[user_id]
    async def audit_event(self,user_id,action,metadata=None): self.audit.append({"id":uuid4(),"user_id":user_id,"action":action,"metadata":metadata or {},"created_at":datetime.now(timezone.utc)})
    async def delete_user(self,user_id):
        if self._db_ready:
            from sqlalchemy import text
            try:
                async with self.session_factory() as s:
                    await s.execute(text("DELETE FROM users WHERE id=:id"),{"id":user_id}); await s.commit(); return True
            except Exception:self._db_ready=False
        return bool(self.users.pop(user_id,None))
    async def account_export(self,user_id):
        u=await self.get_user(user_id); return {"user":u,"profile":await self.profile(user_id),"preferences":await self.preferences(user_id),"usage":self.usage.get(user_id,{"total_requests":0,"total_tokens":0}),"audit":[x for x in self.audit if x["user_id"]==user_id]}

class AuthService:
    def __init__(self,repo,settings,redis=None): self.repo=repo; self.hasher=PasswordHasher(); self.jwt=JWTManager(settings.app_secret_key); self.rate={}; self.redis=redis
    def _rate_check(self,key,limit=10,window=60):
        now=time.time(); bucket=self.rate.setdefault(key,[]); bucket[:]=[x for x in bucket if now-x<window]
        if len(bucket)>=limit: raise PermissionError("Too many authentication attempts")
        bucket.append(now)
    async def _rate_check_async(self,key,limit=10,window=60):
        if self.redis is not None:
            try:
                if not await self.redis.rate_limit(key, limit, window):
                    raise PermissionError("Too many authentication attempts")
                return
            except PermissionError:
                raise
            except Exception:
                pass
        self._rate_check(key,limit,window)
    async def register(self,email,password,display_name=""):
        await self._rate_check_async(f"register:{email}"); u=await self.repo.create_user(email,self.hasher.hash(password),display_name); return await self._tokens(u)
    async def login(self,email,password):
        await self._rate_check_async(f"login:{email}"); u=await self.repo.find_user(email)
        if not u or not u["is_active"] or not self.hasher.verify(password,u["password_hash"]): raise PermissionError("Invalid email or password")
        await self.repo.audit_event(u["id"],"login"); return await self._tokens(u)
    async def _tokens(self,u):
        access=self.jwt.issue(u["id"],u["role"],"access"); refresh=self.jwt.issue(u["id"],u["role"],"refresh"); await self.repo.save_refresh(u["id"],refresh,datetime.fromtimestamp(json.loads(self.jwt._unb64(refresh.split('.')[1]))["exp"],timezone.utc)); return {"access_token":access,"refresh_token":refresh,"token_type":"bearer","expires_in":self.jwt.access_ttl,"user":{"id":str(u["id"]),"email":u["email"],"role":u["role"]}}
    async def refresh(self,refresh):
        item=await self.repo.refresh_valid(refresh)
        if not item: raise PermissionError("Invalid refresh token")
        u=await self.repo.get_user(item["user_id"]); await self.repo.revoke_refresh(refresh); return await self._tokens(u)
    async def current(self,token):
        p=self.jwt.decode(token,"access"); u=await self.repo.get_user(UUID(p["sub"]))
        if not u or not u["is_active"]: raise PermissionError("User is inactive")
        return CurrentUser(u["id"],u["email"],u["role"])
