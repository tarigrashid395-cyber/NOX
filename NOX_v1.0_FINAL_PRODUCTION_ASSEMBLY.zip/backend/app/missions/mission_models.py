from __future__ import annotations
from datetime import datetime, timezone
from enum import StrEnum
from typing import Any
from uuid import UUID, uuid4
from pydantic import BaseModel, ConfigDict, Field

class MissionStatus(StrEnum):
    QUEUED='queued'; RUNNING='running'; REVIEWING='reviewing'; COMPLETED='completed'; FAILED='failed'; CANCELLED='cancelled'

class MissionStartRequest(BaseModel):
    model_config=ConfigDict(extra='forbid')
    goal: str = Field(min_length=1,max_length=50000)
    workspace_id: UUID | None = None
    conversation_id: UUID | None = None
    agents: list[str] = Field(default_factory=list)
    parallel: bool = True
    artifact_type: str | None = None
    artifact_title: str | None = None
    metadata: dict[str,Any] = Field(default_factory=dict)

class Mission(BaseModel):
    id: UUID = Field(default_factory=uuid4)
    user_id: UUID
    goal: str
    status: MissionStatus = MissionStatus.QUEUED
    selected_agents: list[str] = Field(default_factory=list)
    progress: float = 0
    workspace_id: UUID | None = None
    conversation_id: UUID | None = None
    artifact_ids: list[UUID] = Field(default_factory=list)
    result: str = ''
    confidence: float = 0
    metadata: dict[str,Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    completed_at: datetime | None = None
    error: str | None = None
