from __future__ import annotations
import asyncio
from uuid import UUID
from backend.app.evaluation.schemas import AnalyticsEvent
from .mission_models import Mission, MissionStartRequest, MissionStatus

class MissionManager:
    def __init__(self,session_factory=None,analytics=None): self.session_factory=session_factory; self.analytics=analytics; self.items={}; self.executor=None; self.jobs={}
    async def ensure_schema(self):
        if not self.session_factory:return
        from sqlalchemy import text
        async with self.session_factory() as s:
            await s.execute(text('CREATE TABLE IF NOT EXISTS missions (id UUID PRIMARY KEY,user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,workspace_id UUID NULL,conversation_id UUID NULL,goal TEXT NOT NULL,status VARCHAR(20) NOT NULL,selected_agents JSONB NOT NULL DEFAULT \'[]\'::jsonb,progress DOUBLE PRECISION NOT NULL DEFAULT 0,result TEXT NOT NULL DEFAULT \'\',confidence DOUBLE PRECISION NOT NULL DEFAULT 0,artifact_ids JSONB NOT NULL DEFAULT \'[]\'::jsonb,metadata JSONB NOT NULL DEFAULT \'{}\'::jsonb,error TEXT,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),completed_at TIMESTAMPTZ)')); await s.execute(text('CREATE INDEX IF NOT EXISTS ix_missions_user_status ON missions(user_id,status)')); await s.commit()
    async def start(self,user_id,body:MissionStartRequest):
        metadata={**body.metadata,'agents':body.agents,'parallel':body.parallel};
        if body.artifact_type: metadata['artifact_type']=body.artifact_type
        if body.artifact_title: metadata['artifact_title']=body.artifact_title
        mission=Mission(user_id=user_id,goal=body.goal,workspace_id=body.workspace_id,conversation_id=body.conversation_id,metadata=metadata); self.items[mission.id]=mission; await self.save(mission); await self.analytics_record(mission,'mission_started'); self.jobs[mission.id]=asyncio.create_task(self._run(mission)); self.jobs[mission.id].add_done_callback(lambda _: self.jobs.pop(mission.id,None)); return mission

    async def _run(self,mission):
        try:
            return await self.executor.execute(mission)
        except asyncio.CancelledError:
            mission.status=MissionStatus.CANCELLED; mission.completed_at=__import__('datetime').datetime.now(__import__('datetime').timezone.utc); await self.save(mission); raise
        except Exception as exc:
            mission.status=MissionStatus.FAILED; mission.error=str(exc); mission.completed_at=__import__('datetime').datetime.now(__import__('datetime').timezone.utc); await self.save(mission); await self.analytics_record(mission,'mission_failed',success=False,metadata={'error':type(exc).__name__}); return mission
    async def save(self,m):
        self.items[m.id]=m
        if self.session_factory:
            from sqlalchemy import text
            async with self.session_factory() as s: await s.execute(text('INSERT INTO missions(id,user_id,workspace_id,conversation_id,goal,status,selected_agents,progress,result,confidence,artifact_ids,metadata,error,created_at,completed_at) VALUES (:id,:user_id,:workspace_id,:conversation_id,:goal,:status,:agents,:progress,:result,:confidence,:artifacts,:metadata,:error,:created_at,:completed_at) ON CONFLICT(id) DO UPDATE SET status=EXCLUDED.status,selected_agents=EXCLUDED.selected_agents,progress=EXCLUDED.progress,result=EXCLUDED.result,confidence=EXCLUDED.confidence,artifact_ids=EXCLUDED.artifact_ids,metadata=EXCLUDED.metadata,error=EXCLUDED.error,completed_at=EXCLUDED.completed_at'),m.model_dump()); await s.commit()
        return m
    async def get(self,user_id,mission_id):
        m=self.items.get(mission_id)
        if m and m.user_id==user_id:return m
        if not self.session_factory:return None
        from sqlalchemy import text
        async with self.session_factory() as s: row=(await s.execute(text('SELECT * FROM missions WHERE id=:id AND user_id=:user'),{'id':mission_id,'user':user_id})).mappings().first()
        return Mission.model_validate(row) if row else None
    async def update(self,m,status=None,progress=None):
        if status is not None:m.status=status
        if progress is not None:m.progress=progress
        await self.save(m)
    async def analytics_record(self,m,event,success=True,metadata=None):
        if self.analytics: await self.analytics.record(m.user_id,AnalyticsEvent(event=event,category='missions',value=1,success=success,agent='mission_manager',metadata=metadata or {}))
