from __future__ import annotations
import asyncio
from backend.app.agents.workforce.agent_models import AgentExecutionRequest
from .mission_models import MissionStatus

class MissionExecutor:
    def __init__(self, mission_manager, workforce, reviewer, planner, artifact_generator): self.manager=mission_manager; self.workforce=workforce; self.reviewer=reviewer; self.planner=planner; self.artifact_generator=artifact_generator
    async def execute(self, mission):
        await self.manager.update(mission,status=MissionStatus.RUNNING,progress=5)
        plan=await self.planner.plan(mission.goal,mission.user_id,mission.conversation_id); await self.planner.save(plan)
        selected=mission.metadata.get('agents') or [a for a in plan.required_agents if a in self.workforce.registry.names()]
        selected=[x for x in selected if x in self.workforce.registry.names()]
        if not selected: selected=['analysis']
        mission.selected_agents=selected; await self.manager.save(mission)
        context={'task_type':plan.task_type.value,'mission_id':str(mission.id),'workspace_id':str(mission.workspace_id) if mission.workspace_id else None}
        if mission.metadata.get('parallel',True):
            request=AgentExecutionRequest(goal=mission.goal,conversation_id=mission.conversation_id,complexity=plan.complexity.value,mode='team',max_agents=len(selected),preferred_agents=selected,context=context)
            workforce_result=await self.workforce.execute(mission.user_id,request)
            draft=workforce_result.merged_response; confidence=workforce_result.confidence
        else:
            outputs=[]
            for index,agent in enumerate(selected,1):
                request=AgentExecutionRequest(goal=mission.goal,conversation_id=mission.conversation_id,complexity=plan.complexity.value,mode='single',preferred_agents=[agent],context=context|{'prior_outputs':outputs})
                result=await self.workforce.execute(mission.user_id,request); outputs.append(result.merged_response); confidence=result.confidence
                mission.progress=10+index/max(1,len(selected))*55; await self.manager.save(mission)
            draft='\n\n'.join(outputs); confidence=sum(1 for _ in outputs)/max(1,len(outputs)) if outputs else 0
        await self.manager.update(mission,status=MissionStatus.REVIEWING,progress=75)
        review=await self.reviewer.review(mission.goal,plan.model_dump(mode='json'),draft,mission.user_id,1)
        if review.needs_revision:
            revision=await self.workforce.execute(mission.user_id,AgentExecutionRequest(goal=mission.goal+'\nReviewer feedback: '+' '.join(review.feedback),complexity=plan.complexity.value,mode='single',preferred_agents=[selected[0]],context=context|{'draft':draft,'revision':True}))
            if revision.merged_response: draft=revision.merged_response
            confidence=max(confidence,revision.confidence)
        artifact_ids=[]
        artifact_type=mission.metadata.get('artifact_type')
        if artifact_type:
            artifact=await self.artifact_generator.create(mission.user_id,mission.metadata.get('artifact_title') or 'NOX Mission Deliverable',artifact_type,draft,mission_id=mission.id,workspace_id=mission.workspace_id,metadata={'review_score':review.overall_score,'agents':selected})
            artifact_ids=[artifact.id]
        mission.result=draft; mission.confidence=confidence; mission.artifact_ids=artifact_ids; mission.progress=100; mission.status=MissionStatus.COMPLETED; mission.completed_at=__import__('datetime').datetime.now(__import__('datetime').timezone.utc); await self.manager.save(mission); await self.manager.analytics_record(mission,'mission_completed',metadata={'review_score':review.overall_score,'confidence':confidence})
        return mission
